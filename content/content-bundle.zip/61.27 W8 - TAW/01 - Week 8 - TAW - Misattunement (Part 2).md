---

---

# Week 8: Misattunement (Part 2)

## This Week’s Objectives

- Topics we’ll cover:
	- External Subsource
- This week, it will be a big win if you can:
	- Start to notice external subsource in inputs and outputs.

## Application: External Subsource in _The Aeronaut’s Windlass_

<iframe loading="lazy" title="External Sub-Source; subtitle: The Aeronaut&amp;rsquo;s Windlass" src="https://player.vimeo.com/video/762973743?h=398bb9a2b1&amp;dnt=1&amp;app_id=122963" width="680" height="383" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen=""></iframe>

[[External-Subsource_-TAW.pdf]]

## Your Worksheet

In your worksheet this week, you’ll continue with your analysis of the scene from _The Hunger Games._

For your writing exercise, you’ll build a foundation for your avatars’ external subsources by exploring their identities.

[[Semester-3-Worksheet-8-Answer-Key.pdf]]

## Reflection Questions

### Training Reflection Questions

Reflect: Did anything surprise you in today's training?

Reflect: Which topic is the most unclear to you?

Reflect: What is the most important thing that you learned today?

Reflect: What is one question that you'd like answered about today's topic?

## Forum Challenge

[See the Subsource](https://community.storygrid.com/t/forum-challenge-see-the-subsource-semester-3/15584)

Ad campaigns are a great way to start to identify external subsource. For this week’s forum challenge, find an ad campaign and identify the external subsource that the campaign is using to convince the viewer of its message.

Head to the forum to see an example and add your own.

---
# Navigation
up:: 
same:: 
down:: [[Week 8 Worksheet - Story Grid Store]]
previous:: [[60 STORY GRID/61 Guild - Year 1/61.22 W7 - Misattunement/01 - Week 7 - Misattunement (Part 1)]]
next:: 

