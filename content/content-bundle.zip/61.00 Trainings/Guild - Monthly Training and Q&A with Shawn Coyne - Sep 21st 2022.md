---
status:
type: lecture
tags:
source:
---

# Guild - Monthly Training and Q&A with Shawn Coyne

> ## Excerpt
> Wed, Sep 21, 2022 2:54 PM; Duration: Live

# Sep. 21: Story Thermodynamics

---
<iframe title="Shawn Guild Q&amp;amp;A - Story Thermodynamics" src="https://player.vimeo.com/video/753670497?h=bf6c207413&amp;dnt=1&amp;app_id=122963" width="680" height="383" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen=""></iframe>

---

nobody's getting nervous when

Do I have to let you meet? Okay, hold on I can fix it

alright, you should be able to know.

I canceled the meeting for this afternoon but before you respond, just remember this is being transcribed and people can see it.

All right. It is Tim. So I'm gonna let everybody in

Hello, everyone, and welcome to this month's guild training and q&a with Shawn Coyne excited to have you here. Hope everybody's been settling into the new semester and kind of figuring everything out in your group.

For those of you especially for those of you that this is your first time joining us for one of these, how it usually works is Sean is going to teach a little bit and then we will jump into question so we take questions ahead of time in the forum.

And also if you want to drop them in the chat as we go, and then we get to as many of those as we can. But otherwise excited to go ahead and jump in. So Shawn, I'm going to turn it over to you.

Okay, great. Thanks, Tim.

So, so today, what I thought I would do is to support the work that's being done in the guild at the at the ground level of writing, right so you're you're literally learning how to best signal your senses. That's what the guild is about is to enable you to signal messages to Sam with the greatest clarity, right? So all of the work and if you ever get lost and go What the hell am I doing what is I don't get what all this stuff means. Just remember, you're learning how to send signals with with real clarity, so that Sam has no confusion of what it is you're trying to communicate to her. So that's the bottom line of the guild and that work is progressive. It's it's difficult. It takes time. It takes patience. It takes a suspension of critical sort of push back.

So you're going to experience all of that sort of stuff. So just remember, it's all about teaching you how to write clear signal sentences that Sam will understand with great clarity. And that's tricky because sometimes we're not really even sure what we're sending. So by analyzing masterworks to see how the Masters send their signals, that will enable you to start thinking about the signals that you want to send. Okay, so this all goes to really foundational stuff at the bottom of physics. So you probably are all wondering, Well, where did where does shine, get all this stuff about chaos, order complexity, etc. So what I thought I would do today is to give a very very coarse but generally accurate look at the foundations of physics, which are called thermodynamics.

So I'm going to share my screen and No, no bachelor's degree from any university is required to understand this, hopefully, let me go back to the very start.

So let me let me just say, you know, just follow the flow the argument. And you can always refer to this again, if you ever get confused, but this is going to be very, very helpful when you start thinking about your avatars.

So let me let me just start. So what are the origins of Story Grid conception of chaos complexity in order because you hear me talk about that all the time? And I'm sure sometimes you're like, I sort of understand that not really. So you can go back and refer to this when you get confused. All right. So it starts at a very foundational level called thermodynamics. And this was this was a theory by a guy named Helmholtz back in the 18th century. And he was he drove a mad because what happened was there was no real experimental ability to prove his theories. So anyway, if you ever get interested, Helmholtz is the foundational figure of thermodynamics and he came up with the concept of free energy, which I talk about a lot, right? So Helmholtz is the source. Okay, so it concerns the state of an entire system. Right? So an entire system broadly how much potential energy is inside that system? This is what we're trying to figure out with a thermodynamic system. How much potential energy is in there? Right. That's the question. So before we can get into the energy, let's talk about systems.

Broadly, what a system is, is a it's a thing with internality, right? It has an interior and it has a boundary condition around it that separates its interiority from the exteriority. Right? So my interiority of my body keeps all my organs and things in place. And so my organs are popping out of my body, because I have a boundary condition of my skin, right? So it's a really cool thing. And so we've got systems that are inside of surroundings. So I'm in my room right now. I'm in my office. So that's what surrounding me. And then if we really went up to the top of the abstract conceptual, my room is inside the universe, right? So I am embedded inside of my room. Which is embedded inside of the universe itself. So that's really, really helpful to think about. We are embedded creatures. There is no outside of the universe, right? Because the universe is abstraction abstractly, conceptually, every thing and no thing that we can imagine. Okay, cool. So that's what a system is.

So, your avatars in a story are systems so they have a boundary condition and they are inside of surroundings, which we often call either environments or arenas, right? Or the surroundings or the context.

So if you start thinking in terms of systems for your avatars, it will prove very helpful because you can get out of the whole thing like well, I don't know what she would do in this thing, because, but if you start thinking of her as a system, you can start figuring out what's necessary to do in your own storytelling. All right, so systems come in three varieties. Okay.

We have open versus closed systems, and then ultimately something called an isolated system.

So this isn't hard to understand. Here's an open system. Let's call this a pot. of water on your, you know, your microwave right on your range, right? So you're heating up your water and you don't have a top on it. Okay, so it's a pot of water on the stovetop without a lid. So what happens is that matter and heat, are easily exchangeable between the system and its surroundings. So this this, this permeability of the boundary condition isn't it's open, wide open. So it flows based upon what the surroundings are. So if the surroundings are colder than the liquid in here, the liquid forms gas and it goes into the cold air.

Right? It dissipates. So this is an exchange of heat and matter between a system and its surroundings. And what that means is that it's very, very open. So for example, let's say my body now it's it's and what we're going to talk about what kind of systems human beings are in a second. But think about this. What if I took my body and I went into outer space without a spacesuit?

Well, the surroundings of space are so large and chaotic. My my skin would blow apart and I would just, I would just go into little bits, right? Because my, my open system will, will just explode. Right? So that's an open system. So if you think about it in terms of an avatar, let's say you have an avatar who's super it's a super she's a super open system that that means she's going to be vulnerable, right?

Because she's letting the things come into her and she's letting everything that's inside of her out, metaphorically. So she speaks her thoughts. She doesn't edit herself and she just takes in all the, the information and energy that's very chaotic. And she speaks her thoughts. So she's going to be sort of a chaotic force because she doesn't have a control mechanism to stop her interiority from exploding into the exteriority right? That's a metaphor. It's something to think about.

Okay, now, let's go to the next kind of system. This is a closed system.

So this would be like a pot of water with with a really great seal on the lid. Right? So the only thing that's going to be able to be exchanged with the surroundings is heat.

Matter is not going to get out. None of this water is going to get out of the pot.

So the only thing that can change is the heat. So if I'm heating this up to 100 degrees Celsius, but outside is 100 degrees Celsius, nothing's really going to change about that water inside the pod because it is going to be contained. I'm going to get into differences in phases in a second. So don't jump ahead and in your thoughts and go Well it's gonna boil in there. I'm gonna get to that. All right. So that's a closed system. So this is sort of permeable, right? It has it has channels for heat to escape, but no other things can get out. So the only thing that can get out of this closed system is heat. Energy, right.

And that's the closest. Lastly, we have an isolated system. An isolated system doesn't let anything in or out.

Right. So think of your refrigerator.

Your refrigerator is a form of not not extremely efficient form, but it is a form of an isolated system. In that you close and seal and it stays the same temperature in there and it does not dissipate heat into your kitchen. That's why the cold stuff in your refrigerator stays cold.

You have to spend energy to keep it that way. But then isolated system generally means there's no exchange of anything. So what happens in isolated systems is that the the system inside here reaches what's called sort of a thermodynamic equilibrium. It levels out into sameness, such that all of the energy in here is sort of equally distributed.

So it's death. Basically, it breaks down into the sameness.

Alright, cool. So think about this. Now. Some of our characters are avatars, sorry, these are avatars.

They can be expressed and thought of in these terms, is my avatar open how open? Is my avatar closed? How closed is my avatar isolated? Isolated avatars are tricky, right? Because they don't let anything in or out. They live in a world of certainty.

Because they've got it all figured out. So they've closed down the borders. They've shut down the walls, and nothing is going to get in and nothing is going to get out. Think of Ted Kaczynski in his his cabin up in the middle of nowhere. With with with no contact with anyone.

All right, so let's move into Phase Transitions.

Okay, so how do people How did these systems change? Right? Because we know water can change right? We know it can become gas. It can become water vapor. And we also know it can become a solid ice, right? So let's take a look at what what I mean by phase transitions.

Phase Transitions, like let's talk about gas to liquid.

Like let's say we wanted to take the gas of water, h2o molecules in the air and condense it down to liquid. Well, what we would have to do is reduce the temperature right? So that we would capture and those those molecules would come down and then they would bind with one another. And slowly we'd get drips. This is like in The Martian, right? In the Martian movie.

That's that's what he did. He set a fire so that the hydrogen and the oxygen would bind together and condense in a in an isolated system because his little habitat had no inner out right that's why he had to go through that portal. So he lived in an isolated system. So he would be able to theoretically and he did do it. Make his own water using hydrogen gas and the oxygen in the in the air.

Alright, cool. So we would reduce the temperature and that would enable the transformation of the gas, water gas into the formulation of water liquid. So this would be a very dispersed like we can't really see water gas. Sometimes we can in clouds, but not really very well. So the gases are hard to see. We can't see them very well. But but we can sort of, we do have other senses that can take them in right we can smell them. gases have smells, some of them. And also sometimes the vapor we can see but it's very easy. can't grab it right?

Then you can't really touch it.

Like touch oxygen if you can't do it, right.

So gases are really dispersed and they're flying around. It's like a storm of molecules and we can't see them.

very chaotic, right? They're moving all over the place until we order them they're very chaotic. Alright, so moving from gas to liquid we would move from a first aspect of h2o, it transforms into another a second form called liquid water. Cool. Now what if what if we we lowered the temperature some more in our refrigerator, then we can take that second form and it would transform into a third form called a solid? Right? Ice.

Now ice we can hold that right we can touch it we can feel it.

If we get a lot of we got a lot of sensory stuff on on the solid liquid. Yeah, we have more than gas but not as much as solid, right? Because you can't hold a liquid. It just goes right through your hands. Right? So it's very, you can't really hold it.

You can only sort of experience the liquid.

So you dip your hand in water and and it's interesting and you can feel it down in there. But when you pull it out, you can't take any with you really. Alright. So the second form transit. So these are called phase transitions, based upon how much energy is being put into or taken out of the system itself.

All right, cool. Well, let's see if we can loop it back. What would we have to do to make a solid a liquid? We'd have to pump some heat into it right, turn up the temperature. And so the third aspect will reform into the second.

So it's going to reform into liquid and then the same thing liquid can reform into gas with even more heat, and then we're back up in our loop right. You see the cycle of phase transitions loops. The gas can become liquid the liquid can become solid, the solid became gonna come liquid, the liquid we can become gas. And there we are back again. It's a dynamical loop that is dependent upon energy transfers, to change the phases of the system. Now think about this again. What is what is one of your avatars it's a system. And what do you want to do in a store? You want to change your avatar from the beginning of the story to the end of the story?

So your avatar needs to go through phase transitions that will take their chaos or their order, break it down, and loop.

Alright, let's Alright, so let's let's look at this a little bit more closely. So let's think about the open system.

An open system undergoes phase transitions externally.

And they do it quickly right because there is no boundary condition holding holding the gas inside the pot. Nothing is holding the gas inside the pot. And so they can covary with their surroundings optimally in real time, meaning when the outside changes so does the system very easily.

Right? There's there's no stop gap.

So the water in the pot transitions from liquid to gases at bubbles, it can adapt to the environment by phase shift transformation and re formation.

So the system adapts to the surroundings very easily in an open system very easily. But the problem with an open a fully open system is what I can disintegrate with all of my openness. I am so vulnerable that my insides can explode and become part of the outsides.

And I'm dead right okay, cool. What about a closed system? Now a closed system undergoes phase transitions less quickly than open systems.

And remember, you can only exchange heat with the environment. So the internality of the system can undergo phase transition. So let's say there's ice in my head and it gets hot.

Well, the ice in my head is going to melt into liquid, but the liquid can't get out of my head.

So the only way for me to get rid of that heat is to expel the heat some other way. This is metaphorical but pretty close. So if you think about, Well, geez, how do I get my character of my avatar to do something interesting? Well, you got to put some heat on right. So that they have an internal boiling such that they have to release that energy or they're going to start to fall apart inside.

That's a way of thinking of a closed system. An isolated system. This cannot exchange any matter heat with the surroundings at all. So again, think of Ted Kaczynski.

He wasn't he wasn't communicating with anyone. He was sitting up by himself, just churning in his isolated room.

And he got very, very certain about a lot of things. Right?

Because he wasn't communing. He wasn't relating to anybody. He wasn't getting any inputs and he wasn't outputting until he exploded.

So what kind of systems are human human beings? Well, we've got the capacity for all three, don't we?

All of us have the capacity to open up our systems of framing of the way we see the world, closing them down, and sometimes isolating ourselves to work it through. Right.

But we've got to be able to learn how to move through these phase transitions without going for fluey.

We need to integrate and justify our systems. Our ability to open close and isolate so that we can best optimally adapt to the inevitable random changes that come from the real world. There is no stopping change.

If any of you ever have any experience in molecular biology, you know that down at the nano level. The molecular storm of molecules is like being in a sandstorm in the Sahara. It's just it's complete random chaos. And from that chaos, ordered things emerge. It's an amazing, amazing thing.

Okay, let's do a last bit and I'm going to map this now into my concepts of chaos, order and complexity. And I'm also going to map it into our three levels of on the surface above the surface and beyond the surface.

So hang with me and you can always refer to this again, it's a pretty good, you know, generalize grok of what I mean, about Order Chaos, it's okay. So, what is the link between thermodynamics and Story Grid use of the terms chaos, complexity and order. So, in other words, how does change phase transition actually happen in a story?

Well, it happens the same way it happens in real life.

Right. So at the very bottom, we have chaos.

Chaos, the molecular storm at the nano level, we are in the nano level now but we just can't feel it. Thank God.

It's extraordinary that you're being pelted by your internet rays, by molecules by gases by things that you cannot see.

But it's there. It's it's banging. against your skin as we speak.

It's chaotic. That's why we like to niche our rooms and our homes, right. We like to turn off our internet and when we go to bed and we like to make sure that things are clean, right? Because we need to reduce the noise of all that molecular storm hitting us so that we can take the time necessary to learn how to navigate and to attain the wants, needs and desires that that we want. Right without that we're shooting for our target goals. Alright, so at the very bottom is chaos. Well, well, what kind of chaos is that?

Well, here here we go. We got three kinds of chaos. Right? We've got causal chaos, right. So this is what what I talked about when I talked about direct particle energy.

So causal Inciting Incidents are direct particle energy transfers to avatars called protagonists. All right. So what is the direct particle energy? What does that mean? Well, basically all this means is that when you turn up the heater in your house, that cause makes you get warm, right? So you're able to increase the energy in your room, such that the, the molecular storm gets faster and it hits your body more, which heats you up.

That's actually the quantum mechanical level of how you get warm.

So that's a causal, chaotic

What about the next one? Well, then we have correlational chaos.

So correlational chaos is sort of like let's say you're walking down the street, and you're not doing anything wrong. You're on the right side of the street, you're doing your day, and somebody just starts yelling at you. Get out of my way.

And then they walk by. That's a correlational wave energy transfer, right? Because you didn't cause that. But you can think about it nearby. I bet something happened to that person before they saw me that I didn't witness that caused their pot to boil in their head and they released the heat at me.

Right. So their system, their internal system boiled over, and they pushed out their heat at me in the form of a verbal assault.

That would be a correlational chaotic event in a story.

What about the last kind now these are the real difficult ones to deal with because there's no control over this like, like when you get a correlational chaos event, you can start to justify it in your mind. You can start to empathize or not with the other person and say, Well, I bet there was a there's a reason why that person yelled at me.

It doesn't have anything to do with me. But there is a reason why right? It's correlated, but not causal.

Now, the last kind are coincidental chaos.

And this is what Helmholtz was talking about and what Karl Friston talks about when he talks about the free energy principle.

What free energy is, is coincidental chaos Carl Jung called them little balls of chaos. At Story Grid, I coined the term the invisible fear gorilla a P H. e r e. That's coincidental chaos.

And this is the shit that drives us crazy. Because it makes no sense. There's no cause there's no correlation. It just fucking happened. It's fate.

It's fate, for whatever reason. You stepped off the side of the road and a bike hits you and breaks your leg.

Just a coincidence. There's nothing you can do about it. There's no reason for it.

And it's horrifying because you have no control over coincidental chaos. There's nothing you can do about it.

It's it's the, the truth of the uncertain random nature of the universe. It's indifferent at the random level. That's really hard to get a grok on.

We do all we can to try and avoid this stuff. Fate is coming for you. We are all going to die. That's the great truth. It's very painful, but it's fake.

Okay, so that would be like a hurricane, you know, comes and wipes out your house. It's not your fault. It's not anyone's fault.

It's a coincidental noumenal event from the randomness of things that we don't understand and never will understand.

So this is the very bottom of incitement in a story.

And you want to be able to identify, Oh, I wonder what Tolkien was using which kind of chaos was he using to incite this scene? Or this beat or this trope right?

And the more you get, you identify these signals. These are signals, right? These are signals of energy.

One aside, Claude Shannon made a mathematical proof that signals are the same as energy.

So energy and signal communication is the same thing. That's why I talk about it as energy instead of information at the very bottom. Okay, so those are the three levels now what about order? Right? We've got chaos at the bottom border will Oh, okay. Orders are at the ATS zone. Right. So the we order shit in our minds. That's what we do. We're the ordering system. So we take the chaos of the world and we order it in our minds. We put words to it, we give some semantic representational words to patterns and signals.

It has a structural functional organization that is essential, it holds the liquids so that I can drink from it.

Alright, so just as we have causal, correlational and coincidental chaos, so do we have causal correlational and coincidental order?

So causal order is sort of direct technology we mechanize essence. So there's a series of clear step by step processes that result in the production of a car or a lawn mower or a cop or a candle. Technology is awesome, because we can cause the the formation the the copying of patterns and signals of intelligibility that we've picked up from the universe, and we can recreate them so we can make a cup.

That's really incredible. that's meaningful. That's That's incredible.

So that's causal order. We cause the order of things.

What about correlational work? This is indirect technology. This is sort of like when an aspect of a thing that we've created reveals itself. To be

something else so for example, post it notes.

post it notes were conceived, they were causally ordered, as a means to create the strongest Bonding Adhesive ever.

However, the the actuality of it was it really wasn't that strong. In fact, it was pretty weak but just strong enough to hold a piece of paper in a Bible hymnal.

So the post it note was a correlational highly ordered thing that emerged, right? It's causal order didn't work, but another aspect of it a correlation to that causal order did.

So that's a correlational order is when you re aspect actualize technology and see another purpose or use of that technology for something else. This is this is acceptation at the technical technological level, just as our mouths were, you know, we have mouths to eat not to speak. But we exhausted our mouths when we learned how to blow air through our our throats and communicate. So now our mouths are both eating mechanisms and speaking mechanisms. But the first one was eating before speaking right same with correlational order. It's sort of the process of x application of technology with a new aspect. All right, last one. Gotta keep I gotta move, move along here. Coincidental order. This is like your pizza. Your peanut butter landed in my chocolate. Your chocolate landed in my peanut butter, accidental noumenal random technology emerging and all of a sudden you have a peanut butter cup.

Nobody planned it. Nobody really asked actualized it. It just happened and then when it was tested, it was delicious.

And now we can mechanize that and make as many peanut butter cups as we want.

So you can see how people solve problems using causal order correlational ordering coincidental order. Causal order is they follow a fucking recipe. Correlational order is they make a transparency to opacity shift, such that they see a new aspect of something that they never considered before they have an insight. Oh shit. This is terrible for super glue, but it's great for getting all those notes in my Bible to stick to the pages

and then coincidental order is a gift from heaven.

Accidentally happened and you recognize and you realize the accident. You don't just blow off the accident and go Oh, I gotta wipe this peanut butter off my chocolate. You go I'm gonna taste this shit and see how good it is. Holy crap, right.

So coincidental order is the discovery of incredible inexhaustible stuff that's right in front of us.

Okay. This is the red zone.

What about the blue zone? Oh, wow. Okay, so now we're moving from energy signal to informing pattern to meaning making forms.

So Plato talked about the landscape of intelligibility.

And in my estimation, there are three ways that we can find things intelligible.

We can take in the signals, we process the signals into information, it informs us and then we process the information into symbolic representation, which is meaningful.

Storytelling lives in the blue zone. It's the highest level of cognitive capacity that we have as beings. And in fact, it's the highest level of cognitive capacity ever, ever created.

We are at the top of the pyramid.

And this is a very, very powerful psycho technology that we need to come into close. Contact with and understand with great resolution and specificity. Because as as, as amazing as it is, it's also extraordinarily dangerous.

Okay, so there are three kinds of complexity.

And complexity is the meaning making thing that you do when you tell a story. You justify you give reasons. You have beginning middles and ends, you provide energy, intriguing catharsis.

Alright, so we have causal complexity. Hey, that's getting pregnant.

Why? Well, it's a clear process.

Hopefully, and it's co creation of existence, right? You're co creating a new being when you get pregnant.

You can't do it by yourself.

And God save us from machines doing it for us.

Because, anyway, so that's co creation. Storytelling is all about co creation. It's not just one creation, it's co creation, you, you take advantage of the natural laws of this beautiful cosmos.

The desire that you have for another human being and you co create another being you you bring life into this beautiful world. That's amazing. It's causal. And it takes fucking courage to do that.

Because what you've got to sacrifice now that's your responsibility that being is now yours. You've got to take care of it. You got to help it grow, right? You can't abandon it.

Alright, the next one is correlational complexity.

This is really interesting. This is the co creation of existence at a correlational level. So all this stuff is so cool, because it maps on to the other. So if you get stuck, you can always go well what is this about? And what is this about? Maybe that'll help me figure out what this is about. All right, so this is about it's kind of like you discover that the same process that our bodies undergo, you know, morphological change. You know, like say you want to get strong, you go to the weight room, you lift your weights, we experience pain, hurts.

Pain hurts. Got to walk around like, get rid of the lactic acid that is the byproduct of that work. And it hurts. You're okay with that. You understand? I'm in for the hurt. I understand. I want to get strong. Well correlational complexity is understanding the same process. works in your mind.

If you want to get a stronger mind, you're gonna hurt you're gonna get byproducts of metaphorical lactic acid in your mind that are going to hurt.

So you can either go this doesn't make sense that this hurts that I'm trying to get smarter and it's It hurts. It shouldn't. Of course, it makes sense. Why? Because your body and your brain use the same mechanisms.

So if it works for your body, that's how your mind works too. So when you start feeling badly, and you're you're feeling negative effect in your mind while you're trying to get smarter, and you say to yourself, I'm never going to get this shit. This is impossible. Just remember, this is the process of co creation of new existence. At the correlational complexity. complexified arena. When you make meaning it hurts.

That hurts. So expect to hurt.

If you're not hurting. You're not complexified sorry.

If it doesn't hurt you're not complexify because it hurts to break things down and rebuild them.

Imagine like you got to take a part of a toy you know, like a puzzle and then put it back together. Your fingers start to hurt when you're taking all the pieces and then when you put them back and hurt some more. It's okay you got a new puzzle though right?

Okay. Lastly, we have coincidental complexity. And this is what people are always trying to get for free.

These are noumenal random processes Co Co creation of existence that happens as a co creation between you in the numinous. And it feels like you didn't have to do shit for it. Right? But that's not true.

Because what what this does is you're you're able to bind one kind of phenomena onto another and discover a metaphorical truth.

So, you can see why this is part of meaning right? Let me write that was blockwork screen. Alright, we bind seemingly unrelated phenomena onto another phenomena such that a metaphorical truth is realized.

So the big big thing that I've I didn't figure this out. Somebody figured this out in 1972. But our educational system is so poor that I had to I had to figure it out myself. And then I discovered that other people have figured this out. So here's the big, metaphorical coincidental complexity that finally came to me is that in time, changes in degree become changes in kind.

All that is, is a very simple sentence that explains all of thermodynamics.

In time, changes in degree more heat, less heat.

How long are you heating up the thing? If you heat it up too much, it's going to boil and phase transition from liquid to gas.

If you call it down, it's gonna phase transition from gas to liquid. And there's these beautiful liminal spaces where we can loop back and forth and back and forth.

Chaos order and complexity are metaphorically the same as

free energy as chaos gas, right?

Right? It's it's pressed together in an ordered way. And complexity would be liquid.

Liquid, you have to flow in the liquid.

You can't grab the liquid.

Right? You have to flow with it. It's Heraclitus you never step in the same river twice. Our lives are liquid beautiful things.

And we get this phase transition morphologically and psychologically. And the way we do that is to understanding story.

Because the narrative, virtual world informs our real world. And then the real world informs our narrative virtual world. So that the most beautiful dynamical system there is in mental psychological thinking is the dynamical system between the inventions of the virtual world of our narrative orders and the real world of our experience, and we need to inform our virtual creations with our real world experiences and vice versa.

And that's how you flow in the river of time.

So thermodynamics is all about figuring that out.

And and being comfortable knowing that sometimes you're going to be gaseous, sometimes you're going to be a solid mess. And hopefully, you can always get back to the liquid and flow through it.

So that's why the highest order of flows flow they call it the flow state.

When you are writing when you are doing something that feels right, beautiful, incredible true. That's called the flow state for a very good reason. Because your inherent cleitus is River and you are just flowing without water. And it's imbuing you as you are viewing it. That is the dynamical system of the beauty and the goodness, the truth and beauty of life.

And stories remind us of this beautiful dynamical system and they enable us to deal with fateful events that we can do nothing about.

But we can flow through them.

And we can recognize the beauty truth and goodness of don't love the world the way it is. So thermodynamics is at the bottom of Story, Grid technology, and thermodynamics into information theory, are the foundations of the guild training that you're going through.

So whenever you get nervous, like, this sounds crazy. What's Danielle and Lizzie going on about? I can't figure this out. I'm never going to figure it out. Take a deep breath. And know that it was all built from thermodynamics and information theory, which are the most robust to paradigmatic theories in science.

This is not this is objective, empirical research that has been robustly reified, reified and reified. It's true.

It's true. This we're not bullshitting.

So, I'm gonna stop there. Got about 15 minutes left and I can take any questions.

All right. So this question is from Penny last week's narrative device lesson discussed identifying the author in stories told from a third person perspective for the aeronauts Windlass. This was the ship's core crystal channeled through an ethereal list.

I found this very interesting and I can see the value. However, it made me wonder about the Hobbit. There you identified the author as a grandfather telling a story to a grandchild that didn't locate them within the story world. Is there a reason for that? Or is it just that this stops they read relationships dynamics level but could be progressed to further Green who in the story world could know enough to tell the stories level?

My suggestion is to to sit with things

because the question is it specific to one story and then it references a whole other story? And then it's making categorical and conceptual leaps.

Which is an indication to me that this is just confusing for you right now. And it goes to being patient intellectually patient in feeling the negative effect of being a bit confused when you're first starting something. So when you first start anything with when I first started to learn how to swim, it was terrifying. And it still hasn't gotten that much better.

But I did recognize that there are people who can swim, but I just wasn't one of them yet.

And to to answer the technicalities, of these question is going to do more harm than good. It just it'll just be me spitting out a bunch of words that we'll be showing off, you know, whatever it is that I can put together from that.

But you have to remember that the the underlying theories and approaches to all that are being taught are very, very foundationally strong. So if you're having difficulty grokking it after a couple of lessons. That's for a reason. Because these are just like I just spent, what, 45 minutes talking about thermodynamic dynamics. I took a class in college that lasted for months on thermodynamics, and I'm still not fully you know, it's, it's not fully clear to me, but you can get the whole, right without knowing all the parts. And the trick is to do your best to Gestalt, the hole and go oh, there are okay. Let's say there are reasons why people make choices about points of view. That's a good hole. And they've made these sort of globally specific choices about points of view. And they're going to explain the differences because there's really only three really main differences between global point of view it's third person, first person or second person. So this isn't the third person round that has. I'm not speaking specifically to the Jim Butcher project, because Leslie is the the expert on that. And it's also like, I know enough not to try and answer that question because Leslie has better expertise than I do on it. So my advice is to who, it's really cool that you can make those connections with the red zones and all that, but try and bring it down and just take it as it comes. And when you're getting cognitive dissonance say, Oh, this makes sense because I'm growing. So I'm getting some negative effect just like you would lifting weights. So you're getting you're getting the lactic acid in your mind. I can't pull it out of your head for you. It's going to be a process that that only you can do and confusing. You more by giving you technical answers to things that I don't think is a good idea so that I'm just gonna leave it at that.

Curious about your reading and video list. So far? I'm tracking Zach Stein, Ian McGilchrist, lots of per bakey. complexity science chaos theory, information theory young in psychology. What am I missing?

There's Plato, Aristotle, cybernetics C Helmholtz thermodynamics I just talked about. There's there's molecular biology, there's Fineman. The the notion of ratcheting acceptation through the thing I just explained, difference in degree become differences in time changes in time. There's a forest Landry's eminent metaphysics. Which is an extraordinarily brilliant, the best.

And I think it's absolutely true as the foundational understanding of metaphysics. It's better than Conte. It's better than John Stuart Mill is better than Aristotle, because it also Kirk Adele's Incompleteness Theorem, so mathematical people like John von Neumann, Kirk gadelle.

There I'm I read the latest papers from Michael Levin, who is a molecular biologist who also specializes in. He's the discoverer of the electronics sick, the electric signals the energy signals within the membranes in the cytoplasm within cells that actually tell them what to do. So how does an organ know that it's part of a heart? Well, it's because of the the context of the signaling to the cells. So I'm not trying to overwhelm you but it's it's a very it's a 30 year thing and I you know, to to list all the influences would be long and hard but Vivek is a great start Karl Friston in the the free energy principle and predictive processing systems.

There's the five trade theory there's Jonathan hight in terms of values.

The Aristotelian values as delineated generally by Plato, the virtues I mean, so anyway, it's a long exhaustive list, but cybernetics is a good idea to see how the systems work and loop at the at the energy levels. But I prefer Shannon, because Shannon isn't about control systems. He's about more the phenomena.

And I forget the guy know, Norbert Wiener came up with cybernetics. And he came up with cybernetics as a means to control people.

So the cybernetic process is about command and control, and it was adopted by game theorists. In the 1950s, who came up with mutually assured destruction by commanding control systems. But what's really fascinating is that what really prevented a nuclear holocaust was a telephone.

When Khrushchev and Kennedy could talk to each other one to one, it was over. Because they're both like, Man, I don't want to blow up the world. Do you know me neither. Fuck it.

I'll pull the apologetic Cuba, you pull your shit out of Turkey and we're done. And that's what happened. So it was the communication that enabled the continuance of life all the other stuff the computation all that you have to talk to each other.

So at bottom I'm a thermodynamic information theory person cybernetics is useful so is so is game theory, but they I think they became too reductionist, one side of them anyway. So I'll stop there.

All right. This one is from Scott does introducing the concept of the three Trinity plains lead to further architecture on the Story Grid spreadsheet. If we are to add beyond the surface above the surface and on the surface features that would make the grid almost multi dimensional.

Yeah, that's technology that we have.

We're not sharing it with you because it's it's, it's too overwhelming.

It's the technology that we use. Daniel developed my theories into just a great computational system that can automatically generate story grids. But all of those things are baked into you know, the next probably Story Grid 3.0 would be the optimization of that kind of stuff, but it's it's very, very strong. It's just it's a matter of me being able to take the time to go through it with great specificity But Leslie and Daniel and I developed what I called the Claude Shannon pipes. Well, I came up with them and then they they helped bring more resolution. To them. And those concern those three planes, so yes, but you know, one acceptation at a time

because it's very difficult. I admire all of you because I'm, I'm asking you to put aside every piece of shit that you've ever learned about writing in your life and say, You know what, just hold that over here and start new and you're all doing it and you're all doing it with great courage, and I really appreciate it because it's not easy to say everything that I've been told about this thing before. Doesn't seem to be correct. So I'm going to start fresh. It's exactly what faced people in the you know, in the enlightenment, we always thought that the world was the center of the universe, per Aristotle. But now let's take a look at the math a little bit more and see if we can get a better grip on this thing. And that then we got, you know, we got all that rot from the scientific revolution, which is amazingly powerful and amazingly bad too, because we're all still locked in the reductionist ideas of Galileo and Descartes. And we can't break out of it. We can't think that there's there's a trinity of things in relationship. All we think it's one thing it's only one thing that's wrong. It's absolutely not one thing. It's a Trinity that moves and forms a higher order, which is the Neoplatonic, oneness, in my estimation. And a lot of people call it God or the pure energy state or whatever, but it's, it's the new mental space from which we can never we don't have the capacity to know what that is yet, and I don't think ever.

All right, let's end with this one. From Alejandro.

I would love some clarification on how do we Beats into tropes and especially how to know which tropes to use and when and why in a given scene. Are there patterns and techniques for stalking Beats in the scene?

Basically looking for clues as to how it all comes together when you actually compose your scenes.

Well, this is a great question and I'll Leslie and I had a conversation yesterday and it was really, together. We came up with the concept. I think it's could be very useful. It's not easy. But when you're looking at the construction of story from a very analytical point of view, and that's really important, you got to do it you got to learn how to do that. There is a transition a transformation that you need to make when you map the theory into practice. And this is when you apply the real world experiences of your life to your story. So what that means is you get a bunch of constraints, right? You know what, what you need to do for the trope. I need this trope to be about testing someone's resilience, something like that. Then what you would do is you would say, Well, how does one test one's resilience? You could do it that way and look at it very analytically or, and then what you're going to do is probably write something pretty dry, and without much to it. But if you say to yourself, when was the last time I witnessed someone who was having their resilience tested, what did they do? And then you you go into this imaginal realm in your mind, and you say, let me see resilience. What does that mean? Really? Okay, it means like standing up when it's really difficult and you want to quit, but you keep going anyway, do I know and do I have any personal experiences with that? And don't make it about yourself? Try and find a moment when you witness someone else do it. And this is something that we were going to talk to Tim on Friday about for the podcast. Is that we've been asking Tim to think about things that have happened to himself and we don't think that that's probably the best move.

Instead to think about when Tim witnessed another person doing it, because those are very you can bring those up without self examination so much. But if you remember like, all right, I remember back in college, there was that track meet and that guy tore his hamstring and he just needed to finish the race. And I watched as he struggled across that finish line. And the way that the way he DeFazio you know, and you can start to picture it in your mind. And then what you do is you write that and you change the name of that person to your avatars name and what you're going to find is that your the signals that you're sending the choices of words that you use are going to be really good, because you're basically running the frame that the experience in your mind and you're then describing it and taking dictation from that moment. And then that's where you have an editor right? So you do that. And then your editor will go this is really good, but it's a little bit too much. Let's bring it down or it's a little less right. So that's the so when you get into the heartbeat to trope to scene stuff, it can get very egg heavy. And it's kind of like where do I grip this thing. And the grip is within you. And I we don't recommend that you go well one was I resilient because we kind of bullshit ourselves about stuff like that. Or when was I a wimp? Well, we bullshit ourselves about that too. So it's better when you witness another right and another person doing it because then you are bringing that resilience to life you're recreating an experience as opposed to building it up from whole cloth with egg headed technology. Right. So the egg headed toward technology gives you the gold state right? But it's not going to enable you. You've got to go into the imaginal space, right? We can't do it for you. I can't do it. You have to do it. And that having the specificity of the trope will tell you which event in your life to pull. Oh, I need a truck that says this is about you know somebody testing somebody else. When did I witness somebody being tested? Can I remember that? What's the next shot the ones that shine through? Not something that you watched on television, right?

It's got to be something in your life experience. So life experience informs your virtual world. And then your virtual world will inform your life experience. And I guarantee you by the time you finish writing that up, you're going to say to yourself, oh, wow, I never thought of it now that way, because it's going to inform different aspects of the experience that you think you had by the process of reviewing it.

So try and move yourself out of yourself in the imaginal realm.

Because your self is already all over that thing. And if it becomes too solipsistic and too self referential, then it becomes untrue, because you have no clue about yourself really.

Nor do I by the way, it's just what you can't get outside of your eye that the William James eye right? You can't get outside of your frame. So don't try to write go into the memory banks and then simulate from the memory banks with your avatars. I hope that helped.

Okay, we'll wrap it up there.

And just a reminder, you're only a few weeks into this semester of The Guild. And when we lay out when Danielle and Lesley lay out the training for the entire semester.

We're going somewhere together so it's not just kind of like randomly putting out whatever training you want to each week like we have the whole thing already planned out which you can see in your in your dashboard.

Like the schedule for everything. So a couple of the questions I saw come in I didn't specifically ask those because the answer is really like hey, it's coming. We're gonna get to it. Going deeper into tropes, that kind of thing. So yeah, and then there's a couple of questions here and I'll just, yes, our definition of what a trope is, is different than the website link there. So and again, we give that really specific definition to so.

Otherwise, we'll wrap it up for this month. Thanks so much everybody for being here and continuing to be a part of the guild.

We'll continue moving through this semester of the aeronauts windlass and you'll have your call with the instructors next week and then Shawn will be back next month. Thanks everybody. Have a good rest of your day.
