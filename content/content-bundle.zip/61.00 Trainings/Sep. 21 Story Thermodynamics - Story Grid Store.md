---
source: https://store.storygrid.com/guild_pages/september-21-story-thermodynamics/
---

# Sep. 21: Story Thermodynamics - Story Grid Store

> ## Excerpt
> HomeAboutContactPrivacy PolicyLogin To Your Accountav

---
<iframe title="Shawn Guild Q&amp;amp;A - Story Thermodynamics" src="https://player.vimeo.com/video/753670497?h=bf6c207413&amp;dnt=1&amp;app_id=122963" width="680" height="383" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen=""></iframe>
