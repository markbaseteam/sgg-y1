---
status:
type: lecture
tags:
source:
---

# Guild - Monthly Training and Q&A with Shawn Coyne

# Sep. 21: Story Thermodynamics

---

the universal sign for unmute.

Yeah, I have to I have another call. I have to jump on at the top of noon your time. So I may hand off the questions to Lesley and Danielle, whoever's on okay. But, or if you just don't teach as long we don't have a ton of questions ahead of time. So, whatever you do, but if it goes past noon, somebody else will take over. Okay.

Oh, so before I let everybody in and

guess who showed up on the webinar yesterday?

Oh, my God. Yep, we block him. I had he had signed up for the email list like several months ago under a different email address. So I went in and blocked him.

Oh my God. He dropped in a couple of questions and one of them somebody was basically like, Shawn already answered that.

Oh, my God. I'm so glad he's gone. That's funny. I was like, Yeah, Danielle actually pointed it out to me. I was like, Oh my God.

All right. I'm gonna let everybody in.

Hello, everyone, and welcome to this month's q&a and training with Shawn Coyne for The Guild. I'm really excited for what he's going to share today. It's going to be a bit of a continuation of what we talked about yesterday on the live training, which is actually something I want to make sure if you didn't see, we put up the yesterday we hosted a live training called the Master Work spec spec sheet.

It was really really good and I'm excited for you to to go through it. If you didn't see that I'll post a link to the replay in the chat as soon as I'm done here. The other thing I wanted to mention is next month. So I think this will be my fourth year doing a state of Story Grid address where I basically talk about everything we've been doing in Story Grid. And everything that we're doing in the near future.

And we've got a really big announcement coming in for that. And so we're not quite ready to talk about it yet. But it's the biggest thing we've ever announced here at Story Grid and so I can't wait to share it with you. So when you see the announcements about signing up for that, make sure you don't miss out and you jump in on that. But otherwise, that's all I've got. So Shawn, I'm gonna turn it over to you.

Okay, great. So um so what I want to do today is to sort of like, let everybody take a deep breath and review just, you know, the method to my madness, right so that people don't think that I'm just, you know, doing brand new stuff that doesn't really jive with anything done previously. So, I'm going to share my screen here.

And hopefully, yeah, okay, that's the wrong thing. Is this the right thing? I apologize.

I just want to give you the super big, big picture, right. So we've been talking about how or I have been talking about how for the last seven years, I've, since I finished writing the Story Grid.

I didn't stop, you know, investigating storytelling, right, because it was just, it was the sum total of the state of the art of my understanding of story at that time, which you know, is really really great and it has enabled a lot of people I mean, a couple 100,000 copies of the book have sold so that's good, right? But it doesn't mean that I have to stop working.

I'm just love this stuff so much. So it's really what drives my engine. So over the last seven years, I'm like, I think I've really got gotten into the heart and you know, the mother lode of storytelling, but I need to really get my arms around the whole thing. How might I do that? So what I've constructed and what I realized is that there are all kinds of taxonomies in science, you know, like Linnaeus, organized species and kingdoms and fire limbs and all that stuff. And there are very practical ways to order the way you look at the world and they're called taxonomies. Right. So there, you got the big bucket and then you got a little bucket in there like nested sort of Russian doll levels of categories that we think of. So when we think of mammals, that's a big, big category, right? And then we can bring it all the way down to a dog or us or you know, whatever. So there are these different levels of analysis that have their own categorical representation, but they are part of a whole system. Right? So I'm like, I bet story has the same thing. Right? So if there are different levels of animals and universe unicellular organisms, there must be different levels of analysis of story. And absolutely, there are. And so then I got into this whole concept of called Ground theory, which is about the way we human beings actually make sense of the world. So I think I've talked about this before. So what we have are codes, which are sort of these these signals that come to us, and we can't point at them, right. So I can't point at the photon that you know, is hitting off of the light and coming into my body. I can't point at it. They're very tiny. So codes are very, very small things that we can't point at and can't see, but they happen to us anyway. So those are the very, very, very bottom of things. They're the quantum level of experience molecules and particles and all that kind of stuff. So those are signals in a platonic sense, right. And in Claude Shannon information theory sense. And then so we take those codes, and they form patterns to us. So the codes repeat, and they repeat in patterns. And when these patterns we start we can start feeling the patterns. And then we give names to the patterns called categories. So we categorize patterns, which come from codes, so you have signals and codes, patterns and categories. And lastly, then we've got these big massive things that we can't really point at either like evolution or global warming or the economy, right? They're like these massively large concepts, and we can't point at those either. So what we have or concepts that are forms, so we got signals, codes, patterns, categories, forms, and concepts. And then I discovered Well, there's there's a Trinity within each of these. So there's a trinity of concepts, by Trinity of categories, and a trinity of coats. Now we live in that in the middle. We live in the middle of category, so everything that we do all the words that we have for things, they are representations. of patterns that we we have identified, we call this pattern, a pin. We call this a glass case, right? So this is a category. This is a representation within a category, okay? I don't mean to be so abstract, but I want you to get the sense of how I constructed the Story Grid taxonomy. Alright, so up here, what we have are we have nine levels. Okay. So at the very top we have the big concepts. These are the things that are very difficult to point at because they're so large, right? We can't really wrap our minds around it. So we have to have big conceptual categories for these big concepts for this.

So 012, and three are the big concepts. Four, five, and six are the categories so four or five and six are the the way in which we navigate the world. We're very familiar with these. And then 789 Are the the super duper small stuff, right? I'm just gonna walk you through the whole concept of Story, Grid step narrative theoretical framework. This is the whole elephant, right? I talked about the whole elephant instead of looking at the art part of the elephant. You know, the old parable about the blind men investigating the elephant and the blind man who's you know, using the trunk says, Oh, well, it's like a pole and somebody says, it's a break, and they're blind, so they're not moving around the entire elephant. So that's the parable or the analogy about how we need to look at the hole to get the whole thing instead of just parts.

So this is the whole thing. This is the whole thing on three different levels. Alright, so at the very top, we have the single whole thing. And so this is the Story Grid narrative theory, right? This is the absolute declar div, generalized concept of what Story Grid is all about? And it's that thing that's on the cover up my book. It's just that that that infographic that says that you can quantify quality qualitative information in a very helpful manner. So you can see the expanse of time and the changes of value in a person's life. On a on a graph. That's the big idea. That's the big idea. Story Grid. That's it. The end, okay. But there's a lot more on that there's a lot more meat on that bone right. So we can go to other levels of analysis. So the next level analysis is what I call a dialogue. Oh, so that's the analog, right? That's the one analog means one. Daya logos is you know, it's Greek for two. Now, Logos means the reality the ultimate reality.

So the ultimate one idea is the infographic and then we have a binary a two underneath the ANA logos concept and this is the called the meta.

And the meta is what we call narrative path.

So narrative path Leslie is going to be presenting the narrative path in a couple of weeks. And this is the meta functional framework. This is the way we we teach people how to send signals, patterns and forms to single audience members so that they can understand what they're talking about. So the narrative path explained is is an explanatory binary concept of governing and generating functionality.

Right, that's what it boils down to Governor constraints, and generator constraints that come in a loop and form an engine.

Okay, so the third one is what I call a trial logos concept and these are Trinity's These are three things instead of two, right? And so the genre blueprint that I just presented yesterday's fits in perfectly here. Right? So it's a little bit intimidating when you look at the genre blueprint because it's like economics. It's like the marketplace, it's a little bit hard to consider that we could actually get a handle on something so difficult. It's a hyper object and that's why I believe that the genre blueprint is really revolutionary, because now we can actually get a picture of very big things. It's like when microscopes were invented, and they discovered little cells, it's the same thing for storytelling in the blueprint and the same thing. With narrative path in the same thing for the infographic. So we're creating technology that enables us to see stories at these really high levels, which is extraordinary. Okay, so that's the blueprint that I went over yesterday.

Now what's interesting is down here and four, five and six, we go into the categorical, right? So the categorical levels are easier for us to understand than these ones. We can understand these but it takes a lot of a lot of work, right.

And it's we have to do a lot of thinking and investigating because they're conceptual and abstract. These are more easy to follow. And this is why people love these. And what we have here is the analog ghost concept is the whole book on one page. Right? That's the full Scout page that we do here at Story Grid. So I can hand you a full Scout page. For a novel and you will go oh my gosh, the whole thing is right here. This is easy. This is great. Right? And then the dialogue goes category is the spreadsheet, right? So the spreadsheet tells us time and scene. So it's a dynamical system. It's snapshots of each scene in time. So we go from scene one to scene x. And so it has a double factor of the space of the scene plus the time constraint.

And and these spreadsheets are great, right? Because then you can just use them as placeholders and go, scene six is what oh, that's when Bilbo has the kind of confrontation with dog. Right? So we don't have to thumb through the book. So those are really good too. Lastly, we've got the trial logos category and this is the 620 forest scene analysis that you guys do in the guild. You're learning this right?

You're learning the bottom, green level of the middle category.

And it's really great because you're able now to get a grip on storytelling at a scene level. And so you can practice at a scene level and correct yourself much more easily than you can writing a whole freaking novel. Right? So this is an optimal grip to train writing the 624 and it's analytical, it's hard, it's not easy. And all the concepts that are in the 624 are all up in here. Right? So I haven't come up I haven't come up with anything new really. I'm just getting it in a better structure and organization.

Okay, in the very bottom, you're going to be familiar with two because these are the smaller codes, the tropes, build scenes, right? And the Beats build the tropes, and the bits build the Beats and all a bit is is the sick a single signal, right? A single input or a single output. So this is the whole schmuck gorilla in nine categories. So if you ever get lost in golf, I don't know what the hell we're doing here. We're talking about 620 fours, you can just refer to this and go okay, we're right about we're at the lower part of the middle.

And this is all all very graspable, this stuff's a little harder. And this stuff, you guys are learning this at great detail in the guilt and I'll tell you what, if you know this stuff, this stuff becomes a lot easier, and this stuff becomes even easier.

So that's the whole schema, the whole story taxonomy that I've invented over seven years. And so you can always find your place when we're talking about levels of analysis using this theoretical taxonomy.

Okay, deep breath. So what happened to the genre system? Right. So yesterday, I talked about six core genres. And people were very concerned because they were saying, Well, what's going on with the five leaf genre clover? Isn't that still good? And it absolutely is, but it's kind of a coarse grained introductory part of a genre.

So it still is vibrant and helpful. But the blueprint is basically going to take its place over the next couple of years. And when I show you why you'll be like, Oh, that makes a lot of sense. So I'm going to move right into how I constructed that thing, that blueprint from these six core genres now.

Okay, so before I do that, I just need to take a giant step back for a second and talk about reality.

Okay, so reality is the natural world, right? So the natural world that we navigate is what's real. Now we, every single one of us have to navigate the natural world by by having a frame.

We have to, like, just think about the way you see right? You see in sort of like a Horizontal Box, just like I'm framed in this in this television screen.

That's the way you frame the world. Okay, so the framing of the world requires out something called a worldview.

And what a worldview is, is the way you believe the world works.

Now, none of us unless you're just born are very good. We don't our worldview is not perfect. Right? It's not even close to perfect.

So what we have in our minds is a worldview. That's kind of a virtual world, right? It's the world in which we think the way the world works. It's our virtual world.

And we need it. It's really important. It's really powerful. It doesn't mean that you're crazy. By having a virtual world you need the virtual world. Why? Because the virtual world interacts with the natural world.

So I came up with these two names.

Reality I call Natalie or Nathaniel and and for short, I just call it NAT. Right, because I don't want to make gendered things anymore, you know. So NAT is the natural world right? So NAT is reality. Right? We all know reality. And Vic, Vic stands for Victor or Victoria. Right? And Vic, once his or her virtual world to get really close to nats world.

That's called our fundamental desire.

And we want our virtual world inside of us to be coherent to us, so that we're not flying off or that we're not hurting ourselves, saying oh, my gosh, oh, my internal world is so ridiculous. I'm out of my mind. What am I thinking? Right? So we want to integrate that internal virtual world so that it's coherent. So that when we need to break it out and re readjust the frame, that we don't freak out about it. We go, oh, this is natural. We got to fix our virtual world because we get to update it's like getting software updates. Right? Well, it's time for a new software update. Nobody freaks out when they get it from Apple. You just, you know, reboot the computer. And there you have it, and then you've got a new software system. And it's similar. I mean, computers were built upon our brain structure. So it's a reverse analogy. Okay, so Vic and Natalie want to work together and Vic wants to get close to Natalie and here's the really interesting thing. Natalie really wants to get close to Victor.

So Natalie and Victor communicate on three levels.

We have three channels that enable us to listen to Natalie and Natalie has three channels that she's able to listen to us.

And so I took that, and this is this comes from a lot of deep neural neuroscience research that I've done, so I'm not kind of making it up. This is from Ian McGilchrist, if anybody's interested, is a fantastic scientist who came up with a lot of the things that I'm using now and I'm calling Vic and Natalie. He calls them the right hemisphere and the left hemisphere of your, of your brain.

Anyway, and also Claude Shannon, and the information theory maps onto this too. So basically what we have is a virtual world that governs our behavior, right? Whenever we do something we check in with that virtual Victor in our head, and I call him Victor because Victor Victor wants to be victorious. Right. Victor wants to attain his goal states and so does Victoria.

So it doesn't mean Victor is a bad person because he wants he has gold states. It just means that he wants to attain a communion with Natalie. That's his ultimate desire.

And we've lost this thread over the past couple of 1000 years. So that's ultimately what we like to do is to be in contact with reality as it and as close as we possibly can. So a real great trick to this is just ask yourself, if you're if you're in a committed relationship, and you and somebody says that it's possible that your partner is cheating on you.

Do would you want to know? And most people say yeah, I'd want to know because why? Because I don't want to live in an unreal world. I don't want to pretend that that person is really committed to me, if I know if I can have the understanding that they really aren't.

So this this desire to be locked in with reality is deep, deep, deep within us. It's not you know, nobody wants to live in an unreal world. Because that's insane. Right.

Okay, so, up here is the victors world. It's the virtual world that governs how Victor behaves, and that lives inside of Victor right, that's inside Victor's head.

Down here are the operational systems that Natalie demands Victor do.

So Victor can't live in his head without operating himself in the real world by acting, loving and problem solving.

So, the six core genres are dealing with three channels of the interiority of Victor that govern his behavior and the three exterior channels that he behaves, what he does in the world, and those are the generating functions that generate his behavior.

And these map on to whole, meta and hyper hypo alpha and park and we are stuck in the middle. And we use these three channels on both levels to be able to navigate the world. Alright, so let me get into the genre stuff because I'm sure this is getting a little heady for people, but it's, this is absolutely powerful stuff. Okay. So there's all kinds of stuff that happens in these channels. And we call these channels on the surface green, above the surface red and beyond the surface blue.

So let's start at the blue level, and track where these genres live. So the genres are little story patterns that help us solve the problem space of these particular levels of life.

So when we have a problem with our with our virtual world, if we read a really great maturation story, or Revelation story or education story, it helps us break our frame right? So these genres are locked into these three channels, and they enable us to help us solve problems that we haven't faced yet, or ones that keep hounding us. That's the function of story, by the way, is to help us get a better grip on reality, to solve problems in our own lives, so that we can commune with Natalie better. Alright, so at the very top we've got something that I call virtue association. So the virtues come from Plato, the good, the true and the beautiful are the virtues. Right. So beyond the surface is all about truth and falsity. Right, we want a true relationship with Natalie. Not a false one. Right? So that's really where the virtue sits for worldview. Am I being more true to reality or more false to reality?

And this is the whole right. When we think of our worldview, it's it's everything that we think and so when it gets poked at it's very tricky because it's helping us get through life. Okay, so it'd be opponent process that we want to manage here is realization of reality, versus D realization. D realization means that you're mistaken about reality. And your D realizing, instead of realizing, and this is a psychological term, I just didn't make this up. So people who D realize are having trouble with their sanity.

Right. So D realization, we want to move away from that and we want to get an optimal place between fully realized now if we're fully realized with Natalie, we're dead, right? Because then we're just part of Natalie again. So we don't want to fully realize our relationship with Natalie or we're debt.

So and we don't want to fully D realize or then we're insane. So we need to find this optimal place where we're can do both okay. So what about these genres?

We've got the worldview genre we've got

in general, now there's, there's a Trinity underneath worldview.

What does that mean? Okay. There are there are three ways in which we relate to the world, right? We relate to ourselves. We relate to the other, other people and other things. And then we also relate to AV, the numinous, the cosmos itself, Natalie.

So those are three tracks, right? And in terms of sort of theories, this is a good one. So you know, networks like computer networks. I'm a node. I'm one computer in it, a very vast sea of a network of computers. That's called the Internet. And you are to each of your computers is a node in a network.

And that network is called the Internet. So we've got nodes. And then we've got groups of nodes called networks. And then we've got the network of all networks. That's the numinous. So we only have three things that we really need to deal with. They're hard. But there's only three conceptual concepts that we have to deal with in this world. We have to deal with our node ourselves.

We have to deal with networks, our network at work, our network at the playground, our network, playing on the soccer team, our network at Story Grid, right? So we have all these little networks and we're nodes in those networks. So we have to deal with those relationships. We have to deal with the relationship with ourselves. And then ultimately we have to confront the network of networks. Why am I going to die? What's this all about? Anyway, right, that's dealing with the network of networks.

So worldview is a very deep concept. So worldview has three levels. of story, right? I was talking about this a little yesterday. So when you're dealing with a transformation of a single node, then you're talking about like a maturation story. Right? So to get To Kill a Mockingbird is a story of a little girl who has to grow up.

Right? She has to see the complexities of the world in a much larger way. So we watch as Scout grows up and she sees the way the world really works.

Right so at the end of the story, we say, ah, core scout.

Now she sees how things really are.

Right, but the network doesn't really change. Despite all the hard work that her father does, does to try to change that network. It doesn't really change, but Scout changes.

And Scout at the end of the story, we say to ourselves, oh, it's going to be okay. Because Scout sees the truth about how horrible this network is, and she's going to fix it. So that's about the transformation of a single node. Right. What about a society story? That's a transformation of an entire network. So Ragtime is about transformations of tiny little nodes. That critically fire a transformation of an entire network.

Now we got an even bigger one. And these are called religious mythos stories. And these are difficult to talk about because a lot of us are very, very tied to them. And they're very meaningful, but they're talking about the nature of Natalie herself.

These are religious stories, and mythos.

So these are big things. And here's here's the strange like a lot of stories.

Use that mythos. To tell a smaller story like Cool Hand Luke is a religious mythos story.

And in some ways, so is Harry Potter.

And it depends on how you're framing and looking at the story. So you see how powerful this this this thing that I created can be because it gives you a lens to start looking at the network of all networks, and how that's being characterized and shown in stories. So this trinity sits under worldview.

And we've gotten to Trinity under each of the six core genres. So we actually have like 18 genres, and they're divided by node, network and network of networks. So you can very clearly when you get stuck you go, Wait a minute, how am I feeling about this story? Am I really transformed by how the entire society changed? Yes, but then that's probably a society story, or am I transformed by how a single node changed? Oh, then it's probably you know, a worldview built in shock story, which is just German for worldview.

Okay, so that's worldview. And I'm not going to go through these other columns, but I'll just quickly sort of go through a couple of things. Just so that you can see how these map deeply deeply into a whole slew of categories, right. So if anybody's heard of the Five trait personalities, right, I actually think there's six. And I think that there's six universal values instead of five that Jonathan Haidt puts forward. But, so, let's talk about universal values. Jonathan Haidt, he has a moral foundations theoretical framework, and you can look that up on the internet and it's pretty good. It's really It's empirically founded, right? It's based on its lexical. Anyway. So we all have a thing where we we think things are sacred, and then we think other things are profane. Right, so these are like purity codes. That's gross. Like, where do we get that?

Why is that gross? I don't know. It just is right. So sacred and profane. are a universal value for all cultures, all people so this isn't just Americans. This is everyone right?

All right. So sacred profane, is the world in which worldview lives? How do I live more sacredly instead of profanely.

So to be more sacred means you have closer ties to Natalie.

To be profane means you're not really connected to Natalie anymore. That's profane. You're not working and flowing in Natalie's world. Okay. And this is about wisdom and foolishness. The wise person knows that the proper relationship with Natalie is sacred.

And so they work towards getting more truth out of life, to get a better connection to Natalie to understand Natalie, for who she is not who we want her to be. Natalie is uncertain Natalie doesn't talk to us all that often. She only communicates through these three channels. And it's up to us about how we're going to interpret her. Okay, so wisdom and foolishness aligns with sacred and profane, and well how do we know where people sit in the sacred and profane? Well, we also have this this gradient of neuroticism, and pen glossy aneurysm. Those are kind of my terms. But neuroticism means that we're constantly you know, looking for stimuli, and novel novelty. Because we want to settle things and we're we're constantly looking for the next thing that's going to ruin our day. That's being a little neurotic. It just means that you're you're salience, tagging a lot of things as possible, disturbances to your life.

And Panglossian is like, you don't care about anything. Right? So you're just super focused on whatever it is that I want. Yeah, you see people go into coffee shops like this all the time, right? They're just like I'm gonna get my coffee. And they're not noticing that there are other people, right? So the world view is either tightly focused and pan glossy and everything is going to be great. And all I need to do is to get what I want. Or it's super neurotic. I don't know what to do here because there's so much information I can't It's overwhelming. So there's the gradient, right. And all of us are on that gradient somewhere. And it's also context dependent. Sometimes we're Panglossian and sometimes we're a little bit neurotic. It's not an all or nothing. Idea. None of these things are their gradients.

So you can see trait behaviors, then if you're creating an avatar, and you want to show that they are sort of losing their frame. They're either going to be closer to Panglossian if you want to do that are closer to neurotic. So these these concepts enable you to think about how to show behaviors to reflect how people are handling these six dimensions of life

so that's that's worldview very conceptually.

And I'm just gonna run through a few more of these I don't want to get you're gonna all going to have access to this and I'm constantly tweaking it. So it's it's a very fluid document, but it's all locked in right now. I'm just tweaking some of the language.

So what about morality? What's that all about? Morality is about your heroic journey.

Right? Morality is about how you are processing how you navigate the world. So there are three sub genres of morality and the node self one is heroic journey 2.0. And that's when a person has to sacrifice in order to better you know, you, you have to individuate and then participate in such a way that it increases the probability of the continuance of everything.

It's very moral, right? It's kind of the question you have to ask yourself is if you die tomorrow, would you want anything on earth to remain after you're gone?

And I think all of us would say sure, I'd like a lot of stuff to stay here after I'm gone. There are a lot of people and a lot of things I care about. I'd like you know, the Metropolitan Museum of Art to stay here while after I'm gone, right. So all these people who say that there's no meaning in the world are out of their minds. Because what they would say is when you ask them the question, Would you like anything to remain after you die? They would go no, I want it all burned to the ground. I don't want a single ash of life left on the planet, because it's all meaningless. So after I'm dead, I don't care. Just blow it all.

I don't think many people would say that.

But that's the whole nihilism game. So it's not really worth your attention because it's absurd.

Okay, so that's what heroic journey 2.0 is about. It's about the creation of more, not the destruction of everything.

It's the creation of something versus the destruction of everything.

And so it can operate on the self. When the hero rises, that's a very self kind of, you know, Marvel Universe kind of story. And then you have when the self rises, the network can become more heroic.

So Spartacus. I am Spartacus. I am Spartacus. Right. So this the Spartan has myth enabled a network to get stronger.

The Thermopolis story is about a network of heroic action.

And then the network of network would be sort of a processional mythos. Which would mean it's these aren't very good names yet. But the Western Eastern story like the Western is about the rise of the individual versus the collective. How do we manage nodes in a network? Do we control the nodes and don't give them any freedom? Or do we let them do whatever the hell they want? It's kind of like I'm not sure you gotta get a right balance, right.

And the precessional mythos is very much about the heroic journey 2.0 in time. So, the Iliad, the Odyssey, these are permanent processional mythos stories about how to navigate your life.

So they're in in through time.

Now, what about Status? Status has three two, the first one is performance. So a story like whiplash? You know, you got a young kid who's trying to mature and he wants to perform and raise his status to be a great jazz drummer. That's a performance story. Crime is about network.

Right? Crime is all about who is playing properly in the game and who isn't and how are we going to punish the ones who aren't playing properly? How do we judge that? That's crime. So the status of the network is in question. If we let people run around doing whatever the hell they want, they're going to destroy the network. So how do we get them back in line who judges right? That's crime. Thriller is really, really intense, because this is about a confrontation of an individual node with the network of networks, damnation, or transcendence is on the table for that one. So their status rises from one of the corrupt to a redeemer, or redemption story.

So it's really about the redemption of the universe through the redemption of one node. And you can have thrillers that are our multinational thrillers like all like that. That thing with the meteor don't look up or whatever.

So that status, what about action? Action is a little bit easier. So node action is survival. One node network would be a war story.

The platoon are they going to make it is the army going to make it and then the Epic is like, The Hobbit right? So the no transforms and the no transforms the network the doors change, right?

And then because the doors change the network of networks is saved.

So it's this beautiful movement from the bottom all the way to the top, and you've got the kind of a schlubby guy who ends up saving the world.

That's that's an epic action story.

Love. Okay, love is tricky, but not really. Okay, so the first one is notes that's all about coming to love oneself, to enable and disable properties within oneself, to get in good relationship with yourself.

Right having mercy and judgment in the proper balance, having mercy for yourself when you want to have an ice cream sundae. Every now and then that's good. That's fine.

And judging yourself, like you know what, you've had seven ice cream sundaes in a row. Maybe it's time to stop the ice cream sundae binge, right? So that self love is to get into a nice coherent system so that you're able to love yourself and be able to enable and disable yourself so that you can attain your goal states and have self respect, right? All right, the second one, the second party is when you extend that love to another. That would be romantic love or like a buddy comedy, right? Like a cop buddy thing. Those are those stories are about love. Those are love stories, where the partners come together and fall in love with each other not sexually or romantically, but they love each other that is in such a way that they will sacrifice their life for the other. They enable and disable each other so that they can navigate the world in a better way. Lastly, is is the Gothic vs nihilism mythos kind of love story. This is explaining to people that love is the only thing that's going to save us.

Right or God Bay is the co creation of more newness with Natalie. So Victor and Natalie have to work together to make sure that Natalie doesn't reboot.

Because Natalie could reboot the system and all this will have to start over again. If we have to wait 13 point 7 billion more years for Natalie to get us back online. And maybe we'll change our ways by that.

So Agave is the co creation of the universe with nature.

Lastly, we have horror horror can be tricky because people associate are with you know stabbing and Freddy Krueger and everything and there are elements of that to it. But those are more in this sort. of action thriller. You know, facing the monster kind of thing. Actual horror horror is about problem solving.

Is your problem solving. Good. Are you able to is it stable? Can it be upgraded? Can it become more plastic? Can you live with intellectual patience? Because it takes a while to fix problem solving stuff. It's going to take all of us a long time to get a get a handle on a lot of these difficult concepts. So we need to be intellectually patient with ourselves if we don't get it in one lecture. Right? So this is about the loss or gain of sanity, the node losing losing your mind. Right. So psychological stories about people losing their their grip on reality are really horrifying. Those are the heart when you can't, when you're when you're trying to solve a problem. It's intractable. What do you do is the question.

Do you cool your jets and go I'm just going to take a deep breath here. I don't know how to solve this yet. But after I have a cup of tea, I'm going to go back at it and explore some more and see if I can figure out how to fix this. Or do you go Holy shit, I'm never going to solve this problem ever again and I'm going to run away. That's hard.

And what happens is that the more nodes who are horrified by certain things and don't want to deal with them, that network becomes insane.

So the network if the network goes curve fluey and the network's crazy the only way the network is going to change from insane to sane is nodal transformation. The nodes in the network have to get back on line and fix that network. Or we're all going to be like lemmings running off the cliff.

Lastly, is the loss of universal sanity.

And that's really horrifying.

That would be like The Truman Show.

When you discover that everything is a simulation, and you've been played for a sucker by some other intelligent creature for their entertainment.

That would be horrifying.

And so these are all of the genres and they're all across these, these six dimensions. And the more we get in tune with these and then these all have affiliations, right. So let me just tell you what I added from from the I added the charismatic opacity, so we are attracted to charismatic figures, shiny things, right there called strange attractors in network theory.

So shininess is a universal of our species.

When we walk into a room, there are certain figures who shine that's a universal and this is this locks into morality.

And then also there are ethereal things to us, meaning we don't even see them.

So they're kind of in the background.

It's like my concept of the Invisible Gorilla. That's an ethereal thing.

And then you have an open or closed frame, in terms of being able to pick out the opacity and changing attending to different opacities.

So we can all get lured in by very, very charismatic. Lucifer is an extraordinarily charismatic figure. That's why evil is so attractive. They're usually very, very brilliant, very attractive, and we think they have all the answers it doesn't mean that charismatic figures don't rise who who aren't evil? Of course not. There's plenty of those. But you've got to be careful about how you look at charisma because you can mistake shininess for goodness or beauty that's why put it there. And that's on the morality. And morality is a tension is a moral act as McGilchrist sets. So what we put our attention on is a choice that we are making.

And so if all we do is attend to the evil, then that's what we're gonna get.

So we need to break our frame and attend to other things. Maybe those ethereal things that you're not paying attention to will be very valuable

and so all of these things lock in line into very, very fundamental psychological constructs, philosophical constructs, all kinds of stuff. So that's why this is an upgrade from the five leaf genre clover, because this is higher resolution, right? We see a lot more stuff using this framework than we do with the five leaf genre clover. I love the five leaf genre clover, it's a great introduction. It gives you a very quick, coarse grained understanding of what genre is. But you know, we're here to get better not to just rest on our lawyer laurels. So that's why the genre schema, I devised it, and it's the perfect entry to get the full narrative theory without having to read any Plato or Nietzsche or anything. So I'm going to stop there and take questions. I can stay a little bit longer. I know I went long today, but I just wanted to frame this for everyone so that they can take a deep breath and say, Okay, I see there's nine levels of analysis. This thing is teaching and starting in a couple of weeks, that's on the third level, I'm working on the sixth level, the sixth level is really important. I want to stay there or maybe I want to, you know, do a side project where I survey this class and then that'll help me and, but I don't want anybody to think I'm falling behind. I'm never gonna get this. You're gonna get it. It's very, very structured and organized. I'm very excited about it. It's gonna be revolutionary. It is revolutionary. I think anybody who's been in the guild has seen the right writing improved over over the semesters. So I just wanted to do this to frame everything so that every everyone can to get a sense of the gestalt of the entire system. And obviously, I'm gonna write Story Grid narrative theory, what I call the Story Grid helix, but I'm gonna learn a lot teaching this class, right? So I want to test it and show it and then that will help me I mean, I have a lot written but I want now's the time to test it. Now's the time to share it, because I this is so good. I don't want to just have it sitting on my computer or nobody understanding. Okay, I'm going to stop sharing. And I know Tim you have to leave if if Lesley or Daniel are here, they can pick up okay, I'm going to send some questions your way here. Our first question is from Scott and he would like some clarification on the term output or so he gets the basic energetic flow of input and output, but he's wondering, does the output or is that just the avatar who's the recipient of the of the input or is that someone who must respond to the input with a reaction?

Well, again, yeah, this is an output is comes from cybernetic theory. So inputs and outputs are cybernetic technical terms. There's also other terms like stimulus response, that's, that's a skinner concept in psychology, right? So output response reaction. Those are all outputs of the the avatar. So the output or is the Avatar who is responding to input.

So we Sam, our single Audience Member can't, she needs really close framing. So she's going to put her eyes on the output her right, or the responder or the reactor or the, the, the protagonist of that particular scene or trope?

Right. So it's, it's, you know, what we've been doing with Tim in the ED McBain thing is we've been, you know, and this was very difficult to do when you swap and you change protagonists in a scene.

You have to do it very elegantly, because it has to be seamless for Sam and so in the ED McBain seen the output or at the beginning of the short story is the detective and then it transitions in the second trope, I believe, from the detective to the witness and the way it's done is very important, but the important thing to remember is that the output or is always controlling the energy transfers to Sam.

So whenever you get stuck, just say who's doing what who's changing the value, who's moving the ball forward, that's my protagonist, they need to be in the output as chair meaning they need to be the responder or or the reactor right they they can react by breaking down, freezing running away or you guys know all those terms. So I hope that clarifies it. One of the tricky things for me is that I used I've been using terminology as metaphor to enable people to be able to grok these concepts. So they're all very parallel construction. So BF Skinner was talking about the same thing that Norbert Wiener was talking about, and that was talking about the same thing that Plato's talking about. And Claude Shannon and so sometimes the language gets it's it's a language game sometimes. It's like a tower of Babel. Because different levels of analysis have different terminology. And that's why we're so weird about being very strict about talking about avatars as opposed to characters. Because character is an Aristotelian idea about your your your landscape of virtue. How well you manage the good, the true and the beautiful. So it's not about what you are enacting in the world so much as it is your your worldview in some way. So I'll stop on that. I hope that was helpful.

Okay, great. So the next question is from Pamela. And she said, Is it possible to have more than one content genre in a story? So I think about this question is separate from the core genres that you talk about now, and to focus on like, what's the what's the global genre and and in that right question, yep. Okay, so here's the situation.

You pick one global genre out of the six.

Okay. So once you pick it, you got to stick with so talkin picked the epic action story. That's his global genre, and everything that he does, using the other five core genres is framed through that global genre. You cannot have more than one why? Because you are going to get schizophrenic writing the story and you will be so noisy that Sam isn't going to understand what's going on.

So once you settle, you got to lock it and load it and it's going to be difficult because you're going to want to quit and you go oh, I know. I just had this great insight. I'm not really writing an action story. I'm writing a worldview story. And I'm not going to change any of my words. I'm just going to make that twist in my mind and then I'll be fine. Nananananana that won't work. Why? Because the 20 skeletal scenes have to be locked depending upon your global genre, and the nuances of them come from the other five. So how you execute a particular one of those skeletal scenes can be nuanced using the other ones. But but it still has to be life and death stakes.

So Bilbo can be in life and death jeopardy when he plays an intellectual game with Gollum. And we get to see how he problem solves in a horrific instantiation right Bilbo is at the bottom of health and he has to win a verbal intellectual match with a genius. How's he gonna handle it? Life and death is on the table. But now we get to see how smart this little hobbit really is.

So we've got the global genre covered life and death is on the table. However, we're going to get more out of it by seeing just how this guy handles horror. Now, if that had happened at the very beginning of the book, Gollum would have killed and eaten.

But because it was right at the perfect place. After Bilbo solve some problems, he's confident he's gotten his stuff back. He's not freaking out anymore. He's not. He's taking a deep breath. He's thinking it through. He comes up with the right, you know, riddles. So that's what I mean. You gotta lock on one global genre. And yes, there are five other ones but they are useful in nuancing the global AI Yeah. And it's really it's really going to come. It's going to be like this when you know, after after you were after I lay out these 300 data points. I've done it already. It's it's remarkably coherent.

Great, okay. So this is similar question. But it's, it's more about how do we decide which genre is the most prevalent in a story we're studying, for example, in The Hunger Games, JAYLEE is noticing that there are there are more moral dilemmas that feel like morality, but she's also dealing with a worldview shift. And obviously, there's the action component there as well. So how do you decide which genre comes out on top when you're analyzing? Okay, so if you have time, watch what I did yesterday. And you start, you start going, you're gonna start trusting your gut, your coarse grain curb appeal of the story. Here's the clue. The Hunger Games.

Is that a life and death problem? If you're hungry, can you survive very well?

So who starves first is the game? So does that give you a clue about what the globe was already is? Yes, of course. There's worldview horror, all that stuff that I talked about in the story. That's why it's masterwork as far as I'm concerned. And that's how you start to begin to trust yourself as a as a story person.

Because once you're able to coarse grain from your reactions to the story, how you hear, feel and see the story. It's going to be clear to you, but marketing, I mean, this was my job. I had to come up with titles that told people what the story was before they read it.

So I came up with a title called La Requiem.

That's a story about life and death, and the death of a node and network.

The death of a city. How does that happen? It's a crime story. So when you hear the title la Requiem, wow. It gives you a core screen sensibility. So the Hunger Games is a clue and then usually, the stories that are our Masterworks have very good titles, Moby decks a little bit tricky but not really sure what that's about. But so that's really how you have to do it. You have to get comfortable just taking in the information that signals the patterns and forms and asking yourself what is dominating here. Is this about love? No, not really. There's love here. There's the Romans in here. Is this about morality? Yes and no. It's really about survival. Oh, survival. That's action. Okay, now I'm okay.

What about whiplash? Oh, boy. Is it about maturing? Yes. Is it about love? Yeah. Remember, he breaks up with his girlfriend in there? Is it about status? Yes. That's really what it's about. He wants to be Buddy Rich. He wants to be the greatest drummer ever. What? What's that about status?

The ending of the movie is beautiful, because it hammers home status, heat for all that hell that guy put him through. He held the same value structure.

And he followed the drummer at the end of the movie, after he tried to destroy him, because he held the same virtue, the beauty of performance, performance story in the status. So these are the things that this system is going to enable you to do you will get a series of questions that you'll be able to ask yourself and say well, how is it which one is dominating here?

Ragtime society, worldview society. Definitely.

It's Patton What's that? Oh, that's war.

Anyway, so I this is like a practice thing. You keep doing it. You run these questions through your mind and you're, you're gonna get the answers vary. You know, the more you do it, the easier it'll be and when you're talking to your friends and Story Grid, you'll all be like, oh, yeah, that's definitely not and it won't be squishy anymore.

Right. Okay, so our next question is from Nikos and he's struggling with the art. The way we describe things as blue, red and green. Because, for example, sometimes red is the communication layer of the 624. And sometimes it's avatar thoughts. And so we use these terms in different levels of analysis. And so he's trying to find his way through that, through those descriptions to make sense of them for himself.

Well, these are the kinds of things that once they lock, they're gonna lock forever. For you. I did come up with a metaphor recently that I'm going to be rolling out which I think can be helpful.

These three levels, as I described are sensory receptors within every human being Okay, so we've got kind of three channels. And the primary senses that that are operating here are the green is hearing.

Are you hearing the qualifications? Are you hearing the voice of the author? So when you're tuning into the to the melody, harmony and rhythm of the storyteller, you're you're you're tuning into the green zone, right? Okay, what about the red zone? The red zone is about your feeling it's a limbic response. So when you're reading a story, and you're like, I hate that son of a bitch, that character is the I want to I can't wait for them to die, right? Whoa, wow. Now you're in the red zone. You're feeling the the movement of the story in your bones.

And that's you're processing the story. So information processing is the red zone. It's your brilliant mind being able to pick up on signals and turn them into patterns.

So that character keeps saying that shit all the time. I hate that kind of undermining piece of shit, right? That's taking the signal and taking it up a level into the pattern. Lastly, blue is about seeing and when you're in a really great story, you start like my wife said this to me the other day, we drove through her old neighborhood when she was a little girl and she said, Oh, I just noticed this is this is how I see all my favorite stories. There is the library that's from my childhood. There's the corner store, there's the and so when you can start seeing and mapping forms in your mind, then you're operating on the blue level.

So hearing feeling and seeing are the if they're like, and we use red, green and blue for a reason. Right. Those are the three colors that build up all the millions of color.

That's that's a sight concept. But um, and so seeing his blue feeling is red and hearing his green and when you get stuck, go I don't know what level I am. I go what how are you taking in the story? Are you hearing the narration?

Are you liking the language? Are you liking the voice? Or are you feeling love or hatred for characters? Or are you actually seeing in your mind's eye? These characters or these avatars interacting?

post in the chat I wonder if this maps onto the train brain so the reptilian limbic system and and the neocortex Do you think that's a good fit or is that not quite I'm, I used to I used to like the metaphor of the triune brain but I don't anymore because I think it's it's been superseded by the hemispheric and information theoretic concepts of the brain. And all that means is that there was sort of like this phylogenetic thing that oh, well, our primitive self has this reactionary part and it's the reptilian brain and it's we got to keep that motherfucker under control, you know?

Excuse my feelings, which and so it has, it has these other levels to it. But generally, yeah, your reptilian brain is your autonomic nervous system. The limbic system are your guts, you know your gut reactions. And then the neocortex is your propositional system that logically processes information into categorical strep representations, that then you conceptually manipulate in your mind through simulation to come up with some sort of choice portfolio about what the hell to do. But generally, I steer clear the triune brain thing I think it's a little bit coarse now. It was good. It was good for a while but I think people take it too literally and think they have a knot you but you know, I remember telling my little boy about and he's like, Well, I'm going to have a reptile. In my head. I'm like, no, no.

Sometimes yeah, sometimes, right.

Okay, and then a question about the concepts that you were that you presented earlier today. And essentially what do we what's the goal there? Right. It's, we're not applying it. Are we or are we applying it to our writing right away? Or is this more about building our understanding of story? Great, great question. Totally just building your understanding of story. You're not going to be rolling out any of this stuff. At this time. You're learning from the bottom how to write scenes. That's all you need to concentrate on. But this will enable you when the time is right, to be able to start thinking in holes instead of parts. So the whole the best optimal grip on the wholeness of of story is your right. Probably a lot of you were attracted to Story Grid because of the genre concepts, because they're grippable in your mind, because we all experienced Jarrah right. So these are very, very high level explanations and descriptions of how stories work in a long form of multiple scenes. So you know if it's too much too soon now totally cool. But it would be helpful, I think, because they will, this stuff will leak into you conceptually. And then they will enable you to to fine tune your tropes and your Beats. Because you're like, Oh, this is kind of he's breaking down. His mind is breaking down. Oh, maybe he should be, you know, going back to his neuroticism and then you can do a trope where they execute a neurotic behavior. And then that signals to Sam Oh, we got a worldview. frame problem here. But all that said, you know, baby steps if necessary. If this is interesting, and you you would like to know more about this stuff. The hobbits have very simple, beautiful, wonderful book and the worst that's going to happen is you'll have an amazing understanding of it. And of these genres, dramatically at the app, so the purpose is to train to to to get you a better understanding of story. how practical it is at this point. it's not that practical for you right now. But but it's indispensable in the future.

Okay, wonderful. I we don't have any more questions, but there's a lot lots of appreciation in the comments for your responses. And for the material today. So, so thank you for all of that, Shawn, and thank you everyone for your questions and showing up and listening to the recording, and we will see you next week.
