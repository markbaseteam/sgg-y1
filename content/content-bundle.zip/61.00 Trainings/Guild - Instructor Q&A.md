---
status:
type: Q&A
tags:
source:
---

# Guild - Instructor Q&A

> ## Excerpt
> Wed, Oct 26, 2022 3:00 PM; Duration: Live

---

wanted to get us in here and then we can the CO hosts

Now to find my forum tab, there we go. Oh, and I might start out by talking about Victoria's question that Tim talked about from last time it's inciting incident as wave or particle. Okay, sure. Yeah. Just because that was that was coming from the questions for Sean.

All right. So we let them in.

Hello, everyone and welcome to this month's instructor q&a. So good to see all of you. Thanks so much for attending and for submitting your questions. We have a lot of stuff to go through today. And we're looking forward to a useful and lively discussion, hopefully. So to start out, let's talk about a question that we actually had in Sean's q&a. But because it was specific to the masterwork scene, we put it on our list to get to later.

So this was coming from Victoria.

In semester two, the concept of the inciting incident being targeted and reaching the protagonist behaving as a particle versus an inciting incident not explicitly targeted at the protagonist. But reaching them through some intermediate steps was introduced.

It seems like that kind of analysis could be useful with the aeronauts windless where the scene protagonist Captain grim seems to take a backseat, while the ship and the crew seem to be the avatars in charge of the outputs.

And so journeyman takes an action and the ship reacts Is this an example of a particle wave example? That could lead to different analyses depending on how each one sees it? And the example is, grim stood firm as journeyman cut the power to lifts crystal suspension ring and Predator dropped from the skyline of stone. Okay.

this is in the question thread for, for the questions from John from last time, so it's in the forum. And so if you want to follow along there, that is fine, but we're just going to talk about this in general principles.

You know, I would say the inciting incident of the scene is the

as as you know, when the shots fail to land and they find out that the shroud is that.

So this is what throws them off balance, they realized that their attack is not going correctly.

And what this is, is that in the scene, they're finding out that what they thought was a chance encounter is actually a targeted particle because they're being hunted by the orange ship. So at the same level, that's what's going on. Now in this specific example, and I think this goes to examples more broadly, as you'll see in the beat breakdown document that's available in week six.

It's not that it's not that Grimm is ever taking a backseat. And I think it's easy to think that especially if we try to break Beats down to granularly. But if you do something and something follows from it in a very clear cause and effect kind of way, then that thing is really an extension. Of your action.

there's no mechanism for pushback. So if I say to someone, you know, hey, will you go run this errand? For me? There's a possibility that person is going to say no, right? There could be Miss attunement. They could yell at me for even asking me there are all these things that they could do.

But if I push a rock off a cliff, that rock is gonna fall.

And so when I put my agency into the rock, the rock then moves, the rock does its thing.

That rock is acting with my agency, not with its agency. And it's aided by what I can predict all of the physical actions, things like that. But it's not going to be like, sorry, Daniel. I don't fall off of cliffs, you know, it's not going to come back and act that way. And this is a little bit of a dicey arena here because we are talking about the people on the ship, but in this specific context, the people on Grimm ship, the crew have ceded their agency to him for the duration of this battle. So they are acting as extensions of his agency. That's not a given. But when we see them act in an attuned way, when I say I, as grim now, when I say, hey, the power and journeyman says, he might not even say anything, he might just do it. He's acting as an extension of my agency. And so Grimm is really acting. He's pulling all of the strings, right? That's something that we see a lot in this in this novel, is the, the imagery of the puppet master.

And Grimm is pulling strings to the differences that the, the actors on the ends of grim strings have agreed to be there.

And they are they're happy to be there. They're being enabled. They're all going toward a common goal. And they could leave those strings at any time. Where's Kevin dishes strings in the puppet master strings. There are no choices involved. And so I think that because

because we're used to seeing scenes that are broken up very finely. It seems like every time something does something and something reacts to it, then that's an input output. But that's not necessarily true. When those things are acting in concert. So So for this, look at those bigger chunks, but for creating these Beats, think about it as the whole crew acting as a unit.

You have other thoughts on that Leslie?

Now, really, the only other thing that I was thinking of as you were talking was that is that if Graham we're using a tool, right, then the tool doesn't have independent agency. And as you say, it is very tricky to talk about this in the context because we're talking about those avatars that do have agency but as you say, they in this situation, they are governed by a pact or a an agreement that they made before this, and because of the nature of this battle.

It's not like we've talked about it's not a melee right. So so we have a very different situation where the individuals need to work together. And they have made that agreement. So yeah, absolutely. I have nothing else to add things and you know, I think also it's, um, you know, I like my counterfactuals.

And it could be that there's a crew that is divided, and they and they have Miss attuned responses.

That would be a different problem we're exploring. So then it wouldn't be about the problem of how do we deal with the Iranians. It's the problem of how do you keep keep a crew together? That is going back on the agreement that they've made, you know, whoever's breaking it sometimes the captain breaks it. Sometimes the crew breaks that. But that breach of sometimes actual contract sometimes social contract or or understanding that would be at issue there. It's when that group starts to fracture from the inside. Sometimes we'll see that in quadrant three.

Not in this book, because that's not what this book is about. But sometimes we'll see like a fellowship start to fall apart.

And I saw in the chat, thanks, Victoria, for letting us know that that was helpful. I'm really glad that it helped you to understand what we're looking at there.

So let's go into our questions for instructors thread.

Okay, so the first one that we have is a question about the pop and about the on the surface goal.

Or the aeronauts windlass preserving predator and its crew.

Okay, so we have some we have a question about Shouldn't it be making money and preserve predator in its crew, because that's the initial goal. So

a few things are going on here, you know, one anytime that you are defining a goal and you have and in there, you have gone astray, because it needs to be a unified pursuit.

So anytime that you have and what's going to happen, it may not happen in the scene may not happen today may not happen tomorrow, but it'll happen soon. Is that those goals will come into conflict.

And then what will you do?

So now we're getting more into a trade off space. And that is an indicator. That that's not it's not going to work in the way that we need a goal to work because the goal needs to be a single factor pursuit that we can evaluate in the context of the double factor problem.

So that's the first issue there also.

When we talk about I would say like, generally when we have make money in there, Grimm doesn't care about making money as an end in itself. He only cares as about making money insofar as it helps his men survive, right? He's not Oh, my bank account is gonna go down this month. He says, These guys might not eat, you know, these guys are going to be unhappy. They're not going to have what they need to survive. And that's the problem. So money is instrumental to Grimm and what's it instrumental for it's instrumental for how he treats his crew, which is all about preservation.

So in general, Grimm does care about preservation of the predator and her crew.

And the question at the root of this, the underlying question is, how can you preserve in an attack?

Maybe sometimes you've heard the statement like the best defense is a good offense. And in some cases, that's true. Right? So you can attack to preserve by making sure that you have the upper hand in the situation. It's also about time signatures, right. So if Grimm stays in a bubble, and he never attacks, they don't get destroyed through an attack, but they starve.

And so longer term, he's undermining the preservation of predator through prioritizing short term safety through always hiding or you know, going into a different line of business the predator dissolves.

Right then it is no longer an entity.

And so preservation here is not just about physical safety, but it's this bigger concept about survival as a concept survival as a group and thriving even. And so, so that's one side of it. And then the other side of it is that within this scene, the failure of the attack is the inciting incident. And the goal is created or crystallized when the inciting incident happens. And so even if all of that stuff is not true, what you're recognizing in the question is that when the inciting incident happens, preserve predator and her crew comes online in the way that you understand it, and that means that it's an effective goal for the scene because it's functioning from the time of the inciting incident forward.

I think one of the ways that this gets confused is that we as people in our daily lives, we have lots of different goals, lots of different you know, things were trying to balance we have multifactor problems, even so, so, one of the things we're doing with the story in order to illuminate Sam's problem, we focus in and we give avatars a single object, right of that their conscious object that they're pursuing, there's the global object and then there within each scene, there is a an aspect of that, that they are that they are pursuing. And so I think it is easy to get confused about that when we think we've got to make that shift avatars are one one note in this in this context.

Oh, oh, how words are are tricky.

We start exploring these things, but so so when we're talking about goals, they need to be they need to be have a single focus, even though we're used to experiencing the world in a different way. And so then I think the thing is that that the make make money and and preserve predator is a is going to specific.

Right and so that if but if you pull that back a little bit, then you can see how they're consistent in exactly the way that you've explained. But it's a matter of where are kind of at what level are you looking at the goal. If you pull back a little bit, you can see how it how making money is just simply part of preserving creditor and grew.

Okay, sorry. Next question is about point of view as a generator function.

this this question is, is really about the conceptual underpinnings here right about

about why we're calling things certain things, and I would say that the question is, I mean, we can we could go into why it is a generator function, but I think the more salient question is, can you apply it?

You know, Can you can you figure it out like from point of view, can you put words on the page?

And if that's true, then the finer points of why it's called governor or generator.

I think it's, it's not as applicable at this point in the journey to understand the the sources of that, because and this is probably a theme that we'll go back to throughout this q&a.

But the point of the guild is take a masterwork pattern scene and apply it. So if you can take if you if you can say okay, first person, they've told me I need to use first person. So I'm going to pick my avatar who's the first person and I'm going to use my pronouns with them, and I'm going to get inside their head and it's going to and that is not true for this semester. So I should have used a different example. But you know, so they've told me to use third person so I'm not going to use I pronouns. I'm not going to, but that kind of thing, right? If you can take that point of view and you can apply it in your own iteration. That's the goal for this semester.

And so I would say don't worry too much about those categorizations as long as you can take the tool and apply it effectively.

Yeah, I think with you know, it's it's funny because I want to know all the things about all the things right so I understand the urge to, to want to understand it completely. But I think really focusing on what do you need to understand in order to to create, you know, to create that iteration is where you want to focus.

It's, you know, why we, why we do it, and and I think there's, there's there may be a little more to this question than, you know, than just Why do you call it that, but I think if you're understanding that the generator is about how you generate, right, it's how you create that the governing pattern.

That's all that's really required in order to, to, you know, to follow the instruction. So that's just another way of saying what you were saying, but from a different from a more read point of view.

But that, you know, like, what do you need in order to do this? And if you've tried to do it and you get stuck, then that's where you really want to zero in on what's the what's the problem? Why am I struggling with this? And it's probably not about how we're calling it it's probably how you know, in how do i enact this how do I create this pattern? With these with these point of view tools?

But that's a slightly different question.

Great, so the next one is about the potential infodumps so on that one, hang tight. We are going to talk about binding later in the semester. And hopefully the clouds will park and the sunshine will fall on our butt. But when you're thinking about how narration works, or how the how the author is talking directly to Sam, those kinds of things. Those are things that we're going to be talking about in a lot of detail later in the semester. So I want to say if you are new to the gills, and this is your first semester.

I think we run into the same problems that we do when we're writing and doing masterwork study is that we're looking at a final draft. And it's so important to study masterworks, right.

Because they are examples of what we want to do. The problem is we look at them, and all the stuff is on the page, you know, and so it's like, I want to understand everything that's on the page and I want to understand all these different types of Beats. And if we sat you down for longer than we have video, I will set five hours and like sometimes they're no I'm kidding. But you know, we have long videos there at the beginning especially but if we sat you down for an hour video lecture less than we said, okay, here are all of the beat types and all of the Beats subtypes.

I simulate that you would run screaming for the hills because it's just too much so.

So what we're trying to do is walk this line where we give you examples where you can see how these things are functioning in real life because we think in real life and very beautiful good examples.

And we also want to walk that line where conceptually, we're dripping out the kinds of things that you need to look at. So that's why we spend so long with one example. You know, we're spending four months with one scene, and we have counterpoints and contrasting and supporting examples and things like that, but but we're spending four months with this aeronauts windlass scene. Because if we were to give you a different example, every week, then it would be like oh, yeah, I need to know everything in this example, because we're going to move on from it next week. But as we get to each concept, we're going to look at how it applies in the scene. Then we're going to look at how it applies in the scene. So by the end of the four months, you're going to know this scene, backwards, forwards upside down. And you're going to know how all of these concepts work. But you know take it pick it on faith, I think that that as we drip out these concepts, they will make sense. And so and and I also want to recognize that if it's your first semester, you might not know what's coming down the pike. And so, you know, we will get there in time and so so I think it makes sense to be asking these questions, but I'm going to ask you for just a little bit of time so that we can get there and look at it in its proper context.

Yeah, the only thing I want to add to that is that is to is perhaps to to revisit the the training on the point of view, because selective omniscience isn't just the voice of the author, that that's fine not but by an ocular binocular point of view. So you've got the avatars words and thoughts, and it's unlike experiences curated by the author. So, so that's a slight miss. So I think the question as I as I'm reading the question, there's a slight misunderstanding about what that point of view does. And so I wanted to just clarify that.

Yep, absolutely. And the next question that we have coming from Nico's is also about binding. So again, fit tight, we will get there and then we have a question from Daisy about the genres and how we are offering and I want to say and, and as you point out, Daisy it's it's sub genres here.

So the sub genres have a wizard of mercy and the hunger games we've identified a little bit differently than they were on the the roundtable podcast in the past. So I wasn't there. So Leslie, I want to pop it over to you. So that we can we can talk about how these things have evolved how our understanding some evolves over time.

Yeah, I think that you know, when I want to, it's hard for me to go back and recreate the process through which I I made you know, a prediction of what are identified the sub genres in in these two stories. Sometimes that's difficult. I think that

that the difference that I'm seeing now is based on a deeper understanding of what's going on in those stories in the force, the different there are different forces of antagonism. So in any action story, if the only if there's only one force of antagonism, it's not a very deep story, right. So in order to add complexity, we have multiple forces of antagonism. So you do have there are aspects of a labyrinth in both of these stories, but when I look at them again, and I think about well, what's really driving the what's really driving the action right because the antagonist in the story is driving the action. When I look at that, who is creating the other question I ask who is creating the power who or what is creating the power to divide?

Then with time and longer study, I settled on a different force of antagonism as the prime primary one. Now why does this Why is this hard? It's hard because when we read a story, we're picking up on various threads for ourselves, right? So I bring my frame to a story whenever I'm looking at it.

And and this goes along with the things like what what Shawn is talking about in the the architecture of a Master Work course, that that is, there are these threads and depending on where we are in our life, depending on what our primary problems are, we're going to the what's salient to us in the moment is really going to be is what's going to pop and that it and so sometimes we can miss read. And I want to be kind to my past self. I was doing the best I could under the circumstances. But I think I misread these two stories. And I think that with the tools refined in the way they are I think with a deeper understanding of how action works, how the forces of antagonism work, that it's just different. So there are conventions, that that belong within each of the sub genres there. There are conventions that are specific to the sub genres. And I just don't see them now in the same way that I saw them before, and that they're not centerstage the way that a labyrinth is more like a more pure labyrinth plot would be The Wonderful Wizard of Oz.

But we can see the labyrinth you know the aspects of the labyrinth in both wizard of Earth see, and and the Hunger Games it's just not the primary force of antagonism and that's where we want to put that. That's how we identified the sub genre.

as he said, there are labyrinthine components that we can identify in all action throws because they're having to navigate a new environment and and all of that and so, the labyrinthine component is there I would say for me, when I look at is the labyrinth acting as an antagonist.

The question is, is so how does the labyrinth fight, right? It fights by trapping you so in the traditional labyrinth, I would say like from from Greek mythology, the problem is actually the Minotaur. Right? So the problem is like, even the labyrinth is maybe really about the monster.

But in a true labyrinth, it's about might you get stuck.

And that's the thing about the Wizard of Oz is she might get stuck. Whereas like Katniss, she's not going to get stuck, right one way or the other. The Hunger Games is going to end. Whether it ends with her death or her victory. And so, so I think, for me, it's about separating out whether it is a feature of the environment or as you're saying lessly an actual primary force of antagonism that is operating in that way.

All right. So we have a question about the five commandments next very exciting.

You all know I love talking about the five commandments.

So the question is, where does the value shift? Does it shift at the turning point at the climax? In the resolution can happen at any of the above?

So here's the way that I would say it functions because the value shift

let's talk about the purpose of the scene. It's in that scene event synthesis. Right. Do you want to communicate the story event? The story event is this value shift happens when the protagonist does this climax despite the trade off generally speaking, there's the essential tactic component in there that I don't want to forget. But I don't have the formula right in front of me.

But generally speaking, what we're doing is we're saying this kind of value shift happens when this action happens in this context, we're evaluating that kind of a dynamic now.

That value shift, that is part of the controlling idea of the scene, the scene, event synthesis is dramatized over the arc of the five commandments. So all of them are very important, right? The inciting incident poses the question about what kind of value shift are we going to get out of this? And then we go into the later commandments that are at issue in this question. And so all of the commandments play a role in showing and realizing that value shift.

So the turning point, makes it inevitable that there will be a shift in value.

Things cannot continue as they did before.

So this is where the, this is where we reach that point of inevitability. So the inciting incident says maybe there is going to be a value shift. And the turning points is definitely there will be a value shift.

And then the protagonist has to decide what to do about it now. We don't have the full value shift realized at the turning point or else the protagonist wouldn't matter. We need our protagonists to matter.

So the climax is where they exert their agency to try and affect the value shift as much as possible.

Sometimes that means that they inadvertently make it worse. Sometimes it means they make it better. Sometimes it means like in the aeronauts windlass that they mitigate a very bad situation.

And they make it a little less bad than it would otherwise be.

But they're trying they're exerting their agency to effect the direction of the value shifts. Now, without the resolution, we don't know what they did.

Because there could be unintended consequences.

They could have misread the situation, they could have succeeded. There could be complicating factors they don't know about. And so in the resolution, this is where we learn what the climax meant. We learn how the value shift actually played out. And we also learn any information that would modify how we read this value shift in the global context.

And so that's how the progression of the commandments works, to in concert, create the value shift. So it makes sense to me that you're asking this question because it's like I don't see a point where the value shifts. And that's because all of these together, work to create a fully fledged value shift. So it's not going to shift at one point in the scene, even if it's life to death, right and someone dies.

All of the five commandments, it's about it's about modifying what that death means for the story.

Right and so so all of them are working together to create it.

Yeah, I think that is, it becomes even more even clearer if we if we pull back on the global level where the five we have global five commandments. And, and so if the, if the value shifted, and that was done at the turning point, that that would be the about the midpoint of the story. And so and then it would be, then it would be over you know, and then the core event wouldn't be that important. But we know that the core event is the event. Right? And so that's is so so that's obviously that's important, right we don't get we don't get a final result. We don't see how the how the the arena, the environment responds to the protagonists action until we get to the resolution. So I love the way that you're framing this as every commandment is creating is influencing that change in value within the story unit. And then it's we see where it you know, where it settles kind of, at least for the time being, where it settles in the resolution and so thinking about it that way, and then looking at the scene as a whole rather than pulling out a specific trope or a specific moment. I think we do do that, of course when we're you know, when we're identifying the five commandments, but when we're thinking about the value shift I think it's really useful to think about the scene as a whole hold back, look at that what's actually happening and what has shifted on the gradient of value of the the, the global genre, it's really important to you know, to do that and see that because there are there little mini changes happening throughout a scene. And so it's like, what where do you what do you want to capture in your Story Grid spreadsheet? Well, you want to capture what really what's really happening what it means, right?

Because that's what that that beyond the surface value is about meaning what does the change mean for the global story? So that's just another way to approach that.

Yeah, I love that big picture view. And it's like, it occurs to me when you're talking about pulling out those moments.

That yeah, we we do that but then also looking at that bigger picture. You have to realize that every every word that's on the page is in support of building that arc. And so that's why a bridging doesn't work, right. Like you can, you can abridge, and you can get kind of the main flow of the story, but it doesn't create the meaning that having the full story does and so, see I love that perspective on pulling back and looking at its global.

It's the toggle, it's an opponent process, right? So you can you can chop it apart and look at all the individual components. So we do that a lot.

But it's also so valuable to toggle up and look at the at the big picture.

So our next question is coming from Mercy about in your own writing.

Getting lost with Miss attunement and talking about indirect speech internal monologues and things like that. So, you know, I think I would say that when you're applying it to your own writing, and in this question, to answer this question, as it is, I would have to make a lot of assumptions about what this looks like. Now. If you can take one thing away from the gills after what I just said, this might be a little odd but every word right without without seeing the individual words.

I can't know what to tell you here.

And it's actually completely consistent with the you know, looking at both things, but I was like, Oh, we were just talking about the big picture. And now like no, we need individual words, but we do right, because each individual word affects everything. So if we're analyzing a beat, and it is it's looking egoic there can be one word that switches it over. I shouldn't have used that because that's the training that's coming up. Anyway, if it's looking mostly luminary, there can be one word that switches it over to sovereign you know and so that is something where we have to be very careful when we're analyzing Beats and looking at their Miss attunement.

But what I want to talk about is the scope of doing that. So we are editors.

We are instructors. We are teaching you about how to do this and so we have to be very fiddly and finicky. And what we are asking you to do is to write an iteration of a Master Work pattern seen and pay very close attention to every single line. We're asking you to do exercises in your worksheet and write you know one beat at a time and then reflect on it. Talk to your cohort about it. Figure out what's going on there. So there's a lot of really fun to work here.

When you're writing your own work

the muscle memory that you build in the guilt is going to help you to address your own work. And so I would say as you get into your own work, apply that powerful observation selectively. And don't worry if you don't have the full bright light if you can't analyze all of your own Beats 100% of the time. That's okay. You know, you're still learning you're still figuring out what's going on with the guild.

So as long as you can look at it and say did I learn a skill that's going to make my writing more powerful, that is a win. So it's not about if you can't, if you can't analyze 100% of your Beats correctly and make sure that all of them are in the spreadsheet, then you fail. That's not what it is at all. This is about applying in a constrained environment these tools very precisely, so that they teach you those skills for going forward.

So I want to say that because when it comes to applying it to your own writing, we can't it's beyond the scope for us to to help with that. Because we don't know the situation. We're not seeing the draft all of that stuff.

That doesn't mean that you're not making huge progress based on what you've learned, even if it feels imperfect. So I really just want to encourage all of you that you are learning and you and it is making a difference. The fact that you are asking a question about how am i How am I really miss a tuning this means that you're applying it, even if it seems frustrating in the moment. And so trust yourself, that what you learn in this constrained environment is going to come out and it is going to make your writing better. And I know that that's hard because sometimes it seems like the emotional experiences is inverse, where you learn and then it feels a lot worse.

But it's going fine and so in and internal monologues, those are really hard to separate out in the input and output anyway. But that you're thinking about that but you're thinking well what could cause this person to have an internal monologue that puts you miles ahead of a lot of the internal monologues that I've seen out there that are just spontaneous. You know, I'm going to sit and think about this thing for a while now. But needing to have an input to that like that already levels up your internal monologue to something that's more enjoyable to read. And so what I'm seeing in this question are lots of clues that you're thinking about this in the right way.

And as we're coming up, we have one more week of Miss attunement and then we have avatar strategies. And I think that that week, is really where you can start to think about these things. About all of these Miss attunement strategies and think about them in a generative way. So I would encourage you to really focus in on how to use avatar strategies to plan and so basically, what that's going to be is we've been looking at the product and analyzing backward I think of it as backward to figure out you know, what, what is this thing that has shown up on the page, and then avatar strategies, that's where we start thinking about it forward. So when we think about applying it to our own writing, I would say focus on that week and and really get into that generative aspect and understanding your avatars so that you're not really just spinning on each individual line of your story.

Yeah, and I agree with all of that. And then the other thing I would say is that when you're, when you're analyzing your own story, right, you've, you've done whatever planning you're going to do before you start writing, you draft it and then now you're looking at the finished product. Then, what's not a finished product? You're looking at the draft and analyzing it, that you you know, how far down in the, the level of you know, the level of analysis that you're gonna go? Depends on how it's working. Right so if I have a scene that's working, I'm not gonna go in and analyze Miss attunements right? It's only when the scene is not working. Okay, now I'm going to drop down and do tropes, look at the tropes. How are the tropes working? Oh, I see there's a problem here. I'm going to fix that. And then I'm going to, you know, and then I'm going to analyze the scene again. So you don't want it as much as we love analysis. And you know, we do. You don't want to analyze just for the sake of analyzing your own work. It's really about how far do you need to go in order to make it work, and that and I would just for your own health and sanity, I would say don't go no further, because that is the path of pain. But if it's working, then Rock on, well done. Next scene. So that's what I that's my little pep talk on.

And then going down to the next questions that we have.

One from Mercy about beat breakdowns. I think we covered that when we looked at Victoria's question at the beginning, and then we'll is talking about the same thing. We'll also had questions about real time versus durational. And like, where do you

So in general, you're looking at what the core of the output is. And A Beat can convey it can contain within it real time moments, durational moments and all of this stuff. And, you know, we'll as an editor candidate, I realize you're in a little bit of a different place here, because you are asked to do these kinds of spreadsheets.

And so, so that is generally right you you go with the core of it, you go with like what's that core action? So what we talked about earlier, is Grimm is the mover who's creating all of these follow on actions so I would go with grins, action, right.

And so that is the answer, technically to this question. And also, I think that this is a good place for reinforcement of if you are not in that editing space, and you're in that generating space, then just try to find that balance and don't worry too much about like, overall is this going to be this way or this way? But you know, use the use the spectrum of collapse to figure out am I presenting in real time the things that my Sam needs to see?

Am I collapsing the things that she doesn't, those kinds of things and so so you know, again, it's not about perfect analysis, it's about using these things to guide generation. And that's, that's the primary goal, right? So when we are thinking about how to present this material, we try and gear it toward generation so it's the same thing is like grim wants to make money but only so his crew can survive. We want to teach you all to do analysis so that you can write and I think that it is, it's so tempting for me, I know that to just analyze all the time because it's like, hey, the more things I analyze, the fewer words I have to write on the page, right? Because we can stay in the safe analysis space where we're looking at stories, and we're definitely being productive. Right. This is the story that we tell ourselves. And I don't want to say like that these questions are meaning that anyone is not productive or anything like that. These are great questions, and I'm just talking about something that I see that can happen when we study story at this, this intensive a level because I know what happens to me where I'm like, Well, I can't possibly write a story until I do three complete beat level Story Grid spreadsheets. On three masterworks that, you know, and so you you create these learning goals for yourself and keep moving the goalpost.

Right, and it's like, I, I know, this is something that that I could really do, right? It's like, well, I need to be an expert before I write and you don't.

So keep asking questions, keep exploring, and also keep putting them into practice.

And what you'll find is that the more you put them into practice, the more you can discover how these things work in different contexts, and find a more participatory or perspectival answer to your question, because when I tell you well, you know, this is this is real time.

That's a proposition and it's very context specific. And so by exploring you can just really get a feel for how to put those concepts into practice. That's going to be far beyond what I could ever tell you. Because I'm just telling you, you know, giving a fish in this situation and then the more that you explore the sea or when I go down my metaphor paths, and I find myself in this place that like I don't know where I am. I'm in the sea, I guess. But anyway, you like you see all of these fish, and then you understand like what all the fish look like, rather than just getting the one in the aquarium.

Yeah, so I think that was that was everything in that all the technical parts of those questions. Do you have anything you want to talk about there? Listen.

And then we have Okay, discovering.

Okay, and then Mercy's next question, that is also answered by the bundling of that beat into a larger chunk.

And now we have from a hunter Oh, can you elaborate on how to uncover or Discover Double factor problems in our writing?

So let's say that this is one of those things where we have to revisit what the scope of the guilt semester is, and this is really about looking at a specific example and figuring out how to iterate on a double factor problem that we are that we are locking in for you.

And yeah, this is another thing where the ultimate goal is to write a story it's writing original story, it's to generate it's to come up with something that is truly and uniquely your own. And being able to take a locked in double factor problem and iterate it is the first step. Now we do provide some exercises that are stretching for you. And that is looking at the scenes, the other example scenes and doing 620 fours for them. That's going to stretch your understanding and get you to apply these concepts in a new context. That's why we have the masterwork example analysis in our worksheets. And so they're you start to get some examples of what other double factor problems might look like. You start to like you're sitting in one space in one place in this arena of like, what what are double factor problems? And what we're saying is okay, we're sitting at this particular double factor problem. Now let's take a step and see what an adjacent one might be. So you'll notice that we give you these example scenes, and the double factor problems are kind of similar to the ones that we're studying in the main scene. And that's intentional because it helps you to see okay, these are variations on the same now, it may be that you want to write a crime story and your double factor problem is going to look a lot different. And maybe that you want to write a performance story and it's going to look even more different. And so the so we we can't cover all of those and it would be too much to try and give you that download of unit. This is the entire double factor problems face. And so again, what we're doing is we're walking through these examples so that you can start to get an idea of what the different double factor problems look like that are out there and execute on them. And so when you see these examples, and you see how they vary a little bit from one another, you're getting just a small variation. And then as you go through the guild and you take more semesters, you're going to get more variation you're going to see a status love variation from Jane Eyre or a crime variation in the name of rose and start to get an idea of the different types of double factor problems that are out there. Now do three data points make a full understanding? Of course not. But what they do is they start to give you the idea of how to evaluate this. So again, I would say you know, buckle in and hang on because the more that you take into the guild, the more you're going to understand this problem space and the more that you can naturally start to apply it to your own writing. But the way that you learn to apply it in your own writing, is through that sort of broad exposure. To how it works in other masterworks, so, asking about the examples from masterworks, those are the things that you're going to be seeing throughout your worksheets through the the examples in the Guild, and then we also have them on the podcast as well. So when we do the 624 analyses of the things that we're going over for Tim, we talk in depth about these double factor problems, how they're applying and how we get there. And so, so that's what I would say is that when you're working with your own work

that that uncovering your own double factor problem is really beyond the scope of what we're learning in the guild that this is really the first step on a path at the end of which you can do that. But but it is it's a whole thing in itself. So next week, already, we're going to be in Nashville, and Leslie is going to be teaching the narrative path workshop which I'm so so excited for. And that narrative path workshop is going to be about helping to uncover these things about our own writing. And so those are you know, that's that's that place. There's no end point, you know, but it's much farther down the journey, where you are looking at how to create that original point. And so the the methodology of the guild is that we start with iteration of a very specific pattern. We're locked into so many things. And then after you learn a lot about that you can start to break out of the pattern and innovate.

Yeah, this takes me back to to teaching or not teaching watching my kids learn to ride a bike, because the I didn't know that if they had these things. When I was learning this, I didn't know about it, but there are these run bikes, right? And it there are no pedals on them. So because they're just you know, there's just so much to to to manage when you're riding a bike once you know how to do it. It seems very simple, doesn't it? But when you're learning it's really hard in to manage all that stuff and I'm not that coordinated. Anyway, but but but this to me seems like pure genius, you take the pedals off, and then you run so you run with your your feet, and then you kind of coast when you get up a good head of steam. And so that what that does is it enables you to work on the balance which is I don't know if you've ridden a bike, but that's a critical element of that. And so that's part of what we're trying to do here. We want to help you get a feel for double factor problems and the only way to do it is kind of is to do this with the with the with the pedals taken off. Now, I understand the urgency, the the draw to work on your own stuff. Boy, how do you do I get that. So what I would say is, here's a little here's a couple of things to think about. That may help you to develop what really drives you crazy, like what is it that like, oh this thing about the world if it were only fixed, it would, it would make everything so much better. That's where I would start. What are the things that really what keeps you up at night? What kinds of problems what kinds of dilemmas what kinds of things and then like hold back again, right just pulled back. Think about it from a 30,000 foot view, which I know we're not used to doing and if that's not if that's not your mode of thinking it is hard and I don't I don't want to make light of it. But but if you keep imagining yourself pulling back and I'm just seeing this in its seeing the activity in its context, what is it like for a bigger group, for what would it be like if everybody were operating this way? Those kinds of things. Then the other thing is like what kinds of stories appeal to you. Think about all your favorite stories. And then what are those protagonist dealing with?

That's what are their dilemmas? What are their struggles, the things that speak to you, in you know, in these two kind of areas. Will will help you figure out what it is you're interested in. Because the double factor problem that you want to explore is not should not be something that other people are interested in, though you hope they will be of course in your expression on that, but it's really about what what's driving you what's what is what are you interested in? What do you want to illuminate about the world? And and that's where I would start with the with that. So when you're thinking about developing a double factor problem for your own story, start with what makes you crazy and that is a good first step.

That is brilliant and and yes, absolutely. I'm very much looking forward to to exploring that more with you next week.

And you know, as we go forward into future years and semesters and everything like that, and I think it's a perfect place to end the session because you know, we have

We've gone to the top of the hour, so thank you so much everyone for these questions. Sorry for any questions that we didn't get to but you know we have future sessions that we can go over things and hopefully this was helpful. So thanks everyone. It was great to see you and we will see you next time.
