---
aliases:
status: 
created: Thursday, October 6th 2022, 6:18:10 am
tags: Q&A
source: https://store.storygrid.com/guild_pages/october-2022-instructor-qa/
author:
title: September 2022 Instructor Q&A
modified: Sunday, October 23rd 2022, 5:22:05 pm
---

# September 2022 Instructor Q&A

> ## Excerpt
> HomeAboutContactPrivacy PolicyLogin To Your Account

---

# September 2022 Instructor Q&A

<iframe title="20220928_Instructor_QA" src="https://player.vimeo.com/video/757013055?h=de717e0e4a&amp;dnt=1&amp;app_id=122963" width="640" height="360" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen=""></iframe>

# Guild - Instructor Q&A

> ## Excerpt
> Wed, Sep 28, 2022 2:59 PM; Duration: Live

---

I've made you the co host. Thank you. Yep, and now we can let everyone

All right, so we're gonna get started here in just a second. Let everyone connect to audio here

and video and whatever else they want to do.

Okay, so we can go ahead and get started. Thanks everyone so much for submitting your questions in the forum. We have quite a few and so we have organized them by topic area so we're going to be going through and answering those. If you have any additional questions or follow ups or anything like that, feel free to put them in the chat and we will try to address them as well. We do have a pretty full agenda today. Lots of stuff to discuss. So this is exciting. But yeah, absolutely drop your questions in the chat. And we can go ahead and get started. So hi, Leslie. I can Yeah, it's so good to see you this morning. And you too.

Looking forward to diving in.

Let's start out with a question on genre. So we're kind of gonna go in chronological order of how the training is. So this question is from Nick, thanks for this question. Nick. Could you speak some more about the worldview revelation genre? So you know, he's thinking about big reversals like sixth sense and rival and then in the air knots when let's see seeing more incremental revelations. So wants to know a little bit more about how worldview revelation works.

So let's dive in and talk about that. You know, I think, I think as a as a review of what we said in the concept video worldview, Revelation is really about finding out how the world works. So it's not just about learning information that wasn't true before. But it's about learning different approaches to dealing with the context. So the rules of the game have changed or you find out that you are addressing a problem. That isn't the true problem that you need to be addressing. So these are the kinds of things to keep in mind as you're approaching worldview, Revelation. And you know, I think I think there are different levels of subtlety, like the sixth sense or a rival like these are, yeah, big shifts in the way that they're approaching the world. But I think even smaller shifts can are not necessarily smaller, but more subtle shifts can have the same magnitude, because they would affect how the protagonist makes every choice from then on.

You have other thoughts on them?

Yeah, I think what what may be tricky about Revelation is that nearly every story has revelations, right? You have revelatory turning points that you can have in within an individual scene. And so sometimes it's a little hard to separate or make that distinction. So one thing I think, is, as you say, it's about how the world works. What's the game that's being played? And, and how is it different from the way I thought it was? And then the other thing I think about it is that just like any other internal genre you need to see those tiny shifts that are happening across you know, within each individual scene that build up to the global turning point when the frame actually breaks. And, and the and of course, the all is lost moment. That's happening in q3. So I think that that's, that's what we're seeing here. And so that's why we went through, for example, in the trope video, we went through what's the misunderstanding? And then what how is that how is that turned on? It turned on its head. That's not exactly the phrase I'm going for. But hopefully, you know, where I'm going with this. How does that become understood? And so, yeah, so that's kind of how I'm thinking about it. And my sense is that, that if we can pull those apart and see for example, see the revelation plot that's happening here. In the same way we saw the status plot in Jane Eyre. Then if we can make that back those connections, I think it will help a lot but it may take time to see it. Revelation has been one of those genres that's been difficult for me. And I feel like with the aeronauts windlass is actually helping me make a big leap forward. So that's I think, that can happen for everyone.

Yeah, and, you know, I want to also just go back to what we're trying to do here, and I think this will be a consistent theme as we go through the q&a is that we're trying to iterate on this one scene. And so

so what I what I see sometimes is this tendency to feel like you need to understand all of the theoretical underpinnings to go on with the scene work. And sometimes just doing the scene work will help you find a way into the theoretical stuff. And so, so I just want to caution everyone you know, not to get too hung up on feeling like you need to understand everything perfectly before you dive in and iterate just try writing it and see what works. And then if you can see that there that you're seen as missing something or that it doesn't feel quite the same, then

then that is going to give you an indication that you're not iterating something correctly, and then you try something else and then it clicks. You know, so So my point is, I think that

that when you try to go from the blue and make sure everything is lined up before you go to the green, you can get stuck and and this is also like top down bottom up so so try using those switches and say you know if it's hard to grasp this I'm going to try going bottom up, I'm going to try looking at the implementation, and then find my way up from the bottom rather than down from the top.

Yeah, I think that is a lesson that I need to learn every time you know, every time I start a new project is recognizing I can't talk down it exclusively, which is I'm never going to understand it until I iterate it. And that in that process of iterating is where I'm going to have the most insights. And then the other thing I was thinking about in response to what you were sharing Danielle is the way in a video there are certain video games where you're exploring territory and the map is only revealed as far as you've explored.

And so I think that we want to know the whole map. But if we get to know the territory that's right before right in front of us, that that will that that will yield more than looking at the whole map all at once. We want to know where we are in relation to things and that does help. But if we can really that's one thing we found in in doing the scenes this year, is how much a single beat reveals all of the themes of the the struggles that are going on in the whole story. You can see them just within that one little thing. So I think really focusing on the ground that's right beneath us is actually one of the best places to start.

Yeah, I agree. And, and I love that idea of comparing it to a video game because there are so many there are different ways to go through a video game you know, you can play the main quests or you can do a completionist approach and you can do all of the side quests and everything like that. Well you know in a story we want to we want to make sure that our story spine is strong and then if we have time for side quests and here side quests means you know layering in subplots and fun things like that. Those are the things that are secondary, but we have to make sure that that foundation is there first and we're going to be talking about foundations a lot during the semester.

But yeah, when you were talking about how how we can fall into this trap I absolutely agree. And and yeah, as you said one example gives you so much and you know when you when you have something like masterwork study, it can also be tempting to say well, okay, if I want to be a crime writer, I have to have read every crime story before I start writing, you know, and that's not true. Read three to five, you know, and then just dive in and it's like,

you probably have a sense of it already. If it's a genre that you like to read, if it's something like this you know, you're in a safe, constrained environment, where you're able to iterate without without needing to know the, the entire territory.

So yeah, I think I think that toggling is something that we can all learn from. So also, if you have questions, do put them in the chat. So we're not going to have anyone unmute today but we're just going to go off of the chat questions.

We had a couple of follow ups from the chat here. And

so talking it looks like there's some some chatter going on about maturation revelation education and what kind of protagonist those have. So

you know, I think also that this goes beyond the scope of the training, because we're not we're not teaching a class in Revelation, we're teaching a class and how to iterate this scene. So I recommend going to the four core framework to learn more about genre and if you want to see the way that those protagonists are different than dive into different masterworks, so, we have some different different masterworks that we've suggested from two semesters ago. Now.

We have a man called ova as a worldview education. We have a Wizard of Earthsea as a worldview maturation, we have the aeronauts windlass with worldview revelation so you have some masterworks that you can read to compare and contrast and see how the worldview shifts look different. And that would be a really good step to start to understand those genres a bit more in depth.

Do you have anything else you want to talk about on this one? Let's say no, that is exactly what I would have said.

Oh, I'll just round it out. If you're interested in disillusionment, disillusionment, not engaging in it, but reading that, that genre, then the Great Gatsby is the one of the best examples out there. So yes, so true.

All right. So now let's go down to week two, and we're talking about Sam so we have a question about who Sam is, do you want to take it away?

Sure. So okay, so in our narrative device, we have an author who is trying to help someone with a problem and that problem is Sam and Sam is the single audience member. So that's just kind of a a basic definition. But But I think the question beneath the question is, why are we doing this? Why are you making us engage in this second level of artifice to when we already have a story that is complicated enough? And that is because having that narrative device as a model of communication where the author is trying to help someone who is similar to the protagonist with a problem, that they have a very specific problem that relates to the problem that the protagonist faces that helps narrow your focus and, and align all of the scenes in the story so that everything is working together and you have this integrated, coherent whole.

And the reason it can't be the protagonist, I mean, it is in some cases, there are some were, for example, in Brooklyn, I think.

I've identified the protagonist as essentially the the single audience member but But overall, what you're doing is you're, the protagonist can only learn from their experience, if they're getting some distance from it. Right, they're already in it. And so what you want to do is it's a situation where somebody comes to you have a problem and and explains it, and then you say, Oh, I've got the perfect story to help you to help illuminate that problem. And then you start and then the author starts telling them and it accomplishes a lot of things because we don't always like to take advice that's on the nose. So a story helps us kind of fall into that, that lovely narrative and and it gives us It allows us to make our own decision about what we're seeing. So it's the designers to illuminate the problem. So I could talk about this for a very long time. So I'm going to stop there. But ultimately, what that narrative device is trying to do is to create a model of communication because that's what story is story is communication from an artist writer, to a mass audience of readers, but that doesn't give you enough specificity to constrain the story to create that coherent narrative. And that's really what we want because that's what makes for a story that's quite enjoyable.

thing think that's such a great explanation. And I wanted to follow up on the idea of Brooklyn with, you know, protagonist as Sam a little bit because it occurred to me as you were saying that that that's similar for Bridget Jones's Diary and but the thing with Bridget Jones's Diary is it's more overt about she's writing a diary for herself. And, and I think that that's the key is that when the protagonist is Sam, it's that diary aspect of it. And there are very specific instances in which reading a diary is interesting, and many more in which it is not. And so it's not, you know, as a general principle, then that it doesn't work as a general principle because what you'll end up with is a lot of a lot of journals if you have the the protagonist as as Sam and similarly, you know, if you have yourself as Sam, that also leads to that journal kind of feeling. And so, we want to stay away from that so that we have so that we have all of the benefits as you were talking about about the narrative device. And from a green perspective to sometimes you'll have a different Sam and that will give you a different what I call informational strategy. And that is just like, different facts that you need to put on the page. So there are times when the SAM is similar in terms of the role to the protagonist but has different different clothes on meaning they might be in a different time in place or something like that. And we need to know that so that we can get different factual explanations of things and present a consistent place.

That will give us a consistent focus that will give us a guideline for what facts they need to know and which ones they don't. So some examples and I don't know like do I want to go outside of this semester, but here we are. So yes. For example, in in the Name of the Rose, that's something that we did in the first semester. So those of you who are around will be familiar for those of you who weren't. It's a story that is told from a monk in the present day of probably the late 1300s. And the story itself is set in 1327. So when we identify the SAM as someone who's in the late 1300s, that person needs explanation of what was going on in 1327 In the same way that we would need explanation about what was going on in say, the 60s, we wouldn't have the day to day, right. And that's we need different facts than someone who, like if we're telling a story about 2010 We remember more of the things and or, you know, potentially, I think think it's clear in that particular work that the Sam was not alive during the events that they're telling. So, these very specific what facts about the story do I need to know those are informed by the clothes that your SAM is wearing, including age all that stuff, and then and then the energetic message is aligned with the protagonist. So these are two different planes. Some questions that are that are coming through. So for an example like the SAM in The Great Gatsby, I just want to want to give you an idea. We don't we don't do this lightly. When we talk about Sam will have conversations for a long time about what the SAM is what the rest of the narrative devices. And so we can't offer you examples right off the bat. You know, we could probably get close, but I think that would be doing a disservice to do that kind of on the fly analysis because we don't want to lay something down and have it be something that you know, appears to be in stone when it's not. So it does take a lot of thought. And the examples that we present are ones that we have put a lot of thought into and have a solid idea because like to give you an example we talk about different candidates and we talk about them at all the different levels and make sure that everything aligns and then we go back and we look for textual evidence. And we make sure that our theory aligns with what we're actually seeing in the text. So this is not just a conversation. It's actually a fact finding mission, where we go we come up with a theory and then we try to disprove it.

Yeah, and I but I, yes, absolutely. I'm so glad you mentioned that because we can spin it off the top of our heads but it's not going to be completely accurate.

So okay, so but I can give an example based on stuff we've done and that may be useful for this. So So one thing is in the aeronauts Windlass. And before I say this, it will also give you a hint about how to approach you know the strategies that you use as a writer in order to get in information that the readers right your mass audience of readers is not familiar with. So one way is to is to do something like in The Hobbit and we were talking about this just this morning that the the single audience member for The Hobbit is a human not a hobbit, right. It's somebody who's not in that world. And we know that from the very direct references right? Big people don't understand this and they're very direct references on the page. So that's one way of getting in of it. Getting in the information that the that a mass audience of reader. Yes, exactly. Because you have to explain hobbits in the first chapter 100%. Right. And, and the so that's how we're getting in that information that the reader won't be familiar with in the aeronauts Windlass. Right. We don't we don't have that situation. And the and then the point of view, the narrative device, all of that makes so much sense for that. So how does Jim Butcher accomplish this? Well, he has young people young, less sophisticated avatars like Creedy like Gwen, like Bridget who are asking questions that are that they need to know the answers to right they're not just fluff it's not Oh, well as you know, Bob, blah blah blah blah blah. No, it's it's handled very artfully with questions that they need to know that are that are motivated from within. But that's the that's the way because of the narrative device because of the point of view choice that he's choosing to get that information in that the reader needs to know because they're not familiar with that world. So that's kind of one way to think about to think about all of that.

Perfect, yeah, I think that I think that goes over Sam pretty well. So shall we move to the point of view question.

Take it away. Do you want to you want to jump in there? Do you want me to? Sure. All right. Sure. So Frank has asked about why we're why we use different terms for different types of the wide variety of points of view that there are for us to use. And, and the terms that that we're using are mainly from Norman Friedman, and it's because they're very specific, and they're very focused on function. Right, so so we could lump all the third person points of view together. And that can be useful to a point right because you need to know the mechanics How do I carry this out? Oh, it's it's he she and they not I me, mine in you know, in terms of the pronouns, but in terms of what they're functionally doing in terms of the perspective of the, the, the author in delivering the narrative, the lumping the through the third person choices together. Doesn't work. They're all very different. If you look at them on a spectrum, they're not together, they're not all together. So that's why we're separating them. And the key thing again, to go back to what you were talking about earlier, Danielle, is that what we're doing here is trying to iterate this pattern, this particular pattern, which is using this particular point of view. So it's more important in this instance, to understand what are the what are the boundaries of this particular point of view. So you can carry those into your own draft and enable you to iterate that pattern. So we want to so the questions that are most useful I think here are what are the what are the qualities of the particular point of view in this scene? And how what's required for me to to iterate that pattern?

Yeah, and I would add to that to that, because we have questions about well, you know, can I take a class on an in depth topic like Sam or point of view, something like that.

Everything is to that, you know, in the guild each individual semester is, is going into how you iterate this one pattern, but we've also designed the semesters overall so that they give you a comprehensive view of the most common patterns that we're seeing in that we see in stories. So it's sort of a combination, where if you lean into the specificity of each semester, and do that each semester, then it's designed so that at the end of the year, you end up with those in depth views. of the concepts through getting multiple viewpoints. So I think about it like if you if you look at something from one angle, then you're getting essentially a two dimensional view. But if you look at something from two different angles, you can start to extrapolate its dimensionality. So we're having you look at stuff from three different angles, and you get a really a more complete view of what that thing looks like overall. And so in in the future, we are going to have more, more instruction that goes deeper into a single topic and you know, talks about all of its underpinnings and all that fun stuff. But I think that you can really accomplish a lot of it by taking the taking the semesters that are surveys, they are, you know, addressing all of these concepts at a fairly I mean, I don't want to say superficial in a negative sense, but you know, we don't dive deep into any of these concepts, but we're showing how they work in the scene. So it gives you a broad survey. It's a broad course rather than a deep course. And then through looking at that broad application several times you can start to develop that depth.

keep on and we can get down to the controlling idea. So Nick asks, Could we speak a little bit about where the controlling idea fits into the 624 analysis is the controlling idea statement, which helps Sam make overall choices amongst the competing factors and the double factor problem in the particular context of that story universe?

All right, so I want to give a little bit of an overview of how I see these working together and we can discuss from there.

So the double factor problem, very important. The double factor problem is an overview of the factors of the context meaning the different structures that are in play the different like the way that things work in this context, and it's linked back to the genres and the factors at play in the double factor problem. Are things that all of the avatars in the context are dealing with.

So everyone is trying to navigate this broad problem space, then we narrow it down to Sam's problem.

And that is how a person in a specific more specific role, not like this person, but this kind of person relates to the factors. So something that's really poignant in in our scene is that grim has to deal with being responsible for other lives. Not every avatar in our context, is responsible for other people's lives, but he is because he's a leader. So when we look at Sam, and we're looking at that analogy to our protagonist, we're looking at okay, how does a leader navigate these factors and more specifically, how does a disgraced leader navigate these factors because that also influences the approach there.

And we summarize that by looking at what is the key way in which Sam is misunderstanding how she's approaching the double factor problem. So that's that red level. Then we move down into the green level, and this is the crisis matrix. So the crisis matrix is now Okay, so right we have everyone in the context. Now we have a specific role. And now we have a specific instance. The crisis matrix is it comes down to a clear decision between this action or this action.

And then we're going to look at what the consequences are. So we're moving from very general to specific role to specific context. And then coming out of the crisis, the protagonist does one thing or another.

That's the climax that reveals their character. And then the resolution happens, and we see how that worked out for them.

The controlling idea is a summary of that evaluation. So the controlling idea says, If you do this thing in this specific context, it works out this way.

So it's a piece of evidence that evaluates the climactic action in terms of the global value. So, you know, love triumphs when you can let go of your prejudices.

And it is it is specific to the story. So imagine that Sam comes to the author and says, Hey, I met this guy.

He's rich and kind of snobby. And I don't know if I should marry him. And the author says, Well, you know, let me tell you about this guy, Darcy. Now, does that mean that you should marry the rich snobby guy, not always. Not always. They're not all Darcy's right. But what she's doing is offering a piece of evidence that sometimes that can work out and so she's giving someone who's in that position.

Evidence that might expand the way that she can think about that problem. And so that's how I see the controlling idea. Now specifically, I would say that when you are when you're doing that scene events, synthesis and filling in that formula, that's where it logistically comes into play. But theoretically, it's in that stack along with the double factor problems, Sam's problem and the crisis matrix.

Yeah, so to just kind of pick the pick up on that. What occurred to me when you're talking about that and thinking about critique, in particular Pride and Prejudice, that she's not going to know if he's a decent guy until she goes through that transformation. Individual process of transformation as an individual. Right. So that's, that's just, that's fun. I'll give you that for free.

The, the thing about the, to me the relationship between the the double factor problem as it comes out of the pop, you know, in the context in the context that this author has created, right, or is, you know, has let's, let's take narrative device out of it. We'll just talk about you as a writer, you're creating the story world within the story world where the double factor problem applies to everyone. The controlling idea is a Urist ik for dealing with the problem.

whereas I had another really it was really good. It was really good to another thought. So when Oh, yes. So when you're looking at so that's the truth. That's the message in the story. And you want it you can use that controlling idea when you have a pretty good idea of it. You can use that to test each scene to make sure that it's consistent across the across the story because you don't because it's true in this story world.

You want to make sure it is true in every scene that is demonstrating something happening within that story world. So where we get into sometimes, we we have this really lovely formula form for the for the controlling idea that that's that's great. And we also which I think I would say is a very tell me if I have this wrong, but Danielle but I think it's a very green way to approach the controlling idea.

So what's means it's a very practical,

grounded way of looking at it in order to use it as a tool, but we also might come up with at a more eternal or universal pattern. Blue level, we might come up with a slightly less practical way of looking at it. So then we get the things like discretion is the better part of valor. Right and that is something that is true in eyewitness though what we might want we might want a green that, that controlling idea up a little bit in order to make it a little more practical. But if you're someone who who identifies as being blue, then you might then you might start there and then make it more specific and more practical. So you can apply it seem to see.

Yes, and we did on the podcast when we went through the the controlling idea of of eyewitness. We did delineate it at all three levels, the green level, the red level and the blue level. And so that's something to look at to just to see how that looks different at each of those levels.

We had a couple of follow ups in the chat. One is from Douglas I think he said the controlling idea is the answer to the double factor problem. It is once you work down through all of those levels. So in the specific context of the specific choice in the story, it's the answer to the double factor problem. And it's saying in this specific context, and that's that's what we mean by the double factor problem doesn't have an answer, except when you specify context. And so the controlling idea is a way of doing that. It's saying in this specific context, this is how it works out when you interact with the double factor problem in this way. So each double factor problem is going to have a whole range of potential answers. And those are the controlling ideas of the stories that you could tell him that problem space. So you're telling one story, and you're communicating one message, but over the course of your career if you're interested in this double factor problem space then you might write a bunch of different stories that deal with different controlling ideas that are addressing the same problem. And you'll probably find that as you write stories you tend to

you tend to be dealing with the same factors and outside of Story Grid, we might say that you're dealing with the same themes.

And that's what that means is that ultimately your factors are going to be similar because those are those are the big problems that you're wrestling with in your life and it might not be the same for your whole life. But it's we're attracted to certain types of problems.

And then another follow up we had is, Leslie in your non negotiable training.

You mentioned the global synthesis and is that the same as scene of analysis Do you want to go into that, or do you want to?

Sure, just briefly, it's it's the scene events synthesis. It is very similar, but we're applying it at a global level. So you're looking at the Global plot the global on the surface plot, you're looking at the Global essential tactics as related to the goal and the information processing of the of the protagonist and the conflict between the protagonist and the Antex antagonist. And the and then the value shift. And then as the, you know, for the global synthesis, the global synthesis is essentially that very specific form of the controlling idea that enables you to test each scene so that's, yeah, that's well spotted.

Okay, so now we have some questions about the double factor problem. So Shelley had a question about how the double factor problem relates to the crisis matrix. And I think we covered that in going over the the controlling idea question.

Then Mike had a question about the crisis. So he's looking at best bad choice versus irreconcilable goods and transform versus double down. So asking, you know, are there two choices that the protagonist has to make like between best bad choice and irreconcilable goods and then between the the options, so I want to clarify this because it's really important that we have a good understanding of our crisis that that gets down to the heart of our story, right. So that's about choice and irreconcilable goods do not coexist within the same crisis. This is a way of categorizing the type of crisis that it is. And we figure this out because of the way that the author is presenting the choice. So a best bad choice crisis. is between two bad things are probably all familiar with having to make those types of choices.

And irreconcilable goods choice is between two good things.

Although quite difficult, because you can't have both. So these are in both cases, you have two mutually exclusive options and you have to choose which one you are going to create in your world you are going to effect through the climax and by you here. I mean, the protagonist, the protagonist is choosing between these two.

Now, the crisis matrix gives you the consequences of choosing each option at the different Trinity planes. So for a best bad choice for each option, you're listing the bad things that could happen if you choose that option.

And, you know, you may have some potential upsides as well, but the focus is really on like how bad is this thing? Because you're trying to choose the best bad choice you want to figure out on balance, like how bad is this thing going to be? You're trying to figure out for any of you who are, you know, I don't know I have I have an econ background, but it's like it's the expected value of that choice. And that means that you take all of the probabilities with all of the outcomes and you collapse them into into a summary view. Of how you expect that thing to turn out.

And the same thing with irreconcilable goods you're trying to quantify to yourself, I mean, not quantify, you know, but you're trying to get a full understanding of how good is this thing? And that way you can choose the best of the good things.

And so that is, that's how that works. So from the protagonist point of view, there is only one choice. It is either a best bad choice or an irreconcilable, good. And then the crisis matrix is how they're determining how to make that decision.

Yeah, anything you want to add there

Okay, so we can move down to these questions from

we had a follow up in the chat actually quickly. So from Frank I find it more handy if I interpret interpret the gaps you fill in not as consequences but as risks. I think that that's it, you know, it's another way of phrasing, looking at it, but I think that when you connect it to the resolution, for example, it's going to be more helpful if you've already thought of it in terms of consequences, because then you know, what needs to play out.

And so, like the differences that consequences are backward looking. And so you're simulating forward okay, this is getting into the weeds a little bit, but a risk is forward looking like I think there's a 20% probability that it's going to rain I guess, or whatever, you know, whatever it is, it's forward looking. And if you are if you're simulating forward, you're saying, Okay, what if I do this, and I'm living with cognitive dissonance, and so, consequences are kind of backward looking. Because you've you've simulated forward and you're saying, now I'm in that spot.

And so, then when you deal with the resolution, you have to treat that consequence. Now, if you say, well, there was only a 20% chance it was going to rain and then it didn't that's reasonable from a risk perspective. But it undercuts your Sam's experience in the investment they've put into the crisis.

So if you think about it as consequences, then you know, you always have to treat that you always have to have it come up in the resolution instead of using that probability as a way to escape dealing with the risk that was there. So that's why I like to think about it as consequences instead, if it helps you to brainstorm to think about the risks, absolutely do that. But then ensure that you're doing that simulation to get to the point of what would the consequences look alike so that you can treat it in the resolution? And it does not mean that everything comes to pass. But it means that if something doesn't come to pass, you give a reason why it did not.

And that might be like the misunderstanding on the part of the protagonist, or it might be that something changed. In the situation, something like that. But but that's what I mean by treating it is that you have to explain why it didn't happen if it doesn't happen.

Yeah, and there's a subtle mindset shift. I think that that you're really picking up on here. And that is that Hindsight is 2020.

Right? So from the position of the consequences, it's like oh, you can see the clear lines of cause and effect.

As the writer you need to be from Have you need to have that perspective. You need to you need you are determining this world. You are the God of this world. And you have to know that this is what happens here in order to set it up so that the reader is reading it from a risk perspective. So they're experiencing it that way. You can experience it that way. At you know, at first but then you do need to shift and see it as this is the way things work in this world. Under these circumstances. This is what happens. And so and that's really really important because we can't ultimately we need to understand the world and everything that happens in it in order to create that coherent experience experience for the reader.

Yes, 100%. So to say that, just say that in an in a different way to when you are creating your relevance filter, if something is going to not happen because of chance. You don't put it in.

Right. So you are creating.

You're creating the crisis matrix from that perspective of knowing the whole story as you said, Leslie, and then the, the potential consequences that you choose to highlight are the ones that are going to be relevant later on. So it's, it's a form of setup and payoff at the five commandment level where you are making sure that you include just the relevant information for what is going to come to pass in the rest of the story.

then look at our next question.

Okay, so then l McGrath had a couple of other questions about the double factor. Problems is the factor of revelation present in the inciting attack scene in the aeronauts Windlass. Yes, and I would, I would point you back to the concept or the sorry, the application videos. So we went over in the double factor problem itself about what what that is, and then through the application videos, as we look at the scene, we are talking about the kinds of revelations that Grimm has. And so I think, you know, in each week, we're really talking about it. In the tropes week, we go in depth into what are Grimms misunderstandings in each and every trope. And so that's something that you can refer to to look back to that.

And are the two factors in the double factor problem derived from the external and internal content genres? Yes.

Do you have anything you want to add on that? Or should we go?

Yeah, when we can do one word answers, it's nice. Yes.

All right. So JAYLEE asks about value shifts. So

okay, so talking about how it just generally how we how we look at value shifts, right, and her question was about victim to warrior in the context of a Wizard of Earthsea that that scene Yeah. So there are different. Yeah, I think.

Perhaps it is helpful to think about the stack of

how we look at value shifts.

So first, it's about determining valence in in the way that the author is presenting the scene to Sam. Is the scene making things better or worse. That's a very rough cut way of looking at it.

And then you can start connecting to the values spectrums that we see in the double factor or sorry, in the four core framework. So this is looking at what's my global genre? Am I moving from life to death or death to life? You know, what am I moving closer to? And then from there, as you progress in your understanding of value shifts, you can get more specific and start to figure out

you know, more specific and nuanced ways of looking at it.

ultimately, everything needs to connect back to the value spectrum that you're dealing with in your content genre.

What we like to do, because we're trying to present you with the most ideal way that we can, of understanding these scenes, not saying that it's ideal, you know, this is a this is a lifetime journey. But we are looking at these things

in the best way that we can at this point in time. And when we look at a Wizard of Oz, see what we're doing is we're trying to say, you know, we're connecting to life. And death and we are also connecting to maturation, and we're trying to find a value that speaks to not only the global genre, which would be right like that's, that's, you can get really nuanced within that. And the step beyond that, which is the ideal that we're trying to present to you is finding something that encapsulates both genre movements, and how they interact with each other.

So we're trying to show that interplay, right, so when we pick victim victim to warrior we are talking about how gad matures in a way that also shows his relationship to life and death in this context.

When he moves from a victim to a warrior, he's moving from someone who is at the mercy of others to someone who has control and control of his own destiny, specifically as it relates to life and death. And so that's how we came to that. It's a very, very small crystallization of a very long conversation.

But, you know, ultimately, we're moving toward that. So if you're coming up with things that are like, oh, and he's moving from endangered to safe, great.

In the right, you're on the right road. And so that's one of the things where with value shifts, because that road exists, it's hard, right? Because it can be hard to come up with something and know is that is that off, you know, I didn't get the same words. You're not going to get the same words, right. That would be that would be spooky.

So if you don't get the same words, how do I know whether I'm on the right track? And that's something to evaluate right is like is the valence working? Is it on the same value spectrum, that kind of thing? And you know, if, if you're interested in getting more direct feedback, that's why we have that editor mentorship track so that we can give you direct feedback on how your own work fits into that journey. So that's one of the things that we specifically do when we're providing individual feedback, is that we try to, we try to pinpoint where you are on that journey and then give you the next step. Toward progressing toward that more ideal analysis state.

Yeah, and just a reminder that, that a lot of this takes time.

Right to develop these, the nuance, right, we've been doing this for a while and we do it full time. So um, so if you're new to this, or you're, you know, you have an hour or so, or a couple of hours to do the training right, then you're not going to get it right away. But just as you said, getting in the ballpark.

And then playing with the different you know, what does that look like you might even if you're studying a masterwork because it's your what we call magic wand story. Like, whoo, if I could wave a magic wand, and this story was actually one I wrote, right, that's the one that you're the your model your masterwork. And then if you're studying that really closely, what you might do is come up with the, you know, the description of a you know, the potential value the the big value spectrum, right not every action story goes to damnation, but some of them do. Right? So you want to put like, specifically what are the bounds of that of the value shift in the story and then identifying what those things what it looks like, at those different levels and create them in a you know, in a in a hierarchy.

But I think that also that the specificity of being able to tie together, the external and the internal, is something that comes with time and then just really spending time with the story reading the reading the scenes over and over again to try to pick up on what's what's really what's the most important shift that's happening there for the protagonist.

Yeah, Julie had a follow up in the chat. I was curious about the verbiage the value given seemed like an archetype or role it is. It is but it's one that is linked to that value spectrum. So because we're addressing maturation because we're addressing a value, or sorry, a double factor problem that is about it's about the way in which the protagonist exercises agency, that roles are very relevant in this context, and in this example, and so we chose to go with a roll now not we don't always go with a roll right like trap to escaped. It's not a roll.

But in this case, we felt that it was the best way to encapsulate the movement of the scene was to look at the change in the protagonist identity as it relates to that value spectrum, and use that as a descriptor of the movement on that spectrum.

So yeah, I think you know, we're coming up on time. And so I know we didn't get to all the questions, but we try to focus on the ones that are, you know, on the biggest, on the biggest topics for the semester so far. And so I just want to wrap up by by saying, you know, thank you so much for all of your questions. Thank you again, for your engagement with this material. We know that it's hard and we know that it's a lot to grapple with. And so you know, I want to I want to go back to what we said at the beginning and what we've been saying throughout

you get stuck, consider, am I stuck because I'm trying to get a perfect understanding before I move forward, or do I have enough to put words on the page and just try putting words on the page? You know, we're in our week where we're drafting which is very exciting. And, and, and as we said in in the application video this last week, have fun with it.

So if you're finding that you're not that you're getting too tied up in the details, and you're not having fun, I mean

this isn't this isn't something that that you're doing because somebody is forcing you, you know that you have to it's it's fun. And I think it's easy. Like I know for me, it's easy to decide I want to do something because it's fun. And then I can structure it to the point that I take all the fun out of it for myself. And it's really important to you know, structure it to the point that it's helpful. But also keep in mind that you're doing this because it's fun.

And, and make sure that you don't lose that kind of wonder. That's the reason that we all write in the first place. And you know, when GED loses that wonder, that's when he goes wrong. So we don't want to lose that wonder we want to hang on to it. And the way to do that is just to keep focusing on what matters. So what is essential about your study of the guilt this semester? What is essential is that you understand enough to write an iteration of the scene from the aeronauts Windlass. And if it goes beyond that scope, then you can give yourself a pass. I don't have to worry about that right now. Future Me can worry about that thing. But for right now all I have to do is write the iteration of this seen and and see what I can do you know and it's going to be a fun process of discovery.

Alright, thanks so much everyone. And we can we can wrap it up there. Do you have any anything to say in closing Leslie, or shall we just now just just agreeing with everything you said and thanking everybody for engaging with this process because it is a leap, and we understand that and it's hard and we understand that but it's really valuable and valuable work to be doing, and we appreciate your engaging with it.

Absolutely. Thanks so much everyone. Good to see you all and we will see you in a new training and then we can have.
