Tim Grahl 0:00\
And we'll look into that. But otherwise,

Unknown Speaker 0:03\
I just want to leave Shawn plenty of time to teach and take questions.
So

Tim Grahl 0:07\
I'm going to turn it over to you.

Shawn Coyne 0:09\
Great thanks to him. You know, I saw the other day somebody had, there's
this weird thing that pops, okay, that pops up on zoom on the right hand
side. I just want to integrate that. Okay, um, so today I have a few
things I want to talk about. So I'm going to share my screen here

Okay, so, um, one of the one of the foundations of story grid that that
separates from us from a lot of other, you know, recommendations for
storytelling is our reliance upon the science of story. And what does
that mean? It means evidence. You know, we don't we don't say things
unless we find the evidence for them to be true. So I want to quickly go
through some ideas about what what I mean by evidence and then
especially in terms of story, and then I want to get into a concept that
I reviewed the other day for the genre blueprint course that went really
well and I think it would be very helpful to review it with you. And
that's about self organized criticality. Which Don't worry, you don't
need to know it. But it is evidence based of story grid. So it's a it's
a really cool natural phenomena that we map on the story grid so that
you can know that what we're telling you is very convergent with with
science. Alright, so what do I mean by evidence based analysis? Well,
first you want to think about like what what kind of evidence is there,
right. So the primary evidence that we have for anything is our sensory
systems. And what's really cool is that our sensory systems give us
really amazing differences of scale of evidence, right? So think of
sight the way you can see right if you're standing in a really nice
field, you can see very far. One of the great scenes in cinematic
history is the big, you know, shortly in Lawrence of Arabia, there's
this special camera that they had made, where the protagonist is
standing in the desert. And on the very tiny piece of Horizon, you can
start to see this blip and it starts to get bigger and bigger and
bigger. And it's like, I don't know, it's like a two minute shot. And
eventually, you see that little blip form Omar Sharif on this Black
Stallion, and he's coming. So sight is long range, we can see things and
anticipate things with our vision. So it's very, very long range and
it's very objective. Why? Because we can ask the person next to us. Do
you see that? blip on the horizon? And they can either confirm or or
tell us that we're wrong, right? So we can objectively figure out that
we're not crazy. There actually is something barreling towards us on the
horizon. So long range sight is extraordinarily powerful. Because it
gives us some time to prepare for an oncoming collision with some kind
of form of energy. Or what's the second most reliable in terms not not
reliable, but the second scale is hearing, right? So we can hear things
from a great distance. So hearing is sort of mid range. It doesn't
travel as fast as light, but it is very, very powerful. So you know, in
a lot of great horror films, you see people go, Hey, did you hear that?
And it's this little distant thing in the past. So that's an objective
thing that we can we can actually confirm with other people. Yes, I've
heard that it sounded like lightning. Right? It sounded like thunder.
Lightning is light. Alright, so the next one that is a little less
reliable is smell and that's a shorter range than hearing right. So what
I smell I can confirm with other people but the the what you can see is
that the the coarseness that the specificity of the sensory experience
is getting more and more coarse. So I can't really be sure that the way
I smell a pine forest is the same way you do but we can say Do you smell
that thing that we have individually? Decided smells like pine, right?
So as you're getting more narrow, it's becoming more subjective, right?
Alright, so after smell, we have touch. Now what touches it's it's
really incredible. It's It's the moment when the boundary condition of
your body has been disturbed. So we have oh, yeah, there it is. Right.
So touch is right on the external of your body. We feel the touch.
Lastly, we have taste and that's an internal, right, an internal sensory
experience. So you got this really cool pipe, this funnel, right?
They've got a very large site, and then it cycles all the way down. And
so what I have are these arrows, objective measurability, right, so
we've got all kinds of instruments that can measure light, the spectrum
of light, etc. We have instruments that can measure hearing as wave
patterns. Smell. Hmm, sorta not not as good touch. We have good ones.
Taste isn't very, very specific, is it? There's the whole wine industry
is based upon the fact that taste is like impossible to objectively
measure. So it's very story driven, you know, very high end wine stuff.
Okay, so you see this the arrow going up means objectively measurable
measurability with instruments that we can all sort of quantify. And
then the other era is the introduction of subjective in measurability.
Those are subjective experiences that aren't fully able to be
communicated very well. I wrote just think something today on substack
about this. I call that stuff the ineffable. Right? Incapable of being
perfectly described. Okay, so that's evidence in terms of our sensory
systems. Now, what about when we're talking about a story, right? What
can we say is the most objective evidence in the story? Well, it's what
we see. Right? The words on the page the codes that have been scratched
into the, the marble or have been written on a piece of paper, right? So
it's the, the words are actually our site. So we can all objectively
say, what is that word and we can say, oh, it's fish, and everybody
could agree on that. So the codes of the medium or the most objective
the grammar, which is the overall structure, the semantic which means
the meaning of the actual word, and then the syntactic organization,
right? You've got noun, verb, adjective, adverb, all that kind of stuff.
So all those three things come to form a logos of a sentence, Jim went
skiing. Oh, okay. I so we all picture in our mind some figure named Jim,
and now he's shoveling down a mountain and escapes. So that's an
objective thing that we could all say. Yeah, that's what that means.
Right? And then we also have this really cool thing is like, hearing the
voice of the narrator. Right? So we can hear sort of what the narrator
is saying based upon the logos of the way the sentences are put
together. That's called having a voice. Right? So we're all Sam's we're
all single audience members. And when we experience a story, we, we read
it with our eyes, and then we start to hear it in our in our minds.
Right. So those are the most objective things that we can we can
actually say that we agree what does that do that like when I read The
Hobbit? It sounds like a grandfather teach the you know, telling a
nighttime bedtime story. Yeah, I kind of feel that way. I see it more as
a grandmother but it's generally we can coarsely say objectively, that
what we hear is similar to you know, a bridge a metaphor of another kind
of situation that we have all experienced. So this is objective evidence
in a story. All right. So what about subjectivity? Alright, so I'm just
emphasizing the fact that if we really want to get stick Lear be a real
Stickler, let's just look at the words. That's the most objective,
right?

Alright, well, what about subjective feelings like you've heard this
people say, Well, I feel like it's a blank story. Well, what I feel
right and when people start saying we're talking about feelings, they're
valid. They're absolutely valid, valid, but we need to whenever we start
to say what we're feeling, we need to have a little message go off in
our mind that says, oh, feelings are not super subject, a super
objective, right? What I'm feeling is not the same as any of you are
feeling right now. So when I'm expressing my feelings and saying what
I'm feeling, I don't want to fall in love with the feeling as objective
truth. So when you start saying well, I feel oh, wait a minute, didn't
feel that means it's totally valid, but it might not be super
subjective. I mean, super objective. Alright, so what are feelings?
These are limbic system alerts they're course right? They're coarse
grained. And they concern global goal states for the individual, right?
So they're all about should I approach or avoid, they're all about
protecting you. So they're their alarm bells for each individual single
audience. Member, right. So Sam is unique, right? So she attunes to
particular signals and attends to those signals with more vigor than she
does other signals. Like me. I like a good thriller, right. So if I read
a love story, I'm gonna pick out the thriller elements and I'll go you
know, that love story is actually a thriller, because it's really about
the damnation right. And I can really make a great kind of cool argument
about it. But objectively, if we look at the words, it's not a thriller,
right. Well, that's what we teach it story grids, like how do we look at
the words for the evidence to support our hypotheses? That one story is
one thing and not another thing? So we can objectively do that. Now,
here's the trek. Right. Here's the tricky part, right, a masterwork
store. Right. What's a masterwork store? A master word story is
unbelievable. Why? Because what it does is it sends signals across six
channels really well. And these six channels, each one of us likes to
tune in to one particular signal. So when you're dealing with a
masterwork the signals are so strong at every single level that we can
fall in love with our individual signal and lose the forest through the
trees. And think of a love story is actually a thriller. And, you know,
we can pick out the patterns that are thriller ish in the love story and
support our arguments. However, you got to look at the all of the words
to make sense of it. And so that's what we do when the story grid
blueprint genre thing, right? So we really detail all of the six core
genres that come up to make each individual scene. So the reason why I'm
telling you this is that sometimes we fall in love with our feelings.
And when, you know, a story grid person who's been working really hard
and looking at the objective reality of the story, and the evidence
says, well, actually, I think you're wrong. I think it's an action
story. And here are the reasons why. If we're so in love with our
feelings, we'll just go, oh, well, I disagree. And you won't look at the
objective evidence. So the tricky thing is to listen to our feelings
know they're valid, but know that they're very coarse. Bank of America,
not taking that. Okay, um, so, that's what I want to say about that.
And, you know, I'm preparing the next genre thing, which I'm so excited
about because I'm going to be doing the matrix and I'm being I'm going
to break down the entire movie into individual scenes. And I find that
the six core genres in the matrix are extraordinarily well developed
too. And so what would you call the matrix? Oh, it's a science fiction
dystopia thing? Well, maybe yeah, there there are elements of that in
there. But there is I don't even want to tell you what it is yet because
I'm not fully convinced by my evidence yet. I have a good idea. But I'm
that's the great thing about story. Grid is that you can say I feel like
it's a blank story, but let me check. And then you can go through the
evidence. So that's what I want to say about feelings versus objective
evidence based story grid analysis. Okay. Let me get into self
organizing, organizing criticality. And what this is going to talk about
is the science now you don't have to know any of this. The reason why
I'm telling you is to support things like the five commandments of
storytelling, to let you know that these are not just some quirky thing
that I came up with, that seems to be a good idea. They're actually
based upon actual natural phenomena. Okay, so self organizing
criticality. What is this? Well, this is how progressive increases or
decreases in degree tip systems from one state into another. So in other
words in time, differences in degree become differences in kind. This is
a fundamental truth of transformations and emergent complexity. And
it's, it's very well established at this point. Okay. So what do I mean?
Okay, what does self organizing criticality matter to storytelling like
why should you give a shit about this? Okay, so the more we understand
storytelling as its simulation of how reality really works, right, the
easier it's going to be the correct unreal properties in our narration,
because what we want to do is we want to do an amazing simulation of
reality. That's more real than real so we better know what reality
means. Right? So okay, that's cool. But what what is the purpose of
story to begin with? Like, what why are we doing this? So story is, at
bottom, scientifically it's a psycho technology. That means a technology
of our mind. That enables us as individuals and as a species to increase
our adaptive responses to changes in the environment. So stories warn us
or they you know, or they help us so stories warn us about possible
changes that may occur throughout the interconnected Trinity planes of
perception. Right things happen on these three levels, that change is
always happening, and then they show us how to adaptively respond to
those changes. These are called prescriptive stories, or how not to
maladaptive ly respond. Those are cautionary stories. So stories are
these great technologies that teach us how to deal with shit that we
haven't dealt with yet. So they're warning messages that they help us
guide us and navigate through difficulty of change. Alright, so how does
change happen? If it's about adapting to change, what how does change
happen? Let's figure that out. Alright. So there are three categories
that change, right? There's causal change. And in a causal change, we
directly witnessed the source of change causing the change, right? So we
got a picture of a guy poking another guy here, right? And we're
watching it. So we're witnessing the cause of the change. So he this
person has ordered a series of motor actions that project energy at this
other person such that it pokes that person. That's an ordered projected
energy particle of change. Okay, then we have a second con, this is
called correlational change. And in this change, we can we do not
witness the source of change that causes the change that we witnessed,
right? So over here, we see the change, but we didn't get it hold on
second. We didn't get to see this thing that happened before. What
happened before is kind of a wave function. This person has spread some
gossip about what this person had said about this person. So there's a
wave function, the second order effect of this change causes this
change. So it's a wave. It's a flow of energy that moves from this past
event into the future. That's correlation. Hey, why did you poke that
guy? Well, I heard this stuff about what they said about me from Jim
after ski. Okay, so correlational change is a wave function, right? It's
flowing energy from the past into the present.

And then lastly, we have coincidental change, which is really, really
the difficult one, right? This change emerges out of the environment
without cause. So whatever happens there's electromagnetic force in the
sky. It comes together, bring lightning and it hits me, right? So the
lightning hits me and there's no cause of it other than whatever that
thing had that happened in the sky happened. Well, what I'm saying to
you now is that thing that happens in the sky is called self organizing
criticality. And I'm going to talk about how it happens next. Right.
Okay. So how does self organizing criticality Quinzel change emerge? So
it merges out of the environment without cause we can't say that Jim was
the cause of the lightning. It just happened. Right? And so this is
chaotic. There's There's no rhyme or reason, supposedly. Alright, so
let's, let's do a little bit of a bridge here. So let's pretend that the
lightning is made up these little cubes of ice. So all that
electromagnetic static or whatever, it's really hard to envision. Let's
just think it's all pieces of ice. And we've got them in this jar. Well,
what happens is, in time, because of the heat around the jar, the ice
begins to melt. Right? It starts to transition from a solid into a
liquid based upon molecules hitting it just random heat. Right? So this
is a phased transition from one order into a different kind of order. So
the order of the solid ice transforms into liquid. That's a phase
transition and nobody caused it other than the the environment being the
environment, the complex environment. Okay, so that's a phase
transition. Can we get more information about how this actually happens?
Because it's a little coarse now it's still murky. Okay, I get it melts
in the water, but how does it melt into water? That's a good question.
Right? Okay. Well, here's how it works. This is from an amazing paper
from I think it's 1987. And this physicist named pur Bach he E R B a k
because Norwegian or something, he came up with this really amazing
experiment using sand. And he what he did is he shows how these phase
transitions occur. Right? Alright, so let's let's go over here for a
second. What we have is this big bag of sand. And what he did is he let
like one grain of sand drop per second. And then he timed what happened.
Right. So the big bag of sand is representative of sort of chaotic wind,
right, like let's say we're in the Sahara Desert, and there's all these
environmental factors and wind is blowing sand around. And for whatever
reason, grains of sand start to drop in one particular place over time,
right. So what happens all right so the sand drips and then the sand
pile gets bigger, right? And then it keeps getting bigger. Right? It's
getting to be a big pyramid of sand. And then what happens is that
eventually due to nothing other than the chaotic movement of the wind
and dropping sand, it begins to collapse. And so it reaches this place
where it's right about to tip into a different kind of sand pile and
this is the moment of self organizing criticality when that one grain of
sand that last Tippie to be grain of sand hits the top of the pile and
it collapses. So that's the process by which things change without
cause. So you don't need Jim to spread gossip to make the sandpile
follow. So these chaotic inputs become ordered, they self organize into
the pyramid and then in time, with the addition of more degree of sand,
they face shift into a different form of order. This is how change
happens coincidentally, so criticality is the moment the system tips
from one order into another. It's that one grain of sand that tips the
whole thing. Okay, so this is another way of looking at it's the Jenga
event, right? So there's this video, I saw it on Twitter or something
and this kid you know, he's like really made this cool Jenga tower. He's
got his hand he's pulling that one. That one thing and he's hoping the
tower doesn't tip well at tips. So metaphorically, the moment that one
board comes out it tips the whole thing into something else. It's no
longer a tower. Now it's a mess, right? That's the Jenga that's the
moment of criticality. Okay, so what does all this have to do with
storytelling? Well, it's weird, but our minds and our bodies change just
like those sand piles. That description that I just gave you about the
sand pile. It's the same thing that happens in the neural firings of
your your neural networks of your brain. Things tip and then a
connection is made or it's severed. Right something is built up or it's
broken down in the sand pile events. So a grain of sand metaphorically
falls into our consciousness. This is how we change our mind. Right? So
something happens a grain of sand. That's called an inciting incident.
Something comes into our consciousness right and larger and larger
grains of sand accumulate in a pile in our minds that are relevant to
that original grain of sand. Right? These are progressive complications.
More sand is coming into that pile in our mind, but we're not it's not
changing anything yet. We just got a couple we got a sand pile building
up that's all but the mound of the mind sand receives a critical last
grain of sand and it tips and that's a phase transition from one place
on a gradient of value to another. So the grain of sand avalanche the
Jenga moment is the turning point progressive complication. This is
thing that tips us which gives rise to the realization of a crisis. It's
a realization that value that I was chasing is closer or it's further
away. That's the tip. That's the relevance realization of that mind
sandcastle. Right? And then the body's relevance realization of the
climax is is your choice. What do you do now that the value is
transition from one part on a gradient to the other? So do you continue
to pursue it or do you abandon that goal? That's the that's the climax
and then the resolution is the response from the external environment to
that choice. Did it start throwing another similar grain of sand at you
or did it give you a different grain of sand? Did it did throw up a
roadblock? Or did it enable you to go further to a larger higher order
goal? So what did I just I just described the five commandments using
the sandpile and self organizing criticality. So the purpose of telling
you this is a and might be helpful when you're when you're constructing
a scene. And you're thinking about where's my sand? Do I have enough
sand yet? Right and the trick is don't use the same kind of sand the
same size. That's why it's progressive, right? You don't want tiny
grains of sand nine times in a row. You want a grain of sand, and then a
larger one and then a larger one still a larger one still a large one
still until 10 So you want Minimum Viable sand drops that are
progressively larger in size, to induce the moment of criticality in the
value shift. And then the value shift gives rise to the crisis. So
that's criticality, criticality is the avalanche moment that phase
transitions, one kind of thing into another kind of thing. solid ice
reached itself organizing criticality when it becomes a puddle of water.
So when the last the last crystal advice, transition, now you've got a
full puddle, it's liquid, there's no ice in it.

And so in the in the hobbit Bilbo reaches self organizing criticality
when the large reign of metaphorical sand that token came up with which
is that giant spider adds a big mound of sand, isn't it? When that
spider comes in to build those consciousness, that's the grain of sand
that tipped Bilbo from a frightened, hungry Hobbit into a formidable
warrior. It tips him. It shifts him that transforms him. So grains of
sand build up to critical Jenga moments and we become something that
we'd never been before or we rebirth we regressed to something we once
were. So we either progress into becoming something we'd never been
before. Under the Jenga sand criticality moment or we regress. We don't
stand still whether we think we are or not. We're either in that built
by building quote. You're either busy being born or you're busy dying
because regression is a dissipation of being. Okay, so if we block the
dripping of metaphorical sand into our being, we cannot renew ourselves
we cannot become anything. So we failed to create new aspects of
ourselves and become a NERT thus, it's the beginning of breaking apart
from within. So, criticality, self organizing criticality is
unavoidable. You're either flowing with it and building new things from
yourself and exploring yourself and getting more stuff. More aspect to
your being or you're starting to lose it. And you're like, No, I'm just
going to do this and then you get right. So you can't stop the grains of
sand. Okay. So that's self organizing criticality, evidence based stuff.
And so, you know, somebody asked me the other day like, if I could just
change everybody's mind very quickly and give them one thing. I would
say, storytelling is not magic. Storytelling is a science. That's what I
would tell everybody if I could change everybody's mind immediately.
Stop thinking that storytelling is magic. I am not denying magic. I love
magic. But the magic is, is like self organizing criticality. Right
there was no you know, there was no little fairy pushing over the the
sandcastle, right, but magically the sand castle turned into a plateau
just through chaotic life. That's magic. Of course, it's magic. But we
don't assign an anthropomorphic being and say that they're the ones
responsible for tipping over the castle. I do not. I disagree with
Einstein. I think God does play some dice, dice. The random chaos of
life and molecular storm of life is good. Because it constantly makes us
change, which constantly makes us create stuff out of ourselves and the
world. And that what I just described is the process of creation of
transformation. And so, storytelling is that the means by which we
enable people to go through that process. And just like self organizing
criticality, it has scientific as essence to it. There's a structure,
there's a function, there's an organization and there's a logos it's
it's can't it is a science. It's it's we're living in a world where
people do not understand yet that there's a science of story. And it's a
really, really important science, because what does it do? It brings
quantitative scientific objective analysis and subjective humanity and
it binds them together so that they can work together the phenomenology
and the science come together. So that would be the one thing I really
want people to start really grokking don't blame. The fairies didn't
show up to give you your great story. That's really silly. Oh, if I just
journal enough, the fairies will descend from heaven and they will. They
will write my story for me. Good luck with that. Really? Forget it. And
I mean, maybe it'll work maybe in 60 years in a work if you do it every
day. And you magically I just think it's a silly concept. It's like
waiting for the magical cell phone to emerge. Here it is. It wasn't here
a minute ago and now it is now this will took a lot of work. A lot of
hard, painstaking work to create that didn't just magically appear.
Anyway. So I'm going to stop. Stop there and see if we have any
questions. We have 25 minutes left. But yeah, stories, the science and
we're the story scientists. All right. Start with this one.

Tim Grahl 36:11\
In a worldview genre story. How does choice operate when it comes to the
value of ignorance to wisdom? What essential choice is being made at
each scene?

Shawn Coyne 36:22\
Oh, just in each scene

Okay, um what essential choice is the choice of worldview? I that's what
I'm going to boil that question down to because it's just
combinatorially explosive. It's sort of asking me the meaning of life.
The worldview, story is about the cultivation of wisdom. Which is not a
propositional thing. As strange as that sounds, it's because we think
wise people are the most knowledgeable. No. Wisdom is an art form. And
it's about knowing, feeling, right, participating in the world such that
you are doing the right motor action at the right time. It's flowing
through time and space. So wisdom is is the cultivation of an openness.
And it's a very, very paradoxical, difficult thing. But Socrates said it
best when he said, wisdom is the realization when you know that you
really don't know anything. And yet you do. So the worldview story is
about the transformation of your framing of how you see yourself, how
you see the other and how you see the world, right? So when we're young,
we see ourselves as isolated separate beings who can manipulate the
world to our advantage. And a lot of adults think that way too, that you
can just, you know, manipulate people, yourself and the world and output
some sort of valuable product. And then you just accumulate that
product. And, you know, then you're happy. Yeah, that's not wise. That's
not even close. So wisdom is about turning that around and understanding
that you are embedded in the environment, you are not separate from the
environment. So everything that you do has an effect on the environment.
Therefore, you have an innate responsibility, not just to manipulating
the world, but to cultivate the world and be a steward of the world. So
worldview is about the opening up of a frame that sees the world as only
relevant to me. And then a transformation to oh my god, I've been
looking at this the wrong way. How am I relevant to the world? What What
should I be doing here? What is what water should I be carrying for for
this thing? How can I keep this thing going? Right? It's not about how
do I get whatever it is that I want? I should be doing that. So and you
know, people spend their lives searching for that answer. And it's not
an easy answer. But that's a worldview transformation. It's naivete is
when you think that there's a single answer to a complex problem. Oh, I
just get the car and then I get the mansion. And then I get the and then
I get the, and then then what? Where's the finish line? Or if as long as
I get that person to marry me, then they're all my Venmo solve all my
problems. I will be complete. Oh, my God. That's a nightmare idea,
right? That's naive. But a worldview transformation moves the naive
person to a revelation of the deep truth, that we are all connected. And
we need to keep this thing going. And that's nonrelativistic meaning
like, if there is nothing, none of us are alive. It's a pretty simple
idea. If everybody eats everything and destroys everything around so
that they can have whatever it is they want, then there's nothing left.
If there's nothing left, there's no life. There's no life. What the hell
what, huh? So it's a very simple concept at the top of the pyramid.
Let's just what can I do to keep this thing going? How can I keep
creation in China? Right? So that's the world view and it doesn't mean
that somebody has to solve the problems of the world. Rocky is a you
know, you can look at as a worldview transformation story. I'm a
meaningless bum. And if I work hard enough and win the fight, then I
won't be a bomb. That's his thinking. Right? And we go right along with
him. I've got it. He's like, I hope he beats that meet harder and gets
great, you know? And then he has a revelation. There's no way I can beat
that other guy. That guy is just better than I am as a fighter. So what
do I do now? This whole project that I had, isn't gonna work, bang,
Revelation. Oh, but I can survive. I can survive. I'm a survivor, not a
bomb. So all I have to do is go the Go the Distance, take my beating,
and go the distance and not quit. that's meaningful. That's what I'll
do. And then he does it. It's a worldview transformation at the end of
the story, who survives the fight, and we all cry, and we go that's
true. That's all you have to do. That's a worldview transformation
story. So the choice is, am I going to fall in love with my bullshit
goal state? Or am I actually going to constantly be thinking about what
the goal state actually means? And reconfiguring reframing my worldview,
such that I'm serving something bigger than myself? That's a worldview
transformation.

Tim Grahl 42:53\
Alright, so there's a question here. And it's talking about tracking the
value ship scene by scene. So in an action genre, we'd be tracking the
life to death value shift from scene by scene. And the question is, are
there recipes to how to architect a Sequence of Value shifts for the
whole story? When I thought of this, I thought of finding a master work
but But what do you think?

Shawn Coyne 43:18\
I just gave you the Master. I just gave you the recipe. It's called self
organizing criticality. So that's what you do is you do a sequence of
scenes following the natural world such that the the life force,
increases, decreases, increases, decreases, increases, increases
decreases, right and you want a frequency of surprise, such that Sam
doesn't anticipate where you're going before you get there. So self
organizing criticality is about phase shift phase shifting of value. So
the progressive complications leads to a critical moment when it tips
the value. So somebody thinks something's enlivening and it turns out to
be depleting, right? I'm going I won the lottery. I'm so filled with
life. Hey, can you lend me a million bucks? Oh, you jerk, right? Why
don't you give me any more money? Oh my God, I wish I've never won this
lottery. Everybody's coming out of the woodwork and trying to take
everything I don't know who to fund who not to fund. I don't know what
to do. This is really depleting me. That that is the way that's the
formula. That's the just follow the natural world. self organizing
criticality is occurring as the coincidental inciting incident and then
the causal and correlation. It's the same process that does that, too.
So let's say like in the example I gave earlier, there's there's
somebody who, yeah, they're they're not your favorite person in the
world, but yeah, whatever. Right. And so there's a pile of sand in your
head that says I'm just not going to really engage with that person or
you know, forget it. I'm just not going to care. And then somebody else
tells you, hey, you know what they said about you? And it cost you your
emotion. They said that you're a liar. Right? And then bang. Are you
fucking kidding me? They called me a liar. I didn't get the promotion. I
can't put my kids in that school. I wanted to because of them, and the
sand gets bigger and bigger and bigger. And then before you know it,
hey, oak that's that's a phase transition. And it's a right. That's the
way you have to think about moving the sequence, sequential movement of
the story, and then making choices. Well do I put the scene where the
gossip is transferred to the person on the page? Or do I use it as a
payoff later? I don't know. But the formula is very simple. It's called
the Five commandments of storytelling. It's also called self organizing
criticality. It's also called relevance realization. There's all kinds
of language and a different ways to look at it. The formula is very
simple. The execution of phase transition such that it flows and is
understandable by your SAM that's a whole other kettle of fish. So there
is no single formula that is going to and you know what, people get sick
of the formula. So you got to be you got to create your own patterns.
There is no perfect pattern. You have to make your pattern or then it
seems like bullshit. It seems like a machine did it. And we think the
machines are going to save us but they can just all they can do is
imitate patterns. They can't create new patterns, yet we are the things
that make the new patterns we are the creators. So formula creates
copies. Right? So a formula for cookies will create a semi reproducible
copy of a cookie that somebody actually invented. But in his story, if
you're just copying cookie cutter stuff, I don't know why you would do
it. Because you're not creating anything. You're not expressing
yourself. You're not figuring anything out. You're just copying a copy
of a copy of a copy of a copy. And that doesn't seem all that fun to me.
But, but the formula is easy. It's the five commandments and
storytelling. That's why we call it story grid, one on one. And it's
been around a long time. I didn't I didn't invent it. Next.

Tim Grahl 48:18\
I mean, I guess I was thinking. This is like what we did with the end
mcbaine project, but on a smaller scale of a scene instead of a novel,
but this is where you find your master work. And look at how a master
did the value shifts throughout the story as a way to have some sort of
pattern to follow?

Shawn Coyne 48:41\
Absolutely, would you agree with that? Absolutely. And I'm not I'm not
saying not to study the masterworks because that that is the
inspirational stuff. If you don't have aspirational goal states, then
what are you shooting for? So definitely, yeah, the masterworks is
great, and do the analysis and then work through it, and then make it
yours. So the story that you wrote him after the Ed mcbaine story there
they were different. There was a lot of different emphasis based upon
your what you wanted to do. But that was an exercise to there are means
by which you can get the flow of how to do this through masterwork
analysis. Absolutely. But I guess my hackles get up when when I hear
formula. Because it sounds like can you give me a shortcut? Can you make
it less hard? Can you just give it to me and I'm sure that wasn't the
spirit of the question. So maybe I'm just in a cranky mood. But that
that does seem the evidence of a master writer storyteller, making
something fresh and creative and new. is great. And it will only make
you think harder about what you want to say. So yes, Tim, thank you for
the correction. I agree with you.

Tim Grahl 50:17\
What is the relationship between the controlling idea of the story and
the double? Factor problem in the pop a narrative device?

Shawn Coyne 50:29\
The controlling idea, and the double factor problem. These are all about
what do you do when you don't know what to do? So the relationship is
it's an exploratory, you want to find a particular domain of experience
that has that that has no solution to it. There's no algorithm that's
going to tell you who to marry. There's no algorithm that's that's going
to tell you whether you should go to college or not. These are double
these are double factor problems, right? Because what do you do in those
situations? You Oh, well, I don't know. I'll make a list of all the good
things are going to college and all the things that are limiting about
going to college and then yeah, and then you have a list. Okay, so
that's the problem space. Should I do this or that? Where should i What
should I do? What decisions should I make? And there's no easy answer.
So the controlling idea is, is about how someone did come up with an
answer, or didn't do very well answering the question. So, the
controlling idea does go all the way to the top of the period which
which is what I was talking about earlier, about what behaviors in this
world will will enable life to continue versus will destroy life? That's
the ultimate question. How do I navigate the world such that the, the
things that I create, exceed those things that I destroy so that the net
effect of my life is symbolically aligned with the archetypical pattern
of creation? At the end of my life, do I want people to think that they
gave it their all and they created as much as they could, and they did
their best to stop things that we're distracted. That would be that
would be a good controlling idea to have a problem space and the pop.
These are all very technical things that I can't give simple answers to
at this time. There there D deep philosophical questions that are
constructed, so that you're going to have to make that you're going to
have to figure that out. What do I mean by controlling idea? Let me ask
you, what do you think that means? These are the questions that or I can
tell you what it means. And you might be like, Ah, it's not that it's
not that deep. It has nothing to do with creation. I just want to my
controlling ideas to have an exciting story that hits the New York Times
bestseller list. How's that for a controlling right and I would say
that's not going to work. Because it's not sustainable. Believe it or
not, the rush for validation and money is not sustainable. It's not
going to get you to the end of your story. Because you'll you know, deep
down that doesn't mean it's gonna make you happy. It's not going to make
you fulfilled. So controlling idea, hops, problem spaces, these are the
things that that we're all trying to figure out. And just as Sam has,
she tunes into particular signals and sees the world in one of those
genres you probably do too. I know I do. And when I get stuck on one
signal, I try and go to another one and say, Well, what what would what
would the story be if I concentrated on the relationship or, or what
would the story be if I concentrate on the problem solving horrific
part? And this is the way you can sort of move around a very difficult
problem. There's a fame I think I've talked about this before, but
there's a famous experiment. Mind, you know, it's one of those mind
insight problems. It's called the Dunker radiation experiment. And so
they bring people into a room and they say, Okay, here's the situation.
There's a patient, you're a doctor, and they have a tumor in the center
of their brain. That any direct radiation will not kill it. So there's
no single firing that will kill that tumor. How are you going to save
that patient? So the answer is, well, you put a halo around the head and
you do small radiations and they all converge right in the center of the
tumor, and that's how you kill the tumor. So there's no one answer that
will kill the tumor. You need to circle it with different points of view
that will be able to converge in the middle. That's what our six core
genres do is that you need to know the problem spaces and then emphasize
one of them. And then the other ones are like these little radiation,
things that help break up the problem. But if you're trying to pump just
one signal the entire time, it's just not going to feel real. So anyway,
I'm sure I didn't answer the question in the way that you wanted me to
answer it, but it's it's it's a no that took me I don't know 27 years to
come up with controlling idea pop and, and whatever the other thing it
is that you were mentioned, I don't even like this this. This is complex
shit. And and it shouldn't be. You know, that's your life is complex, so
it makes perfect sense. So, working through the curriculum, as difficult
as it is, it's not going to come immediately. It's not going to happen.
Each each step each session if you know a little bit more than you did
before. It's something a couple of things happen for you that that you
go okay, I kind of get that. Then you're on the right track. What's
going to happen is like those grains of sand, right, you're all getting
tight. little grains of sand with each lesson from Danielle or Lesley.
And you're like, what's, what's all this pile of sand? It doesn't make
any sense to me anymore. When you just keep piling more sand on this
thing. And then bang, bang, bang and if you're patient there's gonna be
a grain of sand that's going to tip you and you're gonna go into a phase
transition. And you're gonna go Oh, my God, okay, I get it now. I get
it. Yes, this this makes sense. There I get what he means by the blue
now. Oh, but it's it takes a while, like anything does that's
worthwhile. So there's no simple solution that I can answer like, can
you tip over my castle before and you don't have any sand yet? You have
like one layer of sand and you're like, Can you can you tempt me into
phase transition? So I don't have to do you have to go through all that
other sand? I can't. Only you can.

Tim Grahl 58:27\
Yeah, I've had this with the narrative path. Where I listen, you've been
doing this. You guys came up with it. I went to the narrative path
workshop. And then now I'm working with Lesley through my own narrative
path. And it's like, oh, now I understand what you mean by the double
factor problem or figuring out the helpers and harbors and what they're
doing in a story and like all of those things. And it just takes that
like beating your head against it long enough for it to fall into a in

Shawn Coyne 59:02\
the double factor problem. Let me just talk about that for a second.
Because this really drives people nuts for some reason. It's this
simple. Okay, you can have a 55 year beautiful, wonderful marriage with
a person that makes you so happy and you can also sleep with whoever you
want and do whatever you want. You can go out every night with your
friends. Is that possible? No. You can't have both. Right. That's when a
commitment to another human being means. So when people say you can have
an all you can have every everything you want. That's a lie. You have to
make a choice, which is more important to me. A relationship with a
person that I can grow with and be with to get for a long time. And it's
going to have a lot of turmoil, a lot of challenges. But at least I am
going to be building something or I can have a lot of fun all the time
as whenever I can do whatever I want whenever I want. That's a double
factor problem. And so that's a like, what's the answer to that? Because
sometimes you do want to go out and sometimes you do want to be with the
other person. How do you manage yourself in that time when you don't
want what you have? Do you throw it away? Or not? Do you take that job
or not? Do you go to Europe or not? Do you get the dog or not? These are
the binary choices that there's no free lunch yet can't have it all.
That these are the problems that we face. There's no single solution.
There's positive and negatives for both sides. That's why food like food
is great. Well, if you don't have enough food, you starve. If you have
too much food, you die of diabetes. You got to get somewhere in between.
These are the impossible difficulties. of life itself. And there's no
algorithmic solution to these problems. They're called Insight problems.
And so you constantly have to be thinking about what do I hold at the
top? What is the most important thing? What archetypical form of the
universe would I want to join? Do I want to join the one that's all
about? Do I want to be a monster a lion or a person? Well, you need all
three and they you know they all have to play together and they have to
work together. So that the logos of that Trinity will conform to one
particular you know that religion This is why we have religions they're
saying there's there's good and there's evil sorry, weird mood today and
I hope I'm not.

Tim Grahl 1:02:27\
That's good. Well actually stopped there. Yeah, yeah. Well, I mean,
covering the double factor problem was good. It takes a while to kind of
wrap your head around. So yeah, I think that's good. All right. So we'll
stop there. Next week is our instructor q&a. And so we'll send out the
link where you can submit questions for that. And that will be within yo
and otherwise, we'll see you down the road. Thanks, everybody for being
here. today. Have a great rest of your day.

Transcribed by https://otter.ai
