---
title: The Name of the Rose: Fundamentals
author: 
publisher: https://guild.storygrid.com
URI: https://guild.storygrid.com/guild-training/week-9-the-name-of-the-rose-fundamentals/  
---

# The Name of the Rose: Fundamentals


## Week 9: Misattunement (Part 3)

## Week 9 Handout


## Application: Internal Subsource in _The Name of the Rose_

<iframe loading="lazy" title="W9_TNOTR" src="https://player.vimeo.com/video/802386706?h=1ffe18181b&amp;dnt=1&amp;app_id=122963" width="680" height="383" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen=""></iframe>

___

## Your Worksheet

In your worksheet this week, you’ll analyze beats from the example scenes that we’ve studied so far this semester.

For your writing exercise, you’ll build a foundation for your avatars’ internal subsources by exploring why they act.

