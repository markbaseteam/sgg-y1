---

---

# Week 3: The Name of the Rose: Fundamentals

## Contents

1. [[#This Week’s Objectives|This Week’s Objectives]]
2. [[#Masterwork Scene: _The Name of the Rose_ by Umberto Eco (Week 3 Handout)|Masterwork Scene: _The Name of the Rose_ by Umberto Eco (Week 3 Handout)]]
3. [[#Application: Scene Event Synthesis in _The Name of the Rose_|Application: Scene Event Synthesis in _The Name of the Rose_]]
	1. [[#Application: Scene Event Synthesis in _The Name of the Rose_#Outline|Outline]]
	2. [[#Application: Scene Event Synthesis in _The Name of the Rose_#Video|Video]]
	3. [[#Application: Scene Event Synthesis in _The Name of the Rose_#Transcript|Transcript]]
4. [[#Application: The Five Commandments of Storytelling in _The Name of the Rose_|Application: The Five Commandments of Storytelling in _The Name of the Rose_]]
	1. [[#Application: The Five Commandments of Storytelling in _The Name of the Rose_#Video|Video]]
	2. [[#Application: The Five Commandments of Storytelling in _The Name of the Rose_#Transcript|Transcript]]
5. [[#Worksheet|Worksheet]]

## This Week’s Objectives

- Topics we’ll cover:
	- Scene Event Synthesis
	- The Five Commandments of Storytelling
- This week, it will be a big win if you can:
	- Plan an iteration of the masterwork pattern scene using the essential features of each commandment.

## Masterwork Scene: _The Name of the Rose_ by Umberto Eco (Week 3 Handout)

This is the [[02 - Masterwork-Scene-The-Name-of-the-Rose-Week-3.pdf|text]] of the masterwork pattern scene from _The Name of the Rose_, with our analysis of the scene for the concepts that we cover in this week’s training.

## Application: Scene Event Synthesis in _The Name of the Rose_

### Outline

### Video

<iframe loading="lazy" title="TNOTR_W3_SES" src="https://player.vimeo.com/video/789393459?h=4fc192e531&amp;dnt=1&amp;app_id=122963" width="680" height="383" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen=""></iframe>

### Transcript

Danielle Kiowski  
00:03  
Now that we've gone over the four questions in the Scene Event Synthesis, let's answer them for our masterwork pattern scene from The Name of the Rose by Umberto Eco. We'll start with our first question. The on the surface question. So:

==What are the avatars literally doing? That is, what are their micro on the surface actions?==

So for all of these questions, we will have the full answers in the handout. But in the slides, to keep it more readable, we just have a summary of what is going on. So here we have that one line summary that:

==William takes the case with conditions.==

So in the overall scheme of things, right, this is a role negotiation scene, and he is taking the job. And so ==that's a little bookmark that we put in place to help ourselves remember what happened in this scene.==

Leslie Watts  
00:52  
Right and this is a perfect summary of the on the surface action, right, what's happening in this scene. And if we break down what they're, you know, what they're actually doing in different, you know, throughout the scene, you have conversation, but overall, what's really important what we need to take away and the way that we can, in order to create an iteration of this pattern scene, what we need to understand is that the protagonist takes the case ultimately, and of course, with conditions. That's a really important aspect of what's happening here in the scene.

Danielle Kiowski  
01:39  
Yes, exactly. And then the next step is to dig a little bit deeper into why that scene event takes place. And so here we go into our second question, which is above the surface and that is:

What is the essential tactic of the avatars? That is what above the surface macro behaviors are they employing that are linked to a universal human value?

When we answer this question, we want to make sure that we have a comprehensive view of the scene. So look at the main players in the scene, and answer this question for them. And for the protagonist and the antagonist, in particular, trying to make sure that their essential tactics are–they “comment on” each other in some way. And so that's our focus when we come up with our essential tactics here.

William applies logic to pursue the truth, and Abo manipulates the truth to maintain his power.

So these two players in the role negotiation scene have slightly different ends. So this isn't something where they're working in parallel and they have different methodologies. But Abo really wants to maintain his status and William is pursuing the truth. And so, because William has the truth as an end, and Abbo has it as a means, they’re at cross purposes. And so we see that their essential tactics directly conflict with each other. And that's what I mean by those essential tactics commenting on each other, that they conflict with each other in such a way that it makes conflict inevitable within the scene.

Leslie Watts  
03:05  
Right. And this harkens back to what we talked about in the POP between the dueling hierarchies as well. It doesn't always work out that clearly as it does here, but that's definitely what's going on. They are representatives of the two hierarchies. And so they are almost the embodiment of that, of that here. So it's really important that, that, and I think it's interesting that for William the truth is the end. And for Abo manipulating the truth is how he's going about reaching what he wants, his goal–which is to maintain his power. So it's really fascinating and, as we've found every time we've looked at the essential tactics of the two primary forces within a scene, you do see this, this lovely kind of, it's not the same, but there are similarities, there's a little overlap, but then there's a key difference that creates the conflict in the scene itself.

Danielle Kiowski  
04:25  
Yeah, I think the essential tactic is a really great exercise to understand not only the core of each avatar, but also their relationship to each other. So you can understand, are they going down parallel paths? Are they at cross purposes, are they directly in conflict? And you can start to think about them in that directional way, and build the movement of the scene accordingly. So here, we see this cross purpose, and we're going to see a lot of covert action as they sort of weave over each other to find the winner of this role negotiation. And as they negotiate that movement within the scene, then what we see is that the scene shifts over time, right? That's the stuff of story is that change and the value shift. And when we see that shift happen, what we're eventually going to see is who wins out, and we're going to see that in the value shift that is realized in the scene. And so that brings us to question three:

What beyond the surface universal human values have changed for one or more avatars in the scene, and which one of those value changes is most important and should be included in the story grid spreadsheet?

Now, don't get scared about that. We are not doing the spreadsheet, but we include that to show you the links between the different tools in the methodology. But we won't be doing a spreadsheet for this course because we're just looking at the one scene. And so what we have for our value change is unbound to constrained

Now, this is an interesting one because when you evaluate the value shift, you're looking at how the scene moves on that global value. And so for us, that's justice. This is a crime story. And so I think that when you first read through it, you might think, ‘Oh, well, you get closer to justice,’ because he takes the job. He's gonna solve the case. But what we did is, we went through this thought experiment, what would happen if the scene didn't happen? If Abo didn't give him the job? And I mean, it's William. We know he's a smart cookie. He's going to look around and he's going to see that something is amiss, and he's probably going to solve it, but he would be able to solve it. If he came to it on his own, he would be able to solve on his own terms and without the constraints that hold him to the abbey’s rules because the abbot wouldn't have given him these constraints at the outset. And so, William goes from this unbound force for justice to a constrained force for justice. Who has to operate within the hierarchy of the Abbey. Right and

Leslie Watts  
06:57  
Right and so what we're showing through this value shift is one–this is how it ends. Abo wins–Abo ends up, he's able to constrain William. But we're also seeing and this is really important. We are also seeing how Adso is illuminating or identifying the problem through this change, through, its the appearance at the beginning that William is such a capable agent, that he is not, that there's no way that you would believe that he would be constrained. He's eating excellent raisins in his room, right? He's not conforming to the culture of this new context. They're enabling him to do that, you know, to do certain things his way. So you wouldn't expect that he would, that he would move in this way. So it's unexpected and through this, and through the way that that's executed in the five commandments, which we'll see, that that's exactly how the author Adso is signaling to SAM. ‘There's a problem here. Do you see it? Do you see it?’ Right and, and it's so it's a really, it's really clear that, and we want to see a value shift like this in a story like this where we're identifying a problem. But it's a subtle thing. Right? Because he gets the job, but he is constrained. So it's an interesting, interesting setup, and interesting value shift here in the inciting incident.

Danielle Kiowski  
08:55  
Yes, I love that. And what I'm thinking about is how it ties together that opportunity and threat within the same inciting incident. And so, it really creates an interesting dynamic where the protagonist will have to find his way through the dual nature of that event. So the last step is to bring these together into the fourth question: the scene event synthesis. And that is:

What story event sums up the scene’s on-the-surface, above-the-surface and beyond-the-surface change? We will enter that event in the story grid spreadsheet.

Again, we won't. But that would be what we would do if we were doing a scene level spreadsheet and for this one, we have a formula. So to remind you, that is

[Ending Value] when [Success/Failure of ATS essential Tactic] by [Climax OTS] despite [tradeoff]

And so, you know, we may play with the prepositions and a little bit of nudging here and there to make this work. But the key to this is that you can take all of these components and make that cohesive, coherent sentence, because if you can't do that, then one of your components is off. So it's really important to do this. This isn't just an extra step. This is like the validating step where you make sure that all of your work before this is right and then, if you don't get that right, then you go back. You don't change it here, you change it before, and then bring it back here and see if it works. And so that is what we did to come up with.

William is constrained when he abandons his pursuit of logic by taking the case while bound by the rules of the monastery.

And so we have all of those components there, where we have that constraint, the ending value, the failure of his essential tactic, because he's outwitted by Abo. And, but he's outwitted, but he still makes the decision, right, to take the case. So he is implicated in his own downfall there. So he takes the case, and while bound by the rules of monastery is the trade off, and so that's something that we've talked about as we've gone through this, but we'll definitely see that come to fruition as we look at the five commandments, and look at all of the trade offs that are built into the progression from one value state to the next.

Leslie Watts  
11:12  
Right, the scene event synthesis. The thing I love about it is that we're incorporating the three questions or the responses to the three questions that come before but it's also, this is what we need to enact in those, in the five commandments. So we're still linking everything up as we go. And of course, this is the mini lesson that the author is offering to SAM to illuminate a problem, and here it is Adso trying to help this future monk to identify a problem. ‘Do you see?’, again, ‘do you see this problem? Can you see how he has constrained himself because he agrees to be bound by the rules in the pursuit of his investigation.’ So we, it's a really, it's almost like if you had said this, if you'd offered the scene event synthesis to William he might have said, ‘Wait a minute, what am I doing?’ But of course, he can't see it, and that's that aspect of SAM's problem that we brought up before, right, that when we talked last week when we talked about SAM's specific problem, it's that inability to see what's actually going on here. So that's why it's so useful. To illuminate SAM's problem.

## Application: The Five Commandments of Storytelling in _The Name of the Rose_

### Video

<iframe loading="lazy" title="TNOTR_W3_5C" src="https://player.vimeo.com/video/789391392?h=21d4d19495&amp;dnt=1&amp;app_id=122963" width="680" height="383" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen=""></iframe>

### Transcript

Danielle Kiowski  
00:03  
Now that we've talked about the Five Commandments of storytelling conceptually, let's identify them in our masterwork pattern scene from the Name of the Rose by Umberto Eco. We will start at the beginning with our inciting incident. So we talked about the inciting incident a little bit in the POP, and we talked about Adelmo’s death. But here we want to look specifically at the scene and how that shows up in the scene. And what we've identified is that it's a causal inciting incident where Abo, the Abbot, tasks William to investigate the mysterious death of the monk Adelmo. So it's still centered around Adelmo’s death–that's still the global inciting incident. But what we want to identify is when William’s world gets knocked off balance by his encounter with this inciting incident, and that is when Abo the abbot communicates that event, the presence of that event.

Leslie Watts  
00:58  
Right, and this is similar to the global inciting incident, as well. It’s that we have this, the opportunity and the threat embedded within the same event. So we have this thing, this request, and of course, William is seeing this as his entree to the library, right? He's going to be able to go in, go in to investigate it. Of course, that's not exactly how it works out, as we will see as the five commandments continue.

Leslie Watts  
01:35  
That's right. And they continue with the turning point progressive complication. And so this is when William’s initial strategy–getting into the library, as you just talked about–fails, and he needs to confront the inevitability of a shift in the global value. And so, you know, William is really angling for that library visit right from the beginning. He knows that Adelmo died near the library, he really wants to get into it, and he keeps talking about, he's trying to impress Abo right, He's trying to impress him, so that he can, as you said, gain entry into the library. But at the turning point progressive complication, William figures out that that is not the case. Abo forbids Williams to visit the library, making it clear that he wants to mystery of Adelmo’s death solved on his own terms. And the connection that's really important here is that this complicates out of that initial inciting incident. So, as you said, there's this veiled threat within the communication of the event of Adelmo’s death because Abo is trying to constrain him, not actually give him an opportunity to solve the case and he's doing both. But that constraint is hidden until such time as the conflict between the two pushes it out into the open in this turning point, progressive complication.

Leslie Watts  
03:00  
Right. And if we connect this back to the narrative device and what the author is trying to illuminate for SAM, we can see that that Adso is showing exactly where William goes wrong. Right? That he's shown his hand early, right, with his enthusiasm and, and his desire to be involved. And, and then the thing that he wanted, you know, the thing that was going to be, probably in William’s mind, a kind of quid pro quo, right? ‘I'll solve this for you Abo if you let me into the library,’ that's not on the table. It's completely off the table. And then he's still stuck with his essential tactic, which is about revealing the truth, pursuing the truth. Right, and so he can't in good conscience, turn Abo down, he's in a really sticky bind there. And we'll talk more about that in the crisis. But what this really does is, it doesn't give William a way to save face and remain unconstrained.

Danielle Kiowski  
04:27  
Yes, I love how you put that because it really does back him into a corner and that is the function of the turning point progressive complication. So something's going to happen relating to injustice in the scene. And William just has to make the decision in the climax to determine how much injustice there's going to be. And something that we talked about in previous weeks, is that he is there for this delegation, to talk, to negotiate the doctrine on the poverty of Christ. And so he is set against this backdrop of a need to perform in the context that will have implications for what he sees as the level of justice in the church overall. And so there are big stakes for him, not fitting in here. And so combined with his natural need to pursue the truth, that backdrop of that performance is, weighs heavily, and as you said it forced him into this dilemma.

Danielle Kiowski  
05:27  
So let's take a look at that dilemma. And that is the crisis. So, at the very basic level, it’s should William take the role of investigating Adelmo’s death or refuse it? And in a role negotiation, that's what it comes down to. Your protagonist needs to determine whether they will take the job or refuse it. What we also want to do is look at how this relates to the double factor problem. Because a role negotiation scene can have different double factor problems, right? There are many different stories that we see that have role negotiation scenes, and they don't all have the same double factor problem. But what needs to happen is that one of those choices, taking the job or refusing it, each of those choices needs to correspond to one of the overall categorical choices in the double factor problem. And so here, we have associated exposing the truth now with refusing the job, or waiting is about taking the job. And the reason for that is that if William refuses the job now and he gives that answer that Abo is a tyrant, and this is ridiculous, and he's not going to stand for this kind of thing, that he's exposing this, this nugget of injustice, but potentially leaving more injustice to continue unchecked. Whereas if he waits, he's letting Abo’s corruption in this moment, right, his tyranny in the scene go unchecked, but he may have the potential to challenge the system later down the line.

Leslie Watts  
07:06  
And as you can see in the crisis matrix itself, there is a risk of injustice no matter what William chooses to do. So we're fully locked into this value shift. And, there is going to be injustice no matter how he chooses to proceed. And what he, what he ends up doing, of course, we'll talk about in the climax, but understanding what's at stake at each of these levels and how they connect to justice or injustice will be really important in an iteration of a scene like this, right, where you want to, you're trying to capture the dilemma that the protagonist faces and this specific iteration within the story of the double factor problem and how the protagonist has to deal with it. You want to set up all of these, all of these risks and that it's really important, but I think that it's really, the thing that should kind of rise to the top is the risk of injustice for Adelmo right up through everyone within the church based on William’s role, primary role that he's supposed to engage with here at the Abbey which is as a representative of the Emperor and and putting forth and arguing for this particular ecclesiastic position that, that Christ did not own his clothes.

Danielle Kiowski  
09:04  
Yes, that's such a great point. And we can see that really coming out in the beyond-the-surface row of that crisis matrix where we're talking about William's relationship to justice because this is where the universal pattern shows up. And, and so if he refuses the job, he is as you're saying, he's rejecting justice for Adelmo. And he's also, beyond that, putting the innocent of the order at the mercy of the abbot. Because the Abbot, he's not worried about truth, right? He's very willing to scapegoat people. Willing to set people up who don't fit into his hierarchy. And so that's part of that, you know, William would be, in essence just leaving them to the Abbot’s mercy. But at the same time, then if he takes the job, he becomes an agent of the tyranny, and so you can try to fight from within but you know, how much is he actually going to be able to fight from within? We've already seen the Abo was a capable agent who was able to hoodwink him. And so, you will have to explore over the course of the story. How much William plays into Abo’s hand without even realizing it. And as you're saying that's a real risk to justice on both sides of this equation. And then when we have that risk to justice at the blue level, that also has ramifications for our survival or safety stakes. And so what we see is that at the green level he risks future murders, you know, because Adelmo is not the only one in danger, as we see. And as Adso the author foreshadows in the scene. There are plenty of future people in danger, or he can risk his own safety by getting involved in the pursuit of the murder and in fact he does, right so he takes the job and then eventually Jorge tries, quite unsuccessfully, to kill him. But it is still on the table, that that might happen. And that physical danger and, you know, really the spiritual danger of his involvement with the tyranny - those two come together to really affect his information processing. And that's where we're getting at, you know, the heightened scrutiny from the Abbot, or his agency being constrained by the limitations of the role and that's him, having to come into contact with that double factor problem, really wrestle with it and see what his role is. And so as you were alluding to, this is where we get to this really comprehensive engagement with the problem on the part of the protagonist because they're having to engage with it at all of these three Trinity planes.

Leslie Watts  
11:38  
Right, exactly. And, and so to me, what really pops out of the red level is the information processing but it's also the power. Either way he loses power and that is, that's unfortunate, because William is a capable agent right? We want people like William to have agency to expose injustice. And you know, he is, it, you know, there are many paths to having your agency constrained. And in this case, it's really, it's what we have, what we have with Adso communicating to the monk is - there are lots of ways to give your power away. There are lots of ways to, you know, to not be in a good position to have all the facts so that you can expose injustice. And so I think that this is, this is a really important way that this is being communicated and the narrative device helps to choose and incorporate these facts that are really setting up the double factor problem that also are bringing in SAM's problem of over relying on that, that single pattern.

Danielle Kiowski  
13:08  
So let's take a look at our climax to see how William navigates this problem in this particular scene. It's still at the beginning, so not extra successfully. And here William agrees to investigate Adelmo’s death. So he does take the job, as we've been talking about, and you know, as we've also been talking about, he's really in mitigation mode at this point. He has been backed into a corner. He has been outwitted, which is embarrassing for him because that's what his bread and butter is. And now he has to make the least harmful decision. And in the moment he believes that that is agreeing to investigate Adelmo’s death on behalf of the abbot.

Leslie Watts  
13:46  
Right and what one thing that's that I think is interesting about this is that while he is agreeing overtly, to you know, to investigate within the constraints that Abo sets. Covertly, William is thinking to himself, ‘I will do it his way until I can do it my way.’ And so I think that this is the kind of deal that he's making with himself. That if, if we go back to point of view, and if this were William’s account, we would understand that, but because we don’t have, because that's not really what, the story isn’t about how William formulated this, or how he chose to solve it. It's about identifying the problem. So it makes more sense for us to be not seeing what he's doing, but just knowing after the fact that that's how he conducts himself. So this is an important, important thing to know about the way that the protagonist enacts their agency, which is limited by the turning point progressive complication, but how they enact, the only choice they really can make in this crisis to hang on to whatever, whatever scrap of agency they essentially have left. So it's, yeah, so we want to make sure that that's something we're considering when we're creating the climax for our own iterations.

Danielle Kiowski  
15:31  
Yes, and as you said, he is trying to cling to that agency, but the balance of power has shifted in Abo’s favor. Now of course, this is for now, because as you said, William has some stuff in his pocket. He thinks that he will be able to reclaim the power in the situation. And what he doesn't know is how hard of a struggle that is really going to be and how many things are going to happen along the way. And so, you know, when we look at the resolution, we look at how it's tied to the crisis. And so we want to make sure that it treats everything from our crisis matrix. And we've already talked about how he does put his own life at risk because Jorge eventually tries to kill him. And we also have his power being limited by his position in the hierarchy. That's absolutely true. Now, he has to, because he would always be subject to the rules of the monastery, but now he has overtly agreed to them. So now he has to be even sneakier about trying to get into the library and trying to avoid the scrutiny of the abbot. Right. And, you know, he does also become an agent of the tyranny. So he has to report back to Abo. And through all of this, through acting on behalf of the Abbot, he brings attention to the things that are going on at the monastery.; And then things start moving perhaps even at a faster rate than they would have if he were investigating in a more covert manner, and just kind of paying attention to things and acting as an outsider. But that pressure on the situation and the pressure of having an official agent on it, I think increases the pace of the events that are unfolding and ultimately destroying at the monastery.

Leslie Watts  
17:14  
Yes, and what's really interesting here, of course, everyone is subject to the double factor problem Abo as well, right and so in this situation, although he (Abo) gets the upper hand and he is able to constrain to constrain William, William is secretly planning to go around him, right, to try to get around him. And we get a hint of this, right, this is a moment when Adso chooses to give us a teeny bit of foreshadowing before pulling it back. And when he says ‘he went out and he did a disservice to his reputation as a clever man’, so Abo too is a clever man who's being taken down in Adso’s estimation at this point, but it's because, in part, of what William actually intends to do and what Adso later, you know, with his current perspective, knows. I say, ‘current perspective,’ let me make sure I'm clear about that. With the perspective when he's telling the story when he's writing all of this down, he knows that William does not obey Abo but, moreover, Abo thinks he's got this contained. And so he's a little flippant there when he says, ‘Oh, that's not the blood that concerns you’ when he's talking about the squealing pigs. And what, of course, turns out to happen in the next scene, later, a little later in the story is that it does actually concern William, it is another death in the Abbey. And because Abo has already given William the, the job to investigate. He can't constrain him from investigating the latest death.

___

## Worksheet

In your worksheet this week, you’ll analyze the Scene Event Synthesis and Five Commandments of Storytelling for the Role Negotiation scene from _The Shining_ and compare it to the masterwork pattern scene.

You’ll also continue to plan your iteration of the masterwork pattern scene by developing your own Scene Event Synthesis and Five Commandments.

As you build your plan for your scene, use the following constraints and checks to ensure that you are coming up with a scenario that will fit the masterwork pattern.

**Scene Event Synthesis Constraints**

Question 1: Role negotiation scene between two avatars with an observer.

Question 2: The protagonist and antagonist must have directly opposing essential tactics.

Question 3: The value shift is some version of Unbound to Constrained. You might give it a different lens based on the genre.

Question 4: Follow the formula from the training to synthesize 1-3.

**Five Commandments of Storytelling**

Inciting Incident: The interviewer tells the interviewee about the event that threatens the hierarchy.

Turning Point Progressive Complication: The interviewer places the most important constraint on the interviewee.

Crisis: Take the job or not? (But build out your own matrix of stakes)

Climax: Takes the job.

Resolution: Balance of power has shifted in the interviewer’s favor.
