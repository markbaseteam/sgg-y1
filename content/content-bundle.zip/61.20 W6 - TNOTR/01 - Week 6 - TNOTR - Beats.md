---

---

# The Name of the Rose: Fundamentals

## Week 6: Introduction to Beats

## This Week’s Objectives

-   Topics we’ll cover:
    -   Input and Output
    -   The Role of the Protagonist
    -   The Spectrum of Collapse
-   This week, it will be a big win if you can:
    -   Think of your writing in terms of inputs and outputs, and ensure that your protagonist is in the output position.

## Masterwork Scene: _The Name of the Rose_ by Umberto Eco

This is the beat breakdown text of the masterwork pattern scene. In this document, we break the text into Inputs and Outputs.

___

## Application: Active Build Up Beats in _The Name of the Rose_

<iframe loading="lazy" title="tnotr_w6" src="https://player.vimeo.com/video/795980364?h=517f66e3f6&amp;dnt=1&amp;app_id=122963" width="680" height="383" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen=""></iframe>

___

## Your Worksheet

In your worksheet this week, you’ll start working with a new example scene from Witi Ihimaera’s _The Whale Rider_ (attached below).

For your writing exercise, you’ll practice generating inputs and outputs and work with the sprectrum of collapse. 

___

Training Reflection Questions

Reflect: Did anything surprise you in today's training?

Reflect: Which topic is the most unclear to you?

Reflect: What is the most important thing that you learned today?

Reflect: What is one question that you'd like answered about today's topic?

___


