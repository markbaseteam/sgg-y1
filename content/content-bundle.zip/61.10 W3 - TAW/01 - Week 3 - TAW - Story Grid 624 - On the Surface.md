---

---

# Week 3: Story Grid 624 – On the Surface

## Masterwork Scene: _The Aeronaut’s Windlass_ by Jim Butcher, Chapter 2 (Week 3 Handout)

This is the text of the masterwork pattern scene from _The Aeronaut’s Windlass_, with our analysis of the scene for the concepts that we cover in this week’s training.

## Application: Scene Event Synthesis and The Five Commandments of Storytelling in _The Aeronaut’s Windlass_

<iframe loading="lazy" title="S3_W3_Application_TAW" src="https://player.vimeo.com/video/750854702?h=3475620fb0&amp;dnt=1&amp;app_id=122963" width="680" height="383" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen=""></iframe>

## Your Worksheet

In your worksheet this week, you’ll analyze the Scene Event Synthesis and Five Commandments of Storytelling for the Attack scene from _A Wizard of Earthsea_.

You’ll also continue to plan your iteration of the masterwork pattern scene by developing your own Scene Event Synthesis and Five Commandments.

As you build your plan for your scene, use the following constraints and checks to ensure that you are coming up with a scenario that will fit the masterwork pattern.

**Constraints**

_Scene Event Synthesis_

1.  On the Surface: Keep the nature of the summary event the same. Your protagonist narrowly avoids destruction, but takes a hit.
2.  Above the Surface: Ensure that your protagonist’s and antagonist’s essential tactics are in direct conflict and show their affiliation with growth hierarchies and power/dominance hierarchies respectively.
3.  Beyond the Surface: Negative to positive. Operates on the Life/Death value spectrum. Try to be as specific as possible to the nature of the tactics of your force of antagonism.
4.  Use the formula to check your work above.

_Five Commandments_

1.  Inciting Incident: Protagonist notices something about the antagonist that they did not expect, which changes the nature of the fight.
2.  Turning Point: A higher level of antagonism emerges, changing the balance of power.
3.  Crisis: Fight or Retreat?
    -   (OTS) Lives at risk.
    -   (ATS) Consider protagonist’s responsibility for others.
    -   (BTS) Use the potential identities that you identified in developing SAM’s problem last week.
4.  Climax: Retreat, which is complicated by an unseen part of the force of antagonism.
5.  Resolution: Ensure that you treat each of the Retreat options from the Crisis Matrix.
