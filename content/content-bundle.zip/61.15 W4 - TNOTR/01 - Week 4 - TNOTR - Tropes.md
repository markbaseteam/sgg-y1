---

---

# The Name of the Rose: Fundamentals

## Week 4: Tropes

### This Week’s Objectives

- Topics we’ll cover:
	- Tropes
- This week, it will be a big win if you can:
	- Have fun writing a first draft of your iteration of the masterwork pattern scene. It doesn’t have to be perfect!

## Masterwork Scene: _The Name of the Rose_ by Umberto Eco

This is the [[02 - Masterwork-Scene-The-Name-of-the-Rose.pdf|text of the masterwork pattern scene from _The Name of the Rose_]], with our analysis of the scene for the concepts that we cover in this week’s training.

## Application: Tropes in _The Name of the Rose_

![[03 - THE-NAME-OF-THE-ROSE_-TROPE-OVERVIEW.pdf]]

Week 4

Video 1, This Week's Topic: Tropes

Unknown Speaker 0:09

Hi, everyone. Welcome to week four of the story grid guild 2022 Training. I'm here with Danielle as usual, and this week Danielle, we have a really exciting topic to explore what's on the menu this week.

Unknown Speaker 0:28

Well, Leslie, this week we're going over tropes. And I love tropes. I've said this a couple of times in the forums talking to people, and I know you hear me say it a lot. But I just think that tropes are such a wonderful level of analysis, and I'm really looking forward to going over them. Now. I know I also said this last week because I really love the five commandments, and it's true. Really, I'm just a story nerd. But I think that tropes are really useful level of analysis that are going to help all of the guild members create the masterwork scene pattern iteration in a really streamlined focused way. And so, we started looking at this kind of analysis in the Ground Your Craft course. And it really does ground your craft. It grounds in the progression of the scene and shows you exactly what to do. So I am very much looking forward to going over this and showing you exactly how to use these tropes.

Unknown Speaker 1:24

Excellent. I can't wait. So what I want to know is why are we studying tropes now? Where do they fit in the big picture of what we're trying to accomplish this semesterin the guilt?

Unknown Speaker 1:39

Well, as we've been talking about each week, every topic builds on the last. So we started again with go through, go through it again. Because it's worth repeating to understand where we started and where we're, where we've gone and where we've been and where we're going in the future, you know, have the whole journey in mind.

Unknown Speaker 1:57

So we started with point of view in narrative device. And through coming up with our what if scenario in our narrative, narrative device and locking in our point of view, we formed the foundation for what the perspective of the story is. So then we had in the what if scenario we have a potential to play with, you could say, and so you have this area in which your story is going to operate, you have a kickoff event For it, which is your inciting incident. And then from there, you build that out with the four scene analysis questions, and the four questions or the three Trinity planes of perception made into questions that help you look at exactly what's going on in your scene. And we synthesize those in the fourth question into one story event. So this is your mini controlling idea for your scene. So we've taken you know the area and then we've collapsed it or crystallized it focused it into one sentence that describes our scene. And that's you can think of that as the deliverable or the outcome for those scene analysis questions.

Unknown Speaker 3:00

So now we have one thing, and then we say, Okay, well, I want to take this controlling idea, story event, and I want to communicate it. And we have ways to do that. Like I can tell you, you know, love triumphs when people cast aside their prejudices and learn to love one another for who they are. And that's true, but it's not very, it doesn't capture attention. It doesn't change anyone's mind. You're only going to agree with that statement, If you agree with that statement. And if you don't for whatever reason, then you're not going to have a worldview shift just because I throw a sentence at you. So if we want to reach our readers, we want to engage them. We want to make a difference. We have to actually write Pride and Prejudice instead of writing that sentence on a sheet of paper and hoping it sinks in somehow.

Unknown Speaker 3:00

So now we are faced with that question, what do we do with this sentence to do that? And the first step that we took is expanding it into the five commandments. That's what we did last week. And these are the really foundational principles of story. That's why they're called commandments. You got to have them and there are five of them that build the core arc of the story. And that's how you communicate that story event that many controlling idea in your scene to your reader. So now we have five things we've gone from one to five.

Unknown Speaker 4:17

And you know, sometimes when you have your five commandments planned out, you know, okay, I have to hit these goalposts along the way. But how do I even get there? You know, there's still when you have your scene, it's 1500 to 2000 words, and you have five things that you need to do. It's easy to wonder, how do I get from Point A to Point E, stopping at B, C and D along the way? Well, tropes will help you do exactly that.

Unknown Speaker 4:48

Now, I don't want everyone to you know, worry about that we're over planning, because this is a study tool. So by studying these tropes, we're going to learn how to take the five commandments and break them down into the trope level. And, by studying them you're going to build up patterns that you can recognize of how different tropes will fit together, and you're just building your library of skills. So again, this is about doing these really in depth analyses to learn these skills to build them into your mind and be able in the future to generate these things yourself. So we're going to study the masterwork scene pattern to understand the tropes right now, because they're going to build out the five commandments and help us actually execute.

Unknown Speaker 5:30

And this is part of what I love about Trumps, they're actually the bridge to directly on the page. So they're small enough that you can actually write them. They're small enough that you can really they're graspable, like you can get a hold of them and figure out exactly what words go on the page. But they're also you know, they're not at the micro beat level where it's hard to see how everything fits together. They they have enough macro in them, so that you can see the flow of the scene through these tropes and you can see how they're functioning at the Trinity Planes of Perception.

Unknown Speaker 6:02

That's amazing. I'm so excited to study this with you and I love the way that it takes us from--- because people have people struggled writers struggle with bridging the gap right exactly as you're talking about from these are the concepts or these are the things that need to happen in the scene, but how do I actually enact them? So it sounds like that's what you're talking about today?

Unknown Speaker 6:29

Well, so then my next question would be how do we identify these because we need to be able to pick them out so that we can enact them. So where do we start there?

Unknown Speaker 6:40

Yes, this is a great question. And it's something that is it's a skill that takes time to develop. So if you are reading through the masterwork scene and you say, I don't know where one trope starts, and the next one starts and how do I divide between them? That's perfectly okay for now. So that's why we're doing this for you in this masterwork pattern scene. So part of it is like we're doing with the beats perceptual exposure. You look at how we've divided up the beats, get a sense of you know, where where one thing starts and another stops. And you're going to build up intuition for where these beats go. So don't worry about having to do it yourself just yet.

Unknown Speaker 7:21

But of course, you eventually want to do it yourself. So when you do that, how do you do that? Well, here's the framework, and here are some things that could help you as you're looking at how to develop the beats. So again, we're going to start at the top, this is what we do, we go to the top and we figure out, you know, from first principles, what we're doing so luckily, I already gave you a spiel about what we're doing when we write a story. So we don't have to go all the way to the beginning. But let's think about that controlling idea.

Unknown Speaker 7:49

So, the controlling idea is what we want to communicate. Now we communicate it when we have the five commandments that work together to communicate this change. So also in the scene analysis, we talked about essential tactics, so you have your essential tactic. This is your object of desire, you have one at the global level, you know. So when you're when your global inciting incident kicks off, it is related to your controlling idea because it's genre specific. And so it kicks off your story. And it promises a certain genre of progression of your story arc, and it promises a climax and it promises that your resolution will give you an evaluation of the protagonist actions in a certain global value space.

Unknown Speaker 8:39

So like if it's a love story, you're going to find out whether acting like this protagonist in a situation like this will enable us to find love, or whether it will let hatred reign, right, so these are the two poles of the value. So so that's your inciting incident. It kicks off this global object of desire and it as we talked about last weeks, I won't get into the minutiae of it, but either creates it or crystallizes it. Okay, so now you have your global object of desire, and you have your global essential tactic you have a verb we talked about transitive verbs with this object of desire and at the global level, this is really big. Well, remember that at the global level, at the global story arc, you are making an argument for why you should or should not act like this protagonist. What that means is that you need to explore the full space of what it means to metabolize that inciting incident.

Unknown Speaker 9:43

Now, what that means is that when that inciting incident happens it has a lot of different facets, different ways, different contexts in which the protagonist needs to deal with it, looking at it in different directions, right? It's a ball of phere. I'm doing this with my hands and you couldn't really see that off screen but, but the inciting incident is this ball of chaos or a phere that drops in, right? Well as the ball, you can turn it over, you can look at it from all these different directions. And it's only when the protagonist has really gripped what this whole thing is about and understood it fully, that they can metabolize it and integrate it or you know, fail to also that's a possibility if it's an antihero path, but but they have to understand the full space of this inciting incident.

Unknown Speaker 10:33

So what that means for the object of desire is you have this global object of desire, which is maybe I've been using the love story example so it'sto find love. And so in a love story, you have this external need for love, you have a potential candidate. And then the question is, are you going to find love with this potential candidate to fulfill that need for love or not? So, like in Pride and Prejudice, \_\_\_\_\_\_\_\_\_\_\_ coming into town, creates that focus on them As the potential objects of desire. So, when you have this global object, now, you have to understand all of the aspects of it.

Unknown Speaker 11:13

So Darcy is set up as the potential love interest for Elizabeth. Now, this means that when we go down to the scene level, every scene needs to be an aspect actualization of that global inciting incident. And I know that that might sound like something that something that you might not have considered before but every scene has to do with that global inciting incident and with understanding the true nature of what's going on. Now, this is true, even if it's a sub plot scene, even if it's a complication or anything like that, because all of the inciting incidents are related to it, and that's why it shifts the global value.

Unknown Speaker 11:59

So you can think of that in terms of the--- in terms of second order effects, like Yeah, I think we've talked about this a little bit before, but maybe we haven't, but if not where we are now. About how, you know if if somebody in a love story gets a job in a town that's closer to the candidate of their further the love, then they're moving closer to love and stuff. Literally, in that case, they're moving closer to love. And so you can think about it in that way. So now you have moved from the global down to the scene level object of desire, which is an aspect of realization of the global. Okay, I promise we're getting to tropes. So starting from that inciting incident, as you learned in your in the five commandments training last week, you have an initial strategy that kicks off from that inciting incident and that's how they attempt to solve the problem presented by the scene level inciting incident until they get to the turning point, progressive complication, and that strategy fails. Now that is a specific instantiation of their essential tactic. So you know, what we've seen in the the Name of the Rose scene is that William seeks truth, loves truth. And he wants to do this at a couple of levels. Yes, he cares. He cares who commits murder. He wants to make sure that justice is served. He also wants to see the library. This is a very concrete object of desire in that scene. And so when the scene level inciting incident happens, and he learns that Adelmo died in the Aedeficium, he's like, Oh, this is an opportunity for me. To get into this space.

Unknown Speaker 13:49

So he has the scene level essential tactic of buttering up Abo in order to get into the Aedificium. So, when you then have this essential tactic, you know that it starts, it either starts or is focused by the inciting incident. You know that it fails that the turning point progressive complication. What happens in between? Well, what happens in between is that you'll have transformation micro transformations. So if you think about the whole strategy failing, parts of it will fail at a time. So and fail. Fail means like, meet with complications, and those could be positive or negative. But your protagonist understanding of the inciting incident will transform until it's fully unmasked at this at whatever level is appropriate for the unit of story you're at, and the turning point progressive complication.

Unknown Speaker 14:51

And that happens with these transformations of the essential tactical on the way until that strategy fails. So, whenever there is an interaction, and this happens beyond the turning point, progressive complication to this is just a way of understanding it. But then after the turning point, progressive complication, you either have a reframe, with a new tactic or you have a doubling down on the existing frame by really just throwing more money at that essential tactic. And in that case, you still have the same kind of framework after the turning point progressive complication. So I don't want it to seem like oh, this only happens for part of the scene because this happens on the whole scene. So you have a strategy before and after. That strategy has these little ups and downs as progressive complications happen and complications are happening all over. This is the stuff of story, just little complications dropping in all the time, sometimes big ones. And so when you have those ups and downs you can divide them into chunks, based on parts of the story that have coherent interaction qualities to them. So if you look at what the avatars are doing, they are following. They have consistent roles. They're playing within that little chunk of story. And then the next, the next little chunk, so these little chunks or tropes, spoiler alert, but when you when you go to the next little chunk, they may switch a little bit. They might try something new. But these are they're not at the strategic level. But they're at like the the on the ground like micro action level. And so that's that's how you would identify a trope is by those little chunks that have consistent interactions within them. And so you can sum that up by talking about a specific action that each avatar is trying to take within that trope. And then what you can do is you can take that trope, and you can pour it into other things there. Like I said, they're graspable, and they're portable. So what is portable mean? Well, that means that you can take it and you can say, Okay, this is a part of a story that I can use in my own story. And so you'll start to build up a library of troop types and we'll show you how to identify them using abstract roles and things like that. And then you can just like plug them together in ways that makes sense. They don't all play with each other, but you know, they're like puzzle pieces. Got some different ones that fit kind of generic puzzle pieces, like one of those ones. You heard off the Internet where there are a lot of puzzle pieces that are the same shape, not like the jigsaw expert where it's only one part but anyway, my point is, you can fit them together in interesting ways and really make them your own. But you can use these, they're they're like the building blocks of the scene. So the scene is the building block of the global story. And the trope is the building block of the scene. And they help you to build your progressive complications. They help you to build the arc of your story. And so that is a very long way of going through from first principles, how you identify a trope, and I hope it was helpful to go through a lot of those concepts about how we think about this in terms of all the levels of analysis because they really are working on all the levels when you get down to this micro level. It's playing with the same concepts at a different level. But that is that's how you would identify a trope. And if you try and it doesn't match ours or you try and it's very confusing, it's okay. The important thing is that you're thinking about it and you will be able to refine over time, how you think about these tropes because as you work on your writing, you work on understanding these other levels of analysis, all of these skills are going to help you see what role the trope is playing and you're just going to get more and more clarity over time about how they function.

Unknown Speaker 18:44

Thank you for that because I think that that is it's really clarifying to see again, because the way you walked through what we're trying to accomplish with these things, and it occurred to me while you were talking that if we're thinking about it on the level of a trope, and the you know that there's a an instantiation or there's an aspect of dealing with the inciting incident that it occurred to me that it's like Green Eggs and Ham you know, and would you like it in a house? Would you like it with a mouse and would you like it with a box and what about when the facts I realized I'm not directly I'm paraphrasing a bit there. But but that is a way that the you know, Sam I Am is trying to explain that there are lots of different ways to enjoy Green Eggs and Ham and that he's pushing toward one goal, but offering lots of different options and in pursuing that. So what I love that and then it occurs to me that as you're talking about these, these tropes that if you think about you can think about them. If you kind of make them a little more abstract or more specific then they become they're portable, not just as tropes within different scenes and within different different genres but they are different scenes within different genres, but they are they are similar to the plots within the action story, right? We see the, you know, there's a person against the environment and we've got four different types of those and we've got person against person and four different types of those. And so if you take, if you take the tropes that we talked about today, you can think about how this would fit into one of those big plots that you could use as a subplot or as your whole, you know, the whole plot of your story or, or a sequence and it goes up and down. So I'm so excited to break into break into interesting verb choice there. I'm excited to get into the tropes within the Name of the Rose and it start getting messy but I also wanted to say I wanted to remind everyone that what of what you said about if it doesn't, if it's not clear at first, just like with the what if scenario, just like with the narrative device, and point of view choices that if it doesn't make sense at first, just keep playing with it. Just keep trying it that that you've been working with tropes for a while, haven't you? Yeah, I have I started. I mean, I think like I said the first exposures and the grounds are craft course we started looking at those and then last year in the guild, we did micro scene analysis a lot and we would identify the tropes in those writing assignments. And so got some practice there. That then did the same thing in the pilot workshop that preceded what we're doing in the guild. And through all of those, I've learned a lot about tropes. And I feel like every time I look at tropes, it's like with the five commandments, every time you look at it, you find a new level level of depth. And so yeah, I think my understanding of tropes has evolved a lot over the time that I've been looking at them. And yeah, it's it's useful. However you want to break up the scene and really in start to examine it, part of the value is just in examining it. And then the more you do it, the more value you get out of it, like started a course level and then you refine it and refine it and refine it, and you build on what you did before. To get a deeper level of understanding. But of course, you're not going to be able to like play a symphony, the first time you sit down at a computer, maybe at a computer, I don't know, but a piano. And so instead, what you want to do is practice your scales and that's what we're doing. So the skills are, okay, here's a progression of keys that we want you to practice and that's what we're doing with the masterwork scene. And see you can start by imitating something before you try and venture out into that area on your own.

Unknown Speaker 23:22

Okay, so the most important, the most important thing to remember about how we're exploring the tropes is that we're really in the sandbox, or you might think of us being in in a playing in a Lego bed. You can choose your own metaphor there but but the point is that we're exploring and to have fun with it and to not stress about it as we explore. So, without further ado, let's dive into the troops of the Name of the Rose scene.

Video 2, Tropes in The Name of the Rose Scene

Unknown Speaker 0:02

Okay, so we're going to get started with the tropes in the our Name of the Rose roll negotiation scene and what. So what is our first trope that we're going to explore?

Unknown Speaker 0:16

Our first trope is what I've called it the interviewee and the observer settle in. So this happens when William and Abbo are assigned their room in their cell in the monastery and they go and they get settled in and they eat. They have some excellent raisins. They're important and they have a little chat about what happened with the horse. So that's what happens in the play of the scene there at the trope.

Unknown Speaker 0:47

Okay, so what are some key features that are that are at play within the trope? And how are you identifying those?

Unknown Speaker 0:56

Well, I like to look at how this trope is playing at the other levels of analysis in the scene. And so take a look at all of the things that we've done so far. So when we looked at a point of view narrative device when we looked at and we've talked about the dueling hierarchies, I look at how to set establish roles and each of the hierarchies. When we looked at the scene analysis questions, how are the essential tactics showing through what's happening on the surface that's important that is critical to the overall trajectory of the scene. How does it contribute to the value shift that we saw and beyond the surface?

Unknown Speaker 1:30

And then for the five commandments, I try to identify where the five commandments happen, specifically right in the text? We looked at that last week, but then here, okay, so I know what text corresponds to each commandment, but which trope does that fall Into? Things like that.

Unknown Speaker 1:49

So in this first trope of the Name of the Rose roll negotiation scene, we have a lot going on as we usually do when things are opening up, you know, you want to you want to open a lot of threads up. So one thing is, you know, I talked about the essence of the excellent raisins and I was making a little joke, but it actually is really important. And it may seem like okay, there are raisins, there's food, but these are the things that you want to pay attention to. And again, I don't want to scare anybody because you don't have to do this in your first draft. This is stuff you can layer in later. It's it's what you look at to make sure that your scenes and your work is really resonating is making sure that it has these details in it. So as I go through these key features, if you're like, oh, I don't keep all those things in mind when I'm writing. That's okay. You can edit you can revise you can layer in so just a word of caution before we really get, you know, up to our necks in this trope stuff. But, but the excellent raisins are important, because this trope opens with the display of the material wealth of the power dominance hierarchy, which in this case is the monastery. So you know to us there are raisins all over you can get them in any aisle of your grocery store for not very much money, but not all the raisin but you in this time they were very difficult to come by and Adso makes a specific point of of excellent raisins among all the other foods. And so what he's showing us this is truly a wealthy place. This is a place where even though these are seemingly austere people, and they have they've committed to, you know, a life of restriction they are doing quite well for themselves. And so, this establishes the material power of the power dominance hierarchy. And it also gives an idea of what is possible on the surface if you will just comply with the power dominance hierarchy. So it's showing that this is kind of a nice place to be, if you like great food and comfortable surroundings. So we start to see right away the temptation of conforming to this hierarchy. So that's one thing that happens.

Unknown Speaker 4:07

Well, then, this is really interesting. So we've established the power dominance hierarchy. And now we see the interviewee. So this is William breaking a norm of that power dominance hierarchy. And in the role negotiation scene from The Name of the Rose, what we see him doing is that he likes to talk while he eats, which is great for us because we get to hear some stuff that he has to say, but that is against the Benedictine order. So it's not something that they're going to chastise him for yet he's a guest so he has special privileges, but he's going against the norms of a place when in Rome, He is not doing as the Romans do. Although he is not in Rome, but perhaps just outside it. We don't really know somewhere in Italy. But he is signaling that he's not part of the power dominance hierarchy. He's signaling his otherness. And going back to the the point of view and narrative device, he's signaling his fish out of waterness that he is not of this place.

Unknown Speaker 5:10

And then another key feature of this trope is that the interviewee and the observer have privacy so that the interviewee can speak freely. So a lot of the movement of the scene is going to be about covert action politicking, people playing games with each other. And in this trope, we have a little bit of a place to set up before that sets in. So the privacy is important because it's a time when William or your interviewee can speak freely. While this happens, the observer is playing the role of a reader surrogate asking for an explanation of the interviewing skills that were demonstrated in the previous chapter. So in the previous chapter, William deduced all these things about the horse, which seems magical, to young, Adso who said, you know, how did you do that? And we get the explanation as the interviewee plays the mentor role to the observer. And as he does that the interviewee gives an explanation of the special skills that he possesses. So you're interviewee might not have the same deductive skills as William, but we'll give an explanation of the special skills they possess. And they're focusing on how they strive to learn more. So he's saying, Yes, I was able to deduce stuff about this horse in this one circumstance, but that does not mean that I'm done. Like I always want to improve my craft. If you're here in the Guild, you probably know a little bit about that. I always want to learn more and that indicates that William or your interviewee is in the growth hierarchy.

Unknown Speaker 6:48

So you are using language here, and we'll get into language, of course, a lot more in this semester as we work on line by line. But we want to indicate to the reader that they are striving that they're seeking to grow and that's the growth hierarchy component of how you define your protagonist.

Unknown Speaker 7:07

So I know a lot going on there, but really, we're establishing the roles for the interviewee and the observer in the scene and then also setting the context even though we don't have the interviewer yet. We have the context of that power dominance hierarchy.

Unknown Speaker 7:19

That's wonderful. So what I'm sensing here obviously, is we've got the interviewer and the observer. They're settling in. And this is allowing the, the author to set the scene for what's about to happen. And it occurred to me while you were talking that this is a little bit different from The Shining, which we which is our other example that we've been looking at lately, because we're joining that scene in medius res, so we're not seeing Jack and Ullman settle in the same way we're seeing William and Adso settle in here, so that's a really interesting thing. It's nice to look at the options and see the different Lego pieces that we have at play in scenes like this. Oh, thank you. Thanks, great observation.

Unknown Speaker 8:17

And I think it's really good to to notice those and that's why we're looking at a couple of role negotiation scenes, too, is to allow people in the guild as you observe these different instantiations of rule negotiations and think about like what Leslie just pointed out, that's such a great observation. Why do we see William and Abigail settle in, but we don't see Jack Torrance settle in, and you can start to pick up the differences In what the author is communicating between those two scenes. I think that's, yeah, that's, that's a perfect exercise to do to start to build your familiarity and fluency with these tropes.

Unknown Speaker 8:53

So Danielle, let's look at the second trope that we have in our role negotiation scene in The Name of the Rose, what are we calling this one?

Unknown Speaker 9:01

The second trope is called the interviewer welcomes the interviewee with praise. So as you might guess, from this, the beginning here, the interviewer Abo shows up and he comes into the cell and he starts telling William about how fantastic he is. And that's, what's going on on the page. We're on the surface of the page in this second trope.

Unknown Speaker 9:29

Great. So what are some some of the aspects or features of this one that we want to be paying attention to?

Unknown Speaker 9:38

In this one, it's really, they're all really important as we'll see as we go along. But this one is key because you are putting the interviewer and the interviewee, in conflict or in the same in the same conversation for the first time. So in the previous scene, we had William presenting himself introducing himself to Abo and they had a little bit of an interaction, but this is the first time that they are really engaging with each other. And within the scene, this is the first time that they're interacting. So this is where you see those two sides really come into conflict. And again this is like we were talking about not everything goes in every context. But in the role negotiation scene. It's very important that you bring your to science into conflict with each other because it's this two sided scene where one has to win. So that's where the power dominance hierarchy Abo and the growth hierarchy William are coming together and of course, when two opposing ideologies come together like that, there's going to be a clash.

Unknown Speaker 10:34

So what that looks like, is that the interviewer arrives and gives an oblique reference to the inciting incident. So he says, I have to speak with you about a very serious matter Now you might think, Okay, well, that's just a throwaway phrase. No, it is not. And that's because William as a very perceptive individual starts thinking, the wheels start turning, and it sets up Abos whole strategy. So having that mention of the inciting incident is very important. Next, the interviewer praises the interviewee using his bona fides in the power dominance hierarchy.

Unknown Speaker 11:17

Now, what we're trying to point out here is a small abstraction of the strategies that each avatar uses to accomplish what they wish to accomplish. So and just establish them as a as an avatar as well. So one thing that this is doing is it saying Abo is squarely within the power dominance hierarchy. He is so within that when he needs a new person, he just thinks about them in terms of where they fit. You can see this a lot like they're in power dominance hierarchies, there's always a language of you know, what level manager are you? Or you know, something like that. Show me your CV and I'll tell you how, how seriously I'm going to take you. That's a power dominance hierarchy thing. And so when Abo comes in, and he starts talking about oh, you are recommended by this person, and you've been an Inquisitor, and oh, you've done all this. This is not stuff William cares about. This is what Abo cares about. And so he is simultaneously praising William in his own way, trying again to butter him up to to get what he wants. That's his strategy. And it's also William's strategy, like they're playing a game of how they can manipulate each other to get what they want, as you do in a negotiation scene like this. But he is he's also signaling how different he is from William, because he's doing it in a way that directly contradicts William's ethic, which is the growth hierarchy.

Unknown Speaker 12:52

Now as a demonstration of that, the interviewee keeps redirecting to his growth hierarchy prowess. And that's uncomfortable because every time that the interviewer brings up a bonafide the interview says, Well, yes, but I only did it when I was trying to do it to accomplish this result. And so they keep redirecting to focus on the growth. They're saying, No, it doesn't matter, that I have this shiny badge. What matters is that I accomplished this much justice, you know, you can think about it in that way. And then this keeps escalating until they reach an overt confrontation, where the interviewer calls the interviewee out on the possibility that they may choose a growth hierarchy result over the health of the power dominance hierarchy. And that is the the movement of the speech. So they started out being really polite to each other and they end up in strife and an overt confrontation.

Unknown Speaker 14:04

It occurs to me that that it's really interesting to see the way that the two avatars here are pursuing what they want, and the way that--- because I'm always thinking about what the author is doing too--- that the author is using this interaction to make a point in a very subtle way. And, and so we were getting that kind of that really interesting interaction of avatars that the author is moving around and directing for the purpose and that it's setting up a lot of things that are going to to happen later, not just in the scene, but in the story as a whole. So it's really wonderful to see that.

Unknown Speaker 14:55

Yeah, yeah, I think that when you have two avatars come into contact for the first time. You're you're setting the tone of their interactions, as you said, for the course of the story. And one thing, as you're saying about the point that the author is trying to make too, what's really interesting in here is that the power dominance hierarchy holds a lot of power. That's why it has that name, but it we see in this trope that they are able to kill people. That's something that happens within the, the Abbott's power dominance hierarchy, exemplified both in the church in the Benedictine Order, and then in his monastery at different levels, is he's talking about how when you're an Inquisitor, you can take people, you can punish them. And so, you know, what he's showing is that is that as the power dominance hierarchy figure, he holds a lot of cards in terms of what he can threaten with.

Unknown Speaker 15:59

So yeah, it sets up a lot and it's a very important beat in terms of understanding what's at stake in the story.

Unknown Speaker 16:07

Another great point and I don't want to keep us too long because I know we need to move through but it occurs to me then that what the speed is also showing is that William had the power to do that. He had the ability to do that in certain cases, and chose not to do that. And that that's a really important comparison. So yeah, thank you for for bringing that up.

Unknown Speaker 16:32

Oh, yeah, absolutely. And I think also, I think I've done this in the last couple of exchanges, and I just heard, when sometimes we'll say like in this beat and we mean in this trope overall. So yeah, just to just to note to people who are listening that that we're talking about tropes here, and so, you know, we're having this conversation and we might slip sometimes, but sometimes we're talking about an individual beat within a trope, you know, so we'll be talking about oh, and this beat, but we're not getting into beat study just quite yet. We're talking about tropes. And so you know, as you follow along, even if we mentioned a specific beat, don't worry too much about trying to ground in that specifically, just follow us on the trip level and you'll be a okay. And in future weeks, trust me, we will get into a lot of stuff at the beat level.

Unknown Speaker 17:17

So now we're going to move on to the third trope. What's going on here, Danielle?

Unknown Speaker 17:24

In the third truth, called this one, the interviewer interrogates the interviewee, so remember that at the end of the second trope, they are in open opposition. They have strife with each other. And in this one, the interviewer, after this conflict comes to light, is interrogating the interviewee about the interviewee's beliefs about the core value at stake. So in this case is what is justice? How do you pursue justice and so but doing it in a way that is very tied to on the surface events. Because you don't want to get too heady about Oh, yeah. Explain to me that the meaning of justice you know, that's going to get a little too. too heavy and too, you know, you can tell that the artist comes through and those kind of moments. And so you want to keep in things that the avatars would really say and keep it tied to relevant on the page on the surface events. And so that's what we're doing here is having the interviewer interrogate the interviewee. about specific events that exemplify their approach to the global value at stake.

Unknown Speaker 18:43

Great, and we're not to the inciting incident yet, though. No, we're not by this trope we've had there was a little hint of it in one of the earlier tropes and here we're still just setting it up, a teeing it up as they say, right. So is that something you see often or is that something you think that's unique to this particular scene?

Unknown Speaker 19:12

Well, that's a that's a really wonderful question. And I wouldn't say it's unique, but I would say that it is not the most common strategy. So often, the inciting incident is going to be very near the beginning. So in this case, what you have is a very powerful force of antagonism. This is Abo, who has it figured out. He knows what he is going to do? He has a coherent strategy, it's very well thought out. And so that's why in trope two, when he first comes in, we mentioned that he obliquely references the inciting incident by saying he has a serious matter at hand. Now Abo is enacting his essential tactic right now, because he knows exactly what's going on. The inciting incident which is Adelmo's death right, globally, is already known to Abo. It is not yet known to William. So, when the protagonist comes into contact with the inciting incident, that's when that essential tactic arises. That's when the object of desire is created or crystallized. And so we're not quite there yet, because William hasn't really encountered the inciting incident. So we're going to see that coming up here shortly after these messages, but you know, coming up very shortly, we're gonna see that.

Unknown Speaker 20:42

Now, what are some of the reasons why you would delay (the inciting incident)? Well, I think that when you want to make sure that your audience understands the full, not the full impact, necessarily the inciting incident because it is an invisible fear gorilla, where it has some mass components, but you want them to be able to empathize with your protagonist when you encounter the inciting incident. And so, the more primal it is, the earlier in the story, you can put it and the earlier in the scene that you can put it, and if it needs more explanation you want to delay.

Unknown Speaker 21:23

Now, discovering a dead body is pretty primal. And so you can put that in pretty early and a lot of times we'll see crime stories open in a crime scene or open with the discovery of a crime or the perpetration of a crime because these are really primal. But here what's going on is that the delay is because the essential tactic of the antagonist is to get the lay of the land regarding the protagonist before he lets this information out. So you know, it shows that we're dealing with a very careful person. We're dealing with someone who has a strategy and wants to know before William knows that there is a crime afoot, well, let's see how he might deal with it before he has an essential tactic. Because as soon as he develops his essential tactic, then there will be more complicating factors at play. And Abo would have to factor that in when he's considering what William's underlying strategy is and you know, he knows better than that. He knows to get the information up front.

Unknown Speaker 22:27

Okay, so how is he executing that in this trope?

Unknown Speaker 22:33

Well in this trope he is, as we say in the verb in the title, interrogating William. So the interviewer Abo was openly challenging the interviewee. So he's testing his ability to adhere to the power dominance hierarchy. Remember, William has already tipped his cards a little bit showing him that he adheres to a growth hierarchy instead of power dominance. Now he's pushing it to see how far it'll go. Well, in these cases, what would you do? What about when you said this before? You know, all of those leading questions that are trying to lure him into admitting that he doesn't actually belong in this power dominance hierarchy? Because Abo was testing his potential worth and in his potential loyalty, functioning within this framework for the purposes of this role. And as we talked about a little bit in the last trope, the power dominance hierarchy holds the cards in this case, and, you know, in general. This is a feature of power dominance hierarchies, that they hold the cards in terms of violence, and in terms of, you know, really like that primal control where they have dominance or where people that's part of where the in the name comes from.

Unknown Speaker 23:47

And so, because they hold this power, William is at real risk here. If he says no, you know, the devil is not in these people. You know, what he's trying to get at, but he can't say it, right? Because if he says it, then he's going to be a heretic, and he might be burned for that. He could be cast out. He has all of these potential horrific on the surface. repercussions, because he's in, he's in the church, and so he is forced to back down and start to act covertly. Because he can't show his true dedication to the growth hierarchy at this point, without risking serious bodily harm and you know, I mean, this is a trade off that he's making and it's a small moment here. It's not the overall Turning Point and climax of the scene that are going on right here. But he is here choosing to conform to the power dominance hierarchy, at least on the surface. So that he avoids the limitation of not being able to act as a growth agent anymore because he's been punished. So he always has to be balancing between those two outcomes. And that's something that we'll see again, as you said, like these, these micro interactions set up what happens in the scene as a whole in the sequence in the quadrant in the story.

Unknown Speaker 25:16

Okay, so now, let's look at the fourth trope that we have in this scene, what's happening here.

Unknown Speaker 25:26

So in this one, the interviewer reveals the event that threatens the hierarchy. I promised we would come up to the inciting incident and this is it.

Unknown Speaker 25:34

So remember the in the last beat, William ended by acting covertly. He was forced to back down so he was in, he was in submission, he was retreating and now, remember, Abo brought up the inciting incident at the very beginning. Do you think he did that Accidentally? No, he did not. He had a strategy and now he is employing it. Now. He has William right where he wants him. He's retreating. He's in a position of lesser power compared to Abo, and now this is where he throws that bait into the water.

Unknown Speaker 26:11

So in this trope, this is where he tells William about the death of Adelmo and tries to like I said, Put this bait out here so that William gets intrigued by the potential crime right this mysterious stuff that has happened right before he arrived at the monastery.

Unknown Speaker 26:34

Excellent. And so what are the essential tactics that are happening within this trope?

Unknown Speaker 26:42

So the interviewee, that's William, is seeking a change of subject. He is coming uncomfortably close to the ire of the power dominance hierarchy and he does not want to be there. So he backs out of the debate and he actually spins things around. He takes the bait by asking about the inciting incident so--- I really should have said that the bait was that oblique reference, "Oh, I have a serious matter to discuss with you." So the baits kind of hanging it's like a long line. It's just hanging in the water waiting. And William when he's uncomfortable with what's going on, because he is in this position where he's, like I said, facing the wrath of the power dominance hierarchy, He needs a change of subject. He says, Oh, what about that thing that you mentioned earlier Abo? Let's talk about that.

Unknown Speaker 27:35

So you know, what does that mean that he's doing well, one,he's trying to move on from that other subject. Now, he knows that this guy is a potential danger to him, He's trying to get him out of the room. So he's like, alright, you said you have something to talk about talk about it. Then we can wrap this up. I can get back to my reasons and go to bed. And then from Abo's perspective, this is a small win for him.

Unknown Speaker 27:59

So think about who has the most power in a negotiation? Whoever speaks second. So by getting him to ask about the matter himself, he's already putting William at a disadvantage. And these are very subtle tactics that Abo was using to control things.

Unknown Speaker 28:20

Now. How do we know that he's doing this? Well, the interviewer that's Abo rolls out this prepared speech. So it's not like he is taken aback by William's question. He knows exactly what he's going to say. And that is when you start to see longer explanations and things like that. And Careful, careful turns of phrase, things like that. What you're seeing is that that avatar planned that out before hand. So that's what we see here, where he gives carefully chosen facts to the interviewee. He knows exactly what he's saying. He knows exactly how much to put out to tempt him into the role that he eventually wants William to take.

Unknown Speaker 29:03

So William starts out in a retreat, and then takes the bait by asking about this inciting incident.

Unknown Speaker 29:13

You know that the fun thing about this scene is when I first read it, I didn't feel like Abo seems like a legit okay guy, right. And, so, after analyzing it, and of course, after seeing how it fits in, in the whole story, what was really fun is that now I can't see anything he does as straightforward. I think you're you're really pulling out his, how he's operating. But the audience member gets taken in, at first because of that covert action. And that when we're reading the scene again, it's at this moment when I'm like, No, William Don't take the bait. But of course, he does, otherwise there wouldn't be a fun story.

..........................NB - I had to stich this long video into multiple transcripts, so add about 29 minutes, beginning here.....................................

Unknown Speaker 0:08

Excellent. So are there any other aspects that we want to talk about with this one?

Unknown Speaker 0:16

You I think that those are the key essential pieces of this trope. But I do want to follow up on what you just said about being taken in at first. That is so important. Now. When you're building your scenes, it might be hard to do this again. It might take several revisions and really think because you have to build compelling simulations of people who, you know, follow strategies and things like that, but you have to make sure that your force of antagonism is really a force to be reckoned with. And in some cases, that is physical power and intellectual power, something like that. But here, why is Abo so dangerous? It's precisely because when we first read it, we think, Oh, this poor guy, he had a death in his monastery. That's terrible.

Unknown Speaker 1:04

And, and that's also like, I want to revisit the first principles that we talked about today. In the intro video why do we tell stories, we're communicating something to people? And this happens at every level of story. So at the trope level, you know, we read this and at first we think, oh, you know, that's okay. And then we read it and we say, Oh, I see what's going on there. I see what I was doing and yes, you you feel familiar and say no, William, don't take the bait. And maybe tomorrow, you're talking to somebody, and you ask them a question, and they roll out a perfectly prepared speech with carefully chosen facts. And you think Abbo I see what you did there. And so at a micro trope level, you're learning, you know, the more you go through scenes, and the more you identify these trips, you're learning how to identify things and you learn these adaptive behaviors so that you can start to identify people who act differently than you would ever act but by by being able to simulate them, you know, what you're encountering when you run into them, and you can start to identify the strategies that people are using in real life as well as then employing them in your writing benefits all around, really.

Unknown Speaker 2:17

So now we're moving on to the fifth trope in this scene. And Danielle, what is this? What are you calling this trope? In this one, the interviewee deduces aspects of the event. So this is where William is really showing his prowess so we saw him exhibit his gifts when he had the deductions about the horse. And now this is exactly the same process. He's going through and he's he's following the same process to figure out facts that happened to Adelmo that Abbo did not tell him. And Abo in turn acts amazed. So when when the interviewee applies the gifts to the inciting incident, it should mirror the event that the interviewee and the observer discussed in trope one, because we want to see that mirroring within the scene. And it's also what the interviewer praises in trope two. So we see throughout these tropes that they're building on each other and they're mirroring each other. So trope one we get this frank, speaking freely explanation. Trope two we see that the interviewer sees this gift and thinks, ah, this is relevant to my position in the power dominance hierarchy. It's a threat and also it's an opportunity to use William, right.

Unknown Speaker 3:36

We understand that by displaying their gifts, the interviewee has tipped their hand and has shown the interviewer how to constrain them. Now what that means is not only giving Abo a reason for wanting William in the power dominance hierarchy, but he's also showing him hey, I really like solving puzzles. So if you want to, if you want to get me under your control, give me a puzzle to solve and I will be yours. And that is exactly what we see happen.

Unknown Speaker 4:05

So, you know in response to Williams deduction, The interviewer is playing the amazed spectator to the interviewees display of their gift. Now, again, we know that Abo chose very carefully what to say. So and there are facts in there that there's no reason that he wouldn't put in right like that. The windows were closed, things like that. And so when when William deduces these things and Abo is amazed, This is further evidence that he has planned this out and he is he's playing the audience. He's playing to Williams pride which he knows he has because he's demonstrated that with the horse and he is just Williams not just taking the bait now he is hooked. And so he started to apply his mind to this puzzle and Abo knows that he can get him to to swallow that hook and be constrained in the way he wants him to.

Unknown Speaker 5:07

So in the fifth trope, we saw that William got hooked. what's happening in the sixth trope.

Unknown Speaker 5:15

This one is called the interviewee ascertains the interviewers bias. And in this trope This is an interesting one because we start to see more of Abos plan unfold. So in this, the interviewer begins to outline the constraints on the interview solution to the inciting incident. So we already know there are going to be some constraints in play, not the full ones yet, but he's starting to show his power. You know, I'm not just the victim here. It's not just that somebody died in my monastery, but I have ideas about how we solve it.

Unknown Speaker 5:45

Now here. He's decided it's not a servant. It must be one of the monks, obviously. And so he's already placing boundaries on the field of inquiry into which William can look. And then he tightens the trap. So he does that by Abo feigns uneasiness to goad the interviewee William into further probing. Now, you might be saying, everything has to be on the page. So how do I know that he's feigning uneasiness? It seems to me like he's really uneasy. He has a lot of stuttering. And, you know, you said before that he lines out all these facts, and then we know. Well, in this case, the clues that you're looking for, is that he has this unprompted venture into uneasy territories is what Adso calls it. And it's like, I don't really buy that because he's he wouldn't venture into that uneasy territory If you really feel uneasy about it. He has an agenda for going there.

Unknown Speaker 6:41

Now. If you think about how people interact, they will talk about uneasy subjects if there was someone that they feel very safe with, but he barely knows William, or if they have an agenda for doing so. This is one that he's doing because he has an agenda for telling him this information. Or you know, if they're specifically working on that uneasy subject, like if you're in a therapy session or something like that, you might need to delve into that uneasy territory. But absent one of those three, he's not going to just talk about this uncomfortable subject. He's going to shy away to protect himself. Now. Again, we can eliminate that he feels safe with William because he doesn't. They're barely acquaintances, and we can eliminate that he's in a therapy session because William William is good at stuff but not that. And so we know that he must have a reason for doing it. And the reason is for getting his object of desire in the scene, which is to constrain William and keep him from ruining the power dominance hierarchy.

Unknown Speaker 7:43

And so just looking at the text because it always comes back to the text. You know, what we can see here is that Abo was talking about how a monk on the contrary might have gone into the Aedificium. And William \_\_\_\_\_\_\_\_\_ I understand it's getting uncomfortable him so I understand he wants to shut this down. And then Abo says Furthermore, a monk could have other reasons for venturing into a forbidden place. I mean, reasons that are reasonable, even if contrary to the rule. So now he is, William has already said I understand he can leave it, he has an out, but he is not taking it. And to me, that shows very clearly that he is not in fact uneasy about this or at least not uneasy enough about it that he won't use it in pursuit of his object of desire. So again, he has that strategy for bringing it up because he's not forced into it. He's bringing it up with his own accord, and that means he has something to gain from saying this.

Unknown Speaker 8:40

It's really, if you'll forgive the term, diabolical the way that Abba is setting William up and just reeling him in. And again, you know, as we mentioned before that on the first read, you don't pick up on it but all these details are there. And it's really it's fun to see the mastery with widgets put together. And how and again, I really appreciate what you're showing us in terms of how do you how do you show someone feigning something right? How do you show them pretending when it has to be on the page and we just have we have all those lovely clues. So thank you.

Unknown Speaker 9:26

That's such a good point, Leslie. And you know, I can't deny the diabolical influence in states of affairs like this. But it is so important to look for clues in the text. And just read as closely as you can. And again, do it iteratively so that you are learning more with every read, but look for as many clues as you can to pull apart what's happening and look for what's really going on at the root of the events that you see on the page, but always look for clues. In the text. That's, that's the lesson here is that you can find everything in the text if you look for it.

Unknown Speaker 10:00

So now we are approaching the seventh trope and Danielle, what's happening here?

Unknown Speaker 10:07

Well, this trope comes directly out of the last one so, you know, William, Abo, sorry, ventured into this territory where he was trying to get William to ask him about this uncomfortable thing that he accidentally revealed. And in this one, they put it out on the table as much as they can and they lay as many cards down as they can. Not all of them as we'll see. But this trope is called the interviewee discovers the constraints on the interviewer.

Unknown Speaker 10:39

Now, in the Name of the Rose, the way this plays out, is that Abo makes a reference to his identity as a as a priest. I think brother William, and of course the audience member might not get that it's very, very subtle. You know, even though the audience member might be a young monk who is in Adso's order he feels that he needs to explain it because it's not something that clicked immediately for him as a young monk. And he understood he had this insight and that what was happening is that Abo was saying, you know, I'm a priest, and William acknowledges that that by saying you are always a priest, in Latin. But he's saying that he learned something under the seal of confession that he can't relay.

Unknown Speaker 11:30

So what's going on here at the abstract level? Well, one is the interviewer is explaining why they can't deal with the inciting incident themselves. So if Abo heard something in confession, again, he's a power dominance hierarchy guy, he can go out and take care of that person. We'll just spin up an inquisition, Turn them over to the secular arm. Easy peasy. You know, we're out by lunch and then we can receive our papal embassy. But he can't do that, you know. And so and the reason that he can't do that is that he would be jeopardizing his position in the power dominance hierarchy by going against one of the core tenants of his position as a confessor. So what's really interesting to me about the way that he chooses to present this is that he's presenting something that is sacred to both parties. So he may look at it as an indicator of the power dominance hierarchy, But it is very important in Williams world to. William shows that by acknowledging it and say Say no more, you're a priest forever. Now. So what you want to do here is find an overlap where there's common ground between the priorities of power dominance and the growth hierarchy and use that because because Abo uses this to inspire empathy in William.

Unknown Speaker 12:56

So William is now he's he's gobbling down that bait. Really, he is on Abo's side because they share this common ground. And so it's a it's a nice moment where they find, Well, it's nice on the surface. It's diabolical as you say. That that what's really going on is the Abo was using this to get William even more on his side and to lead him into the constraints that he's prepared for him.

Unknown Speaker 13:31

So then we move quickly on to the eighth trope, and this is a pretty important one. What's happening here, Daniel? Well, here we're seeing a big moment where the interviewee accepts the mission and starts to negotiate terms at least he thinks he is. So remember that in the last trope, William was moved to empathy and compassion for Abbo by the brother William moment, where he he realizes that Abbo is under the constraints of something that he learned in confession. Through the shared sacredness, Abo inspired empathy. And so William says, okay, cool. I'll do it. I'll take on this mission. And you can see this as a direct result of his feeling for Abo. He wants to help this guy out. They, they share values, you know, we're on the same side, we're on the same team. And so he wants to help him and it's a nice added bonus---it's actually the essential tactic---that he can get into the library. So he starts to name terms. And, you know, this is a very short short trope, where just boom, boom, boom, William says what he wants and, and Abo says, Cool, that sounds great. You may I grant you that power this very evening.

Unknown Speaker 14:43

Now, when you see that quick agreement... and this is something this is a nice moment that happened before to when Adso said when when I noticed I noticed that when William agreed very quickly, he was up to something. Well, that goes maybe double for Abbo, too. So when he agrees very quickly like this, he has up to something and we're going to see that in the next beat . And the next trope brother, did it again.

Unknown Speaker 15:10

So in the eighth trope we have William agreeing to take on this mission and and starting to talk about the terms but then something interesting happens in the ninth trope what's happening here.

Unknown Speaker 15:27

It is indeed a very important trope Lesley because it has a lot of scene level stuff going on. going on. So what I mean by that is that I mentioned we can pinpoint the moments when the five commandments are going on. And in this one, we see the turning point progressive complication and the crisis.

Unknown Speaker 15:43

So in this trope, the interviewer places conditions on the investigation. And so this is the, the, the turning point moment when the protagonist interviewee's strategy fails. Now, we talked a little bit before about how the inciting incident was delayed a little bit so that Abo could have some time for his plan. And then since that time, we've had a build up to this turning point moment. So Abo's had a lot of machinations going on. And we've seen these progressive complications happen that are interfering with Williams strategy to investigate the crime to get into the Aedificium to see the library. He really wants that library.

Unknown Speaker 15:46

Now, along the way, we've seen some negative progressive complications, like for example, Abo's threat that he might consider William a heretic. So all of these things where they get uncomfortably close to Williams dismissal of the power dominance hierarchy, and then he has to back down. We've also seen positive progressive complications like in the very last beat where we saw these three things in quick succession where William asked for stuff and Abo said Sure, no problem. These are things where instances where things are easier than they maybe should be. And so we see the it's a progressive complication, because it's signaling that Williams essential tactic is initial strategy coming up, the inciting incident is not working the way that he thought that it would. Things are just a little bit too easy and that signals something going on. There's a problem.

Unknown Speaker 17:21

So now we come to this moment where the whole strategy fails. And that's because the nature of the inciting incident is unmasked. And that means that we're going to see, see that that initial strategy totally fail and that is when Abo says no, you may not go in the library. So in in that moment, the interviewer is revealing the core constraint on the interviewee, and it must directly oppose the interviewee's object of desire.

Unknown Speaker 17:49

So we've seen constraints coming from Abbo before in terms of oh, it has to be a monk it can't possibly be a servant, and he's already put limitations on the investigation. But now he's throwing out one that is huge. Right, so he is making a ridiculous ask. He's saying you may not see the body, it's in the ground. You may not consider all of the suspects. You're limited to a few of them. And oh, by the way, you can't even go to the crime scene.

Unknown Speaker 18:19

So I don't know how many crime shows you all have watched out there in the guild. But you know, generally when I see a crime story, they either examine the body or go to the crime scene or you know, hopefully both, maybe multiple times. So interview everybody involved. And so, so these limitations are really putting constraints on William's ability to solve the crime, to the point that he might not even be able to find out what happened to Adelmo. and this core constraint of the lack of access to the library is in direct opposition to William's object of desire. Now, you know, William tells him what his object of desire is. he said, one of the main reasons I came here is to see this library and Abo Directly opposes that. So that's the turning point.

Unknown Speaker 19:14

Now, the rest of this trope goes into the crisis. And this is when the interviewee and the interviewer debate the legitimacy of that constraint because this is a big deal William is not going to just take this one. Now, and so they do this in a debate. And what I want you to do as you're looking through these tropes is note how this debate is a mirror image of the one that they had in tropes two and three.

Unknown Speaker 19:37

So to revisit what happened in tropes two and three, the interviewer made statements that assumed a common focus on the power dominance hierarchy. So this is where you saying, oh, you know, I was so pleased that you did these things that benefited the church. And then the interviewee, William, deflected with growth hierarchy statements where he said, actually I put people in jail or not in jail, They were they had a much worse fate. But I found people guilty, because they actually did it. And so he's he's voicing some radical ideas there. I know, but he's voicing ideas that are consistent with the growth hierarchy. And those two strategies escalated to the point of open conflict, at which point the interviewee had to make a concession to the power dominance hierarchy to avoid being branded a heretic and facing the same fate as these people who were actually guilty. and he backed down. So that's what happened in two and three.

Unknown Speaker 20:28

Now here in trope nine, we're seeing the mirror image of that. so know what happens. in this trope the interviewee is making statements assuming a common focus on the growth hierarchy. So William is saying this library is really valuable and I should be able to go and see it. He's talking about all the value it provides. He's talking about all the knowledge in it. He's talking about what a value it is to the world and these are all growth hierarchy focus statements.

Unknown Speaker 20:51

Now. The interviewer Abbo parries by doubling down on the power dominance aspects of the library, and these are exclusionary aspects. Now you consider this, this text where he talks about, about books that are in the vulgar tongue, where he talks about that these books are a fomentar of heresies. They inevitably come up, become a fomenter of heresies. You know, he talks about how books can be dangerous. Books can have knowledge that that can can lead people astray. And so he's focusing on the library not as a repository of knowledge and an opportunity for growth, but on a way of locking away knowledge so that the people who are key to the power dominance hierarchy can be the ones who decide who's worthy of getting that. So it's really an accumulation of a hoard of resources, as we talked about in the narrative device training, that will enhance the power of the power dominance hierarchy by giving them leverage over knowledge.

Unknown Speaker 21:57

So those are the two strategies going on. And again, we're seeing this escalate until it reaches a direct confrontation. And this is when William lays the cards on the table by saying Oh, so you're admitting that books have falsehoods. And at this point, the interviewer attacks on a growth hierarchy argument. He says, Oh, well, you know, books are also fragile, and so we shouldn't touch them because they might fall apart. And so he's talking about the loss of knowledge there. And so he too, is backing down a little bit by by making a concession to the growth hierarchy, but he's not backing down from his argument. He's just adapting it to fit into this other hierarchy in the face of open challenge.

Unknown Speaker 22:40

This is really great because one of the things we're seeing in this trope is the way that the the avatar who embraces the growth hierarchy is they're constrained by their values. And you know, so that they don't, they could, you know, he, William could come up with some arguments that are that are power dominance related, but he's, again, he's constrained by his values. Abo on the other hand, does not care and he will use whatever you have to within reason. I mean, he's, he's, okay, he's no Hannibal Lecter. So, so there is there's a spectrum, but but you can see how he's using whatever he has to to get what he wants, and he is not constrained by by values, because he is because he subscribes to power, the power dominance hierarchy and in that it is you know, hold on to the power at all costs. So this is another in a way this is another way that William is constrained that Abo is not and Abo can use this to get what he wants.

Unknown Speaker 24:09

Yeah, that is such a great point in you can really see the different lines in the sand that these avatars have where it like you said William is constrained because he has to play along with his ethic and then for Abo the only thing that matters is maintaining that position. So you know, his line in the sand is he's not going to do Hannibal Lecter things because they wouldn't let him be Abbott if he did you know. But but other than that, it's like as long as he can keep his position, he'll do anything you can to strengthen it. So yeah, that's a that's a really great insight.

Unknown Speaker 24:41

So Danielle, you've talked about how the inciting incident of a scene poses a question that is then answered by the protagonist of the scene in the climax. And as we approach the 10th trope, we're going to dive into the climax. So what's happening here? How does William answer the question posed by the inciting incident?

Unknown Speaker 25:06

Well, in the 10th trope, the interviewee accepts the role even with its conditions. So this is the climactic action that answers the question posed in the inciting incident of whether he will take the job or not. So or whether he'll get the job or not. So when you have a role negotiation scene and you open with the opportunity of a role, then the the answer that it promises is whether or not the avatar will get that. And you know, it could have happened in different ways like do they are they offered the job or not? Sometimes they're not offered the job at all. If they're offered it to they take it or not depending on the consideration. So here he does. He accepts even with the conditions.

Unknown Speaker 25:44

So what we see happening in this trope is that the interviewee tries one last time to make a growth argument, and he appeals to the interviewers interest in the inciting incident. Now here he's really laying it all he's saying like it is absurd for you to expect me to solve a murder---A presumed murder, a death---when I don't have access to the crime scene, and you've already buried the body.

Unknown Speaker 26:09

Again, if you're a reader of the genre, if you've ever seen any sort of police procedural, you know, these are basic things, you know. So he appeals to the interviewers interest in getting that solved. Now, here's where Abo really shines as a covert actor because he anticipated this and he has been setting up breadcrumbs all along, so that he can just sink Williams argument. So remember, he set the hook in trope five, that he's going to control the interviewee. So remember, trope five is where the interviewee deduces aspects of the event. So he lets William exercise His gifts in risk in relation to the inciting incident. So he he deduces things like the windows, the rain, he always he deduces things about Adelmo's death. And so he's already been applying his gifts to the inciting incident and that set the hook of Williams interest, as well as placed the foundation for for what Abo is about to do. So he had set that hook right in trope five. He also, here he he appeals to the interviewee's gifts, and those were established in trope one, praised in trope two, used in trope five, and now he says okay, in that little progression there I did is I showed that you can use your deduction to find out things about Adelmo's death without even being there. You already knew all this other stuff about it. And so you don't need you don't need what I you don't need the access I can give you if you can deduce things about a horse that you've never even seen. I am sure that you can deduce what happened in Adelmo's death.

Unknown Speaker 27:58

And so he uses the interviewer's pride or the interviewee's pride, sorry William's, to push William into accepting. And also the interviewee is going to be hypocrite if he refuses to investigate, you know, because he's talked about how important it is to get justice. He's talked about how important the growth hierarchy is to him and how important truth is. He needs to investigate, or else he's going to be hypocritical. And so with the twin forces of pride and that new commitment to the ethic driving William, he accepts the constraint and agrees to take on the role of investigating this death.

Unknown Speaker 28:40

I love how you have summarized Abo's actions from from the very beginning, because because in in praising William's gift and go and going on and on about it, as he did, he was showing his gift, his gift to really see the situation in front of him. And when I say him, I'm talking about Abo. And, and so you can see how these two, these two men are really well matched. Right we have this is a role in negotiation scene. But another way to look at it is this battle of wits. The problem, of course, is that William doesn't know that he's really that Abo is trying to get the upper hand in the way that he is and as a result, because William doesn't see it in time, he gets hooked. And let's say hooked, line and sinker because of because as you say he if he doesn't accept he will be a hypocrite. And that's a problem for anyone who's engaging with the growth hierarchy.

.................NB, Again, I'm stitching together transcripts, the timing tags are even further off from here. Add about 58 minutes as you proceed.................

Unknown Speaker 0:34

Yeah Leslie That's brilliant. I think you're exactly right. And it also reminds me of what you said about the last trope about how how Abo isn't constrained and William is by the growth hierarchy versus the power dominance hierarchy. And so they're in this battle of wits and as you point out, they're perfectly matched. But they're not because one of them has a line that he'll cross he won't cross and the other one doesn't have any lines at all. And so I think that's a perfect way to delineate the the dynamic going on here in the the battle between these two people. So yeah, thanks for that. That's awesome.

Unknown Speaker 1:15

So as we move on to trope 11, William is in a really bad spot. And he has accepted the the role even though he's in a in a position where he has to accept constraints that he would rather not. How to how do we follow that up? What comes after that?

Unknown Speaker 1:40

Well, the next few tropes are in the resolution space. So after the climax, we're figuring out what happens as a result of William's choice. And we start to see this in trope 11 and we'll continue to see in trope 12 which is the final trope. And I have heard and you know, when I've talked about the scene before, sometimes people will wonder why The things that are in the resolution are in there. So I think it's important to really dig above and beyond, I don't know, dig above and beyond, but go above and beyond the surface, to look at what these what the on the surface actions really mean. And really good example of this is in the 11th trope.

Unknown Speaker 2:23

So in this one, the interviewee asks after the mentor. Now this seems like an abrupt change of subject one more thing Ubertino has like who is Ubertino. But to understand this, we have to dig into what just happened. So as you pointed out, William is in a very bad spot. He has faced a setback. He's constrained. He lost this battle of wits. He's a prideful man. He does not like to lose battles of wits, but he has done so. And so he's in a bad place. Well, what happens when we do that?

Unknown Speaker 2:52

You know, when people are out in a dangerous place and something befalls then the natural tendency is that we start searching for home. Now, maybe not literally, maybe we know we can't go home but you know, we look for some sort of certainty, some sort of familiarity. So if you're threatened in the novel environment, you might look around for something that makes sense to you. This is why you know, you teach children to look for certain things right? Like, like the McGruff trucks, you know, so that they'll identify afamiliar image and go to that, because when you're flooded with threats, it's so difficult to find what the actual safe place is. you just look for something familiar and anchor to that. And that is what William is doing here.

Unknown Speaker 3:45

He's asking after his mentor. so he's in this strange place. He doesn't know many people. He's never been here before. There are lots of rules. He's not even one of the members of this order, right? He's a Franciscan, not a Benedictine. And so there's all of this. All of a sudden. he thought he could navigate it. But now he's been shown very clearly that he can't navigate it. He's at a disadvantage. And he searches for home by asking after his mentor. and so he's going to go and find Ubertino and talk to him and try to salvage what he can by going back to the only thing that he has as a home base in this place, regrouping and figuring out what to do in the face of this seeming defeat.

Unknown Speaker 4:30

So now we are at the 12th and final trope of this scene. and this is the the culmination of the resolution as well. So what's happening here, Daniel?

Unknown Speaker 4:46

Yes, so with the with the resolution we saw in the last trope, how things worked out for William. and now we're going to see the resolution for Abo. Now Abo thinks that he has won. He believes that he has constrained William, he has him in his nice little box, and he's going to be able to go on with his day and do what he wants because William is very constrained. You know, he can't as I've pointed out, right, he can't see the body. He can't see the crime scene. He's gonna go run around doing busy work of investigating things, but hopefully he won't solve stuff very soon. And Abo can have a little bit of peace while this guy who is you know, very likely to uncover some unsavory things that Abo doesn't want uncovered is elsewhere occupied. So that's great. And, you know, in the meantime, he might also find the murderer and then they can take care of that before the papal embassy arrives, which would also be a bonus for Abo. So he thinks that he is in a really great spot. Yeah, we think so too.

Unknown Speaker 5:45

So what happens in the 12th beat is a signal that that might not be the case. And so the way I've described this as as the interviewer who leaves the unbalanced environment signals, it's chaos. So that is, you know, the resolution for Abo. And what happens here takes a little bit of explanation because there's a lot of symbolism and metaphor going on. So what you have to remember when you look at narrative is that everything is determined by the author. That means that the details of the environment the details of the setting, correspond, symbolize and resonate with what's going on in the events of the story. That's why they're included. If not they, if you didn't have a purpose for including you wouldn't include them. And so something that's seemingly unrelated can be related to the events of the story on a symbolic and metaphorical level. And that's what's happening here with the cry of the murdered pig.

Unknown Speaker 6:52

So the environment, as we talked about in the narrative device, training is tightly tightly ordered. Abo has this on lockdown. It's under the power dominance hierarchy. But when we see the pig cry, what we understand is that William has come into this environment, he's ordered in a different way. But he's introducing chaos into the power dominance hierarchy in the sense that he disrupts it and he starts to create cracks in its structure. And Abo doesn't think that's going to happen. He thinks that William is totally contained and walled off, but William will not be stopped like that. He's going to regroup, he's going to come back and he's going to start to cause fractures in the power dominance hierarchy. And so that pig cry symbolizes the rending of the steel of that power dominance hierarchy order. It's starting to break down through the introduction in the interviewee. And that growth hierarchy ethic is going to come into that power dominance hierarchy and break it apart.

Unknown Speaker 8:01

Now when that happens, the interviewer reacts dismissively. And wait, what's the interesting thing to note here is that in the same way that the protagonist can't see exactly what's going on with the inciting incident. Here, the interviewer Abo can't see what's going on here. He thinks again that William is totally locked down. And the chaos here that symbolized by this pig cry is an invisible phere gorilla to that interviewer. He thinks everything's handled, everything's taken care of. Everything's well ordered. And because he's this over-ordered figure, he believes that everything can be explained away. Everything's cause and effect will just explain everything. And, you know, oh, they're slaughtering the pigs. Everything's on time. That's a that's a signal that my timetable is being followed, see? And so, instead of understanding that it's this chaos that actually threatens his position, and so this is something that's a threat to him.

Unknown Speaker 9:01

And, you know, again, we we have some commentary from the author, where he says that Abo did a disservice to his reputation as a clever man. And this calls back to some of the discussion before about how he was magnanimous and he had decorum. And now we're seeing that the front that he put up as being this very clever person, was because he had all this planning time. he had all this preparation time, but when push comes to shove, he's not necessarily as clever as he thinks he is. And he has been fooled by the introduction of this chaotic element into his power dominance hierarchy.

Unknown Speaker 9:42

So that wraps up the scene. And, you know, it's a strong finish. It's an eerie finish, and it propels us forward into the next one.

Unknown Speaker 9:49

Excellent. So I love the way that you've wrapped that up and one of the things that the resolution tells us is of course how things work out. And so when the story event that we talked about in the in the second week, when so when we took the scene and break it down, or not break it down, but distill it down to a single statement that is the the story event that's like the controlling idea. And this is where it's all borne out. And this is the lesson that the audience member or excuse me, that the author is trying to communicate to the single audience member. And so when we come back to that, which I'll share that with you in case you haven't remembered it. Abo constrains Williams pursuit of justice by engaging him to investigate Adelmo's death while bound by the rules of the monastery. And so what's really wonderful I think, is we really, we see this coming to fruition and all of the pieces working together so you can see how each trope is adding up to this statement, that is a distilled statement of what is being shown in the scenes.

Unknown Speaker 11:20

That's such a wonderful summary and it's it's really great that you brought up the connections to those other levels of analysis, because it brings us back to what we're trying to do here, right, communicate that story event, which you laid out so wonderfully. And I think that as guild members go into their assignment, which we'll outline below because there are a lot of constraints this week. So we want to make sure that you have them all lined up, ready to go. It's so important to keep in mind that the how the other layers of analysis, the other levels of analysis, work all together and then come to fruition in the the trope overview.

Unknown Speaker 11:58

And so this week, as you work on actually writing some stuff you're going to be filling in all of these tropes. And as you work on looking at the concept of tropes and seeing how the five commandments of masterwork examples are actually realized in the text, it's going to be so important to keep in mind why you're doing this. It's so that you can make sure that all this stuff works together so that you can create a coherent and consistent and beautiful scene like this one. And so you've done so much hard work over the last few weeks and it is all going to start paying off I hope that you can really see it when you start to construct your own iteration of the same pattern this week.

Unknown Speaker 12:38

Just one more point before we close is to remember the the sandbox or Lego bin again, whichever appeals to you the most, is just to have some patience with yourself. And have some fun and remember that it is a-okay to make mistakes and just really embrace the challenge and and have fun.

Video 3, Close Reading a Trope

Unknown Speaker 0:03

So Danielle, I noticed that as you're talking about these tropes that you are, well, let's just say it, you're paying very close attention to what's happening in you know, in the tropes and and down to even the particular words and so I wondered if there's a good example of how of a detail that you can pull out and show us how you're how you're exactly No, not exact. That's the wrong word. But but to show how you're extracting meaning. That is beyond what the words are on the page, but you're doing it from the actual words on the page.

Unknown Speaker 0:51

Yes, so when I talked about how you identify troops, remember, we talked about how you have this coarse level, and then you refine it, refine it, refine it, refine it, until you it just as there's no until right you always learn more, there's there's no end to this journey. Sorry, if you're, you know, expecting one but, but it's all about the journey. I mean, Shawn's been studying this stuff for 30 plus years. we studied this a lot. You know, we spend so much time with this, and we're always learning more. So you can always refine, you can always enhance your understanding. But what you're looking to do is add value every time you go a little deeper, to make sure that you're understanding things more you're seeing how things fit together more.

Unknown Speaker 1:31

And so when I'm evaluating these tropes, everything I want to say first, everything needs to be on the page. So you don't get anything for free in terms of like, Oh, my reader understands this, because they, you know, like, they must have read this other thing. So you need to make sure that that is on the page so that the reader can piece it together. That said, you do get to collapse certain things or show them just with a nod if things are known to the audience member. So this is part of your continuity and coherence in your consistency and coherence, I should say, in your narrative device model. So you have your author and your audience member in the audience member has certain information that they know like, if they're a monk in the 13th century, you don't have to tell them what all of these things are.

Unknown Speaker 2:19

So that is to say that, you know, I start by by looking at at a very coarse level, what's on the page. And that means looking at what they're actually doing on the surface, what actions they're taking, what are their actual conflicting the things that they say in conflict. And then using the same the same toolbox, you know, start to dig down into a central tactic. So what are they trying to achieve here and look for clues in the text as to what they're trying to do, what their goal states are, how they're feeling how they're processing, and then finally move down into beyond the surface and look for clues about what is at stake.

Unknown Speaker 3:05

So one of the things that we've been talking about as we went through all of the tropes above we talked about well, how do we know what's going on with Abo? he is so covert, you know, he's he's a powerhouse and the more you read, the more a little clues that you find in the text, you know? But in trope five I, I wanted to bring up an example of this really interesting reference. So the abbot, as I have said, was a man of great and diplomatic composure. But this time he made a movement of surprise, that robbed him totally of that decorum, suited to a grave and magnanimous person, as Aristotle has it, who told you is what Abo says?

Unknown Speaker 3:47

Well, that's it. So So remember, you know, we've talked a little bit about how every word is important. Oh, why don't we have this tag as Aristotle has it? So, you know, I went and did some reading into what Aristotle has, and looked into his concept of magnanimity. And when you really pull apart this concept, you learn a lot about what's going on with Abo. And I'm going to link to this interesting article that I read about this. But this talks about Aristotle and how his ideas are related to and relate through the writings of St. Thomas Aquinas. And, as we know, Adso didn't read Greek because that is quite a point in this novel. You know, I think assuming that he's familiar with Aristotle through Aquinas is reasonable and elsewhere he does mention a Aquinas. Jorge talks about him a little bit. So you know, I think it's reasonable to to understand that he would have known about the tension between and tension in the overlap of the ideas between these two thinkers.

Unknown Speaker 4:55

So we can look into what goes on with magnanimity. So a magnanimous man, according to Aristotle is one aware of his high worth and to worthy of great things. So note that in the text. Adso is saying that Abbo failed to be magnanimous. Well, there are two ways that a failure in magnanimity can occur. One of them is that the potential magnanimous person can fail can fail to be aware of his high worth. So this is thinking that you're not as, as worthy of great things as you are and this is called pusillanimity. Failure of the second failure of being worthy of great things but thinking that you are worthy of great things is vanity.

Unknown Speaker 5:51

Aristotle says that pusillanimity is more common and is worse because you don't live up to your full potential. And so, you know, that's, that's Aristotle's construct. And, you know, it seems an awful lot like needing to shine through, you know, differentiating yourself in the growth hierarchy. Now, vanity is something that we see with Abo a lot, but I would say in this instance, we're not seeing evidence of that, you know, where we're not seeing that he has an overinflated opinion of his own worth at this moment, because at this moment, what he's saying is, oh, I didn't know that, William, how did you know tell me more? Well, if he fails to be magnanimous, and he's not being vain, what's the other option? The other option is he is being pusillanimous. What does that mean? He is feigning stupidity, so that William will think that he has the upper hand.

Unknown Speaker 6:47

And so this is a clue that we can look at this one little tag of a phrase, as Aristotle has it, and we understand that by process of elimination---which William likes by the way, there are a lot of William of Ockham references, and you know, eliminating stuff to find the truth---But, but using that process, we can come to the conclusion that Abo was using a covert strategy in this case, and you'll, as you'll see, that's exactly what the author has told us. So it doesn't have to be overt. You don't have to be like I knew at that time, or I didn't know at that time as a young novice but I know now as an old monk, nearing my death that He was being ridiculous. Instead you can say it just through these oblique references and this is what really lent it lends a lot of depth to your to your story, but it also means that you have to pay attention to what the author would say. So at this point, like Adso would not say that at 13 but when he's an older learned, man, he would say it and, and so that's, it's a lot of fun to think about, about those small moments like that to see what they reveal about the text as a whole.

Unknown Speaker 8:01

Now, this doesn't just reveal to us Abo's strategy in the moment, but it also connects up to the broader themes of the novel. So Aristotle focuses a lot on honors, and the magnanimous man must be worthy of honors and hold them in the right regard, which, you know, it's these are external honors. So that's like wealth and so here he's commenting on magnanimity, meaning that you are embracing the wealth that comes to you from from being worthy of it. And we can see that that is really important in this story in terms of the wealth that the monastery has accumulated again, the excellent raisins I'm going to keep saying it because those excellent raisins they're important, but also it you know, it ties in with the poverty of Christ theme. So if you if you have poverty, and you know, that's the big thing that they're debating about at the political society level is, it goes back to that magnanimity, how can you be magnanimous if you you don't have wealth to act as an external marker?

Unknown Speaker 9:07

You know, this all goes back to Aristotle. This is not necessarily what we would see as modern readers, but this is what Adso would say as a scholar of Aristotle, and it also has a connection to justice, right? This is a crime story. And so in the same article that I'm going to link, a quote from the author's justice like magnanimity, but unlike the other moral virtues, is tied to external states of affairs, rather than to means of action or passion relative to the agent. So what this means is that by bringing up magnanimity in a story that's about justice because it's a crime story. We're talking about how important that on the surface result is. So it's not just about you know, figuring out why people do things. It's not just about protecting the church, but it's about making sure that the external state of affairs is in a state of justice, that things are as they should be, in order to achieve the just results.

Unknown Speaker 10:06

And finally, you know, I think that an important thing here is that for Aquinas, and for Aristotle, magnanimity was a sign of salvation. So they had this concept of the unity of virtues, and that meant that if you had one virtue you would have them all, and so magnanimity. You can also be temporary, I don't want to get into all of the details of that there are some, some nuances in there in that you don't have to be worthy of great things to be a virtuous person, you can be temperent, which means that you just find your right level even if it's at a lower level and can still be virtuous. But if you are magnanimous, it is a signal that you possess all the other virtues. And so another quote from this article, it is not possible for one to be both wicked and magnanimous for the fulfillment of the other virtues is a necessary condition for magnanimity.

Unknown Speaker 11:06

So now look at you can look at that in terms of the wealth of the monastery, that by proving their magnanimity by accumulating their wealth, they are showing that they're doing the right thing and they're showing that they are going to go to heaven. And as we see throughout this novel references over and over again to the coming of the Antichrist in the end of days, this is very important to them, because they want to ensure that they're going to be saved when that day comes. And this is something that is very, very salient to them, they think it is just around the corner. Adso even says, if anybody gets to read this manuscript because who knows when the end of the world is coming, you know? And so, so that's extremely important for them. And so we can, by by unpacking these references, we can learn a little bit more about why the things that are important and at stake for them why those are so important to them. And what seemingly surface level things like the wealth of the monastery or the ability to possess wealth to possess great food to eat and excellent raisins. Why is that so important? Because it really it a soul hangs in the balance.

Unknown Speaker 12:18

So I hope that you enjoyed this little rabbit hole because I enjoyed going on it. And, you know, obviously, this isn't the only thing that is happening in this book. I mean, there there are references all over the place, and really with any masterful text, if you look closely enough, you're going to find this you're going to be able to go down these rabbit holes. I don't want you to feel like you have to, but I was hoping, you know in presenting this to you to just show you a little bit of an idea of the fun you can have through close reading and of the fun that you can have layering these things in as an author. So if you have a special area of interest if you know, trivia and details and things like that about a certain subject, you can put them in and they're going to be like these fun little easter eggs for your reader that will help them to illuminate more about what's actually going on in your story. So this can be a really fun exercise. It can be fun to look it up. It can be fun to create it. And for me, it's certainly fun to talk about it so I hope you had a good time listening as well.

## Your Worksheet

It’s time to write your draft! Using the outline of the tropes from the scene, write your draft of your iteration of the masterwork scene. 

Next week, there will be no new training to give you time to complete your first draft.

Editor Mentorship students: send your draft to your editor mentor via Google Docs by next Tuesday.

___

