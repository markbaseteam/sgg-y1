---

---

# The Name of the Rose: Fundamentals

## Week 8: Misattunement (Part 2)

## This Week’s Objectives

-   Topics we’ll cover:
    -   External Subsource
-   This week, it will be a big win if you can:
    -   Start to notice external subsource in inputs and outputs.

## Week 8 Handout

___

## External Subsource

<iframe title="S2-W8-V1-External-Subsource" src="https://player.vimeo.com/video/721865492?h=49322bfa2e&amp;dnt=1&amp;app_id=122963" width="680" height="383" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen=""></iframe>

___

## Application: External Subsource in _The Name of the Rose_

<iframe loading="lazy" title="Y1W8_TNOTR" src="https://player.vimeo.com/video/800233017?h=0c8e0452e2&amp;dnt=1&amp;app_id=122963" width="680" height="383" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen=""></iframe>

___

## Your Worksheet

In your worksheet this week, you’ll analyze beats using external subsource.

For your writing exercise, you’ll build a foundation for your avatars’ external subsources by exploring their identities. 

___

[TRAINING WORKSHEET](https://guild.storygrid.com/worksheet/?ninja=73)

___

[MARK THIS LESSON AS COMPLETED](https://guild.storygrid.com/guild-training/week-8-the-name-of-the-rose-fundamentals/?mark=completed)
