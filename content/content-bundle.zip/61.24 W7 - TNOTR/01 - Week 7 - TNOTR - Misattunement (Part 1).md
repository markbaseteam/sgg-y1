---

---

## Week 7: Misattunement (Part 1)

## Week 7 Handout

___
## Application: Valence, Time, and Degree in _The Name of the Rose_

<iframe loading="lazy" title="Y1TNOTRW7A" src="https://player.vimeo.com/video/798089537?h=eb6dfd18b8&amp;dnt=1&amp;app_id=122963" width="680" height="383" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen=""></iframe>
### Transcript
Speaker 1

00:03

Now that we've gone over the concepts of Valence, time, and degree, let's look at how they apply in our masterwork pattern scene from The Name of the Rose. So what we've done is we've looked at all of the active build up beats for the scene. And we've identified what they would be with respect to each of these characteristics of Misattunement. And we're doing that for the two primary avatars – for Abo and William. Adso has one energetic transfer in there, but we're not going to worry too much about that. And so what we're going to do is look at how they play out over the course of the scene. And we're only looking at active buildup beats. So we're gonna look at moments where the avatars react rather than pursue their objects of desire in later lessons. But this one is really when they're following that strategy when they are trying to achieve their objects of desire. So just the active build up beats.

Speaker 1

00:54

So let's get started by looking at valence. What we can see here is that both of our avatars are pretty depleting, and that's because they're in this debate. They don't like each other. Their worldviews don't agree, they're not having it. And so we do see a certain amount of enlivening energetic transfers from them. You know, they weren't completely going off of the deep end. They do work within the society. They're being somewhat polite to each other, but we have a much higher level of depleting than we tend to see. You know, especially in conversational scenes where people are kind of, you know, trying to follow the rules of the society. Because it is this debate, it's private, and they're able to really get at their core disagreement. Now, this might look different in your iterations. If you have an observer if you have a– I mean everyone has an observer, but if it's more of a public forum, it might look different because they might need to gauge how they're perceived in that environment. But what we need to know here is that both of them are pretty depleting and William it's actually slightly more depleting than Abo. And I think that's because Abo, you know, has a lot of tricks up his sleeve for how to get at his object of desire in a manipulative way. And so he can be covert more of the time and lead William down a path where William doesn't know where that path eventually leads. And so, it's really interesting to look at Abo's energetic transfers and see how he is acting in this covert way to get William to do what he wants.

Speaker 1

2:32

Next, let's look at the external source. The external source comes, it's tied up with valence. So **if the valence is enlivening, it's going to be enabling** so we see that here. And then **our depleting is going to be split up between defeating and redirecting**. And so we won't talk too much about enabling because we just talked about enlivening and so we know what's going on there. But what's really interesting to look at here is that Abo has kind of a split of defeating and redirecting. You know, sometimes he's giving William another objective desire to pursue and sometimes he is just shutting him down. But William is almost always redirecting. And that's reflective of the way that they function in the society. So Abo runs the show here. He is the Abbot, this is his Abbey, and he doesn't have to put up with William's suggestions, of redirecting, and so he can just shut them down. So he has a lot more leeway to be defeating than William does, and we see that reflected here.

Speaker 1

03:37

Now let's take a look at the internal source. So the the percentages here are going to be the same, because these are tied one-to-one to the external source, but through considering them in this other way, we can start to look at what is, how these avatars think about the world. And so what's really interesting here is that we have one who's operating in a lot of chaos – Abo– and one who's operating in a lot of order. And that's William. And so when we think about that, and we think particularly about how William is so tied to order, you know, he wants to come up with a logical argument for things, he wants to make everything makes sense, have everything be linear, it makes sense that he's operating from propositional order so much of the time. And so as you go through the scene, pay attention to those moments where William is expounding on his worldview. Pay attention to how he relies on order to make his arguments and on logic to make his arguments and then Abo comes back and says 'hey, my whim is law here. So it doesn't really matter if it's logical, does it? It matters what I want' and so he can throw chaos into the mix. Now at the same time, these are both mature avatars who have a good hold on what's going on in the context. And so they do have a lot of perspectival complexity, and we do see that come through. And so this is where they are, you know, they're taking on the perspectives of others. They're imagining what the other is thinking. And so that's going to drive a lot of their behavior as well. But again, it's really interesting when we see that divergence where we see chaos over represented in Abo. And order over represented in William.

Speaker 1

05:28

So that wraps up our discussion on valence. That's going to give us an understanding of the way that these two avatars approach valence. And now we can go and look at **Time**. This is not a very interesting graph because it's 100%. Right? So both of them are always working in possibility. And that's because we see dialogue back and forth. So we don't see a lot of nonverbal communication. And I want to talk about that. And we also don't see actuality like they, they don't hit each other. Because they're remaining polite. They're setting each other up for the future. So it makes sense that we're seeing possibility, because it's this verbal discussion. It's this dialogue. And the point that I wanted to make about potential is that we have this narrative device where we have the observer who's in a corner, and so Adso can see things. So he says, you know that the abbot smiles sometimes and things like that sees body language, but he's not in it to where he is seeing the fine details of their body language to the point where he would potentially give us a nonverbal communication. And you know, that may be speculating. We don't really know why he's not giving us that. And he doesn't say that his vision or his perception was obscured in any way. But he is leaning very heavily on this verbal communication, and it makes sense that that's what will come to him the most easily from the place where he is in that nook. This really isn't out of line with what we see in most works, too, because this is a verbal medium. So there's a lot of verbal stuff going on. And we see a lot of dialogue and so possibility is always going to be the highest or – not always, but most often is going to be the highest one of the modes. And here it just happens to be 100%. So often we'll see one or two energetic outputs that are something else, but here it is all about possibility.

Speaker 1

07:37

And finally, let's take a look at **degree**. Now here again, we have a default, and that's going to be micro because ordinarily they're dealing with things that are within the scene. And here we do have a little bit of macro because they're planning what's going to happen later. They're planning when Abo's going to give William the assignment. They're planning William going to see Ubertino and so they do have a little bit of macro going on. William a little bit more, because he is, he's trying to get assurances for the future. He wants to see the library and he's thinking about the future a lot. And Abo's really managing what's going on with William in the scene, although he does engage on some of those topics. And so we do have a little bit of macro, but overwhelmingly micro and think about where those moments are where you need to have macro promises, because this is the inciting incident of the story. So we want to set up some of the things that are coming later in the story to keep our readers interested. And when you do that, you want those macro moments so that you'll say, 'Okay, I'm going to see this in the investigation' or whatever your external genre happens to be. I'm going to see this feature of that external genre as we go along. But you don't have to. You don't have to have a ton of macro moments to make a big impact. You know, we already know a lot of the things that we're going to be looking forward to in the rest of The Name of the Rose and we have that from just a very small number of macro energetic transfers. So don't be afraid to stay in the micro almost all the time, and just have a few peppered moments of macro in there.

Speaker 1

09:10

So that's how it looks overall for the Name of the Rose pattern scene and then think about these distributions as you go forward and you work on revising your own beats. You don't have to do that necessarily, but just keep it in mind as you go through and, it's, we encourage making changes to your drafts along the way, but you don't have to until the next draft revision week. But as you do that, as you think about the way that you are writing beats, and as you engage with your worksheet exercises, think about maintaining these kinds of standard distributions, and especially the ones that are coming from your Master Work pattern, because that's a great place to start to iterate to make sure that you're getting the same feeling and communicating the same things that you need to from the masterwork pattern, because we're working on communicating that signal and eliminating noise in the signal.
___

## Your Worksheet

In your worksheet this week, you’ll continue working with the scene from Witi Ihimaera’s _The Whale Rider_.

For your writing exercise, you’ll practice using valence, time, and degree to misattune your beats. 
