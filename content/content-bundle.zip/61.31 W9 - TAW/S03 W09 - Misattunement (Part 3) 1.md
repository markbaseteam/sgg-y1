---
type: lesson
created: Sunday, October 30th 2022, 8:04:10 am
tags: misattunement
source: https://store.storygrid.com/guild_pages/week-9-misattunement-part-3-2/
author: Story Grid
modified: Monday, October 31st 2022, 6:18:54 am
---

# Week 9: Misattunement (Part 3)

## This Week’s Objectives

- Topics we’ll cover:
	- Internal Subsource
- This week, it will be a big win if you can:
	- Start to notice internal subsource in inputs and outputs.

![[S03 W09 - Rough Transcript.docx.pdf]]

## Week 9 Handout

![[Internal-Subsource-1.pdf]]

## Internal Subsource

<iframe title="2022-S2-W9-V1-Internal-Source-and-Subsource_1" src="https://player.vimeo.com/video/724125925?h=09bef4c409&amp;dnt=1&amp;app_id=122963" width="680" height="383" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen=""></iframe>

![[Internal-Subsource.pdf]]

## Application: Internal Subsource in *The Aeronaut’s Windlass*

<iframe loading="lazy" title="Week 9 - Internal Sub-Source: The Aeronaut&amp;rsquo;s Windlass" src="https://player.vimeo.com/video/765159060?h=bcbd40510a&amp;dnt=1&amp;app_id=122963" width="680" height="383" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen=""></iframe>

![[Internal-Sub-Source-TAW-1.pdf]]

## Your Worksheet

In your worksheet this week, you’ll analyze beats from the examples of attack scenes that we’ve studied so far this semester.

For your writing exercise, you’ll build a foundation for your avatars’ internal subsources by exploring why they act.

[[Week 9 Worksheet - Story Grid Store]]

## Reflection Questions

### Training Reflection Questions

Reflect: Did anything surprise you in today's training?

Reflect: Which topic is the most unclear to you?

Reflect: What is the most important thing that you learned today?

Reflect: What is one question that you'd like answered about today's topic?

## Forum Challenge

[In a Different Light](https://community.storygrid.com/t/forum-challenge-in-a-different-light-semester-3/15674)

How can the same action come from different sources?

Practice considering different reasons that an avatar might act. Pick one concrete action (e.g. rearranging the kitchen) and describe what the avatar’s thought process would be if they were acting from Egoic, self, and Soul.
