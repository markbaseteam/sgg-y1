---

---

## This Week’s Objectives

- Topics we’ll cover:
	- Input and Output
	- The Role of the Protagonist
	- The Spectrum of Collapse
- This week, it will be a big win if you can:
	- Think of your writing in terms of inputs and outputs, and ensure that your protagonist is in the output position.

## Masterwork Scene: _The Aeronaut’s Windlass_ by Jim Butcher, Chapter 2 (Week 6 Handout)

In this document, we break the text into Inputs and Outputs.
[[Semester-3-Masterwork-Scene-The-Aeronauts-Windlass-Week-6.pdf]]

# Application: Active Build Up Beats in _The Aeronaut’s Windlass_

<iframe loading="lazy" title="Active Build Up Beats" src="https://player.vimeo.com/video/755835698?h=13e6bb69ed&amp;dnt=1&amp;app_id=122963" width="680" height="383" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen=""></iframe>

[[Beat-Example-TAW.pdf]]

1

Danielle Kiowski

0:02

Now that we've gone over what active buildup beats are all about, let's look at them in the context of our masterwork pattern seen the second chapter from Jim Butcher’s, The Aeronaut’s Windlass.

To start out, let's just take a pause, take a beat, we might say, and remember what this is all about. So we are looking at beats specifically that are focused on the avatars. So we're going to refer to these as Avatar-owned beats. And that's going to encompass both Active Build Up beats that we're talking about now. And then Reactive Break Down beats that we'll talk about in a few weeks.

But these are the ones where SAM is looking at the avatar, rather than at the author. So in our coffee table model, she's looking at the salt and pepper shakers that are moving all around and talking and all that good stuff. And she's immersing herself and simulating the play of the narrative, rather than hearing directly from that author. So in today's lesson, we're going to look at specifically how these beats look in our masterwork pattern scene.

2

Leslie Watts

1:09

Yes. And to do that, we're going to look at our relevance filter, which is the narrative device. And that involves the author who is the theory list, who has access to Predator’s core crystal, and that Etherealist is talking to SAM, and our SAM is a disgraced leader who is responsible for the lives of other people. And the problem the subject of this conversation is the double factor problem. But we modify it a little bit in the context of the narrative device.

So we have the first factor, which is acting before the nature of what you're up against can lead to falling into a trap. And even if not fatal, with no allies to protect you, the disgraced leader also risks becoming a scapegoat. So that's Factor One.

Factor Two is waiting to know the true nature of the threat can allow antagonists to make nests. And even if not fatal, the disgraced leader who has enemies that want to prey on their vulnerability, also risks being labeled a coward. So we've got those double factor problem that that has the double factor problem that SAM is facing.

And complicating these external factors is the real problem that the leader faces, which is he's over-emphasizing what he can see in predicting the consequences of his actions.

So on top of everything else, all the stuff flowing in from the context, he has this internal challenge, and that's the real challenge that SAM needs to address in order to solve the external problem.

So that's our relevance filter. So the author is going to be presenting active beats that are relevant to that problem. So if we really laser focus on that, it'll help us with analyzing the beats in The Aeronaut’s Windlass, and then to iterate them or generate our own beats that are doing the same thing in our own scene.

1

Danielle Kiowski

3:37

Right, and those beats that are generated within that relevance filter, come from our author, even though they appear to be coming from the avatars. And as the author is presenting those beats, as he said, The Theory list is showing SAM, the story as it happens, the author is taking on the role of curator and deciding what SAM gets to see.

That's the, that's one of the hallmarks of that showing mode is that the author is acting as a filter. And so what that looks like is that the author has these two modes, Evaluative Mode is going to help us understand what to think about the context helps them to think understand what to think about the context and the actions of the avatars.

Through additional information that is coming from the author, and then Declarative Mode is going to present the facts as they unfold.

So these are actual events. We're watching avatars act, and so you know, it might be worth talking about here how these modes show up a little bit differently in something like The Aeronaut’s Windless than in another work, where we might be used to seeing a stronger voice from the author like they may be interject didn't and actually give us some summation of what's happening or give us a value judgment in that Evaluative Mode. But here, Evaluative Mode might look a little bit different.

2

Leslie Watts

5:10

Yeah, see, this is really tricky with this point of view, because it's as if it's a first-person point of view, but from a third-person perspective, so it's all of it's the experience of the point of view character, their external experience, and their internal perceptions and thoughts. But as you said, they're all curated by the author. So the author is going, you know, as if you have all the data, and then is omitting some of it. And then, the rest that's left in, it's all relevant to SAM's problem.

Now, all points of view involve some Telling and some Showing, but as you said, this, it shows up a little bit different here, because the author isn't directly addressing SAM. So if we compare this to something like The Hobbit, where we have lines, like, “I suppose hobbits need some description nowadays, since they have become rare and shy of the big people, as they call us.” So you can see in that instance, the author is directly addressing SAM.

So here, in this particular point of view, the author is covert. And they don't account for why they know the information. And it makes it tricky, trickier than a typical, like a third-person editorial omniscient, like you see in The Hobbit, or in a first-person narrative, like you see in something like Jane Eyre. And there is this binocular point of view.

So what this means is that all the words belong to the avatar. So whoever's point of view or perspective, we are observing the story events through, it's all their words, these are not the words of the author. So it's very much like if you're familiar with free indirect speech. That's exactly it's like the whole thing is free indirect speech.

But again, the author is curating the experience. So you don't get all of the thoughts and experiences but only those that are relevant to SAM's problem.

And that leads us to all the thoughts and experiences that the author is choosing to show to illuminate SAM's problem. There are some that happened in real time, some that are collapsed, and some that are expanded. And so and there are specific reasons for that.

1

Danielle Kiowski

7:53

So look at how the author does that and accomplishes that collapse expansion in the communication of the events. Let's take a look at a particular example from The Aeronaut’s Windlass. So there are lots of beats in the scene. And we will provide a beat breakdown in the handouts, but we want to really dive into one in this application video and show you how we can look at the different modes that the author can employ in a particular instance.

So to take a look at this beat example we have the input. This is coming from Creedy.

That was his theory Sir He's cut power to the lift crystal and is running extra to the trim crystals to make up the difference in buoyancy and keep us afloat. And now the output, Grimm smiled faintly and opened his eyes, there would be no prize money on this trip and no bounty either. The trim crystals that helped adjust the chips attitude were expensive and using them to help maintain the chips lift would be hard on them. But replacing them was a standard operating cost. The large crystals sufficiently powerful to suspend airships were another matter. They were far rarer, and much more bitterly expensive. Only a power core cost more assuming one could be found at all. Where would he get the money? I see. Grim said we'll simply have to replace it, I suppose.

Perhaps fleet will put in a word with the Lancasters. So, in the input, here, we have a fairly simple declarative mode, input, we just have dialogue. We're not getting a lot of explanation of what Creedy is all about here. And, you know, I think as, as you were saying, this is that conflation of the, the author and the avatar that by not by an ocular view. And that we're looking at Grimm so we get more evaluation around Grimm. So really, when we get into the output, this is where we see those two modes diverging.

And we have the bits that are where we're looking at Graham, we're watching him do something whether that's smiling and opening his eyes or speaking to Creedy and then in the middle we have As you said, this is the analog to free indirect style where we're getting his thoughts. But we're getting them coming in an authorial mode. So we believe them. We're not saying, Oh, well Grimm thinks that there's no prize money. But maybe it'll be enough. It takes on that, that authorial sense of objectivity and truth, because it's coming directly from our narrator.

2

Leslie Watts

10:29

So I want to bring laser focus to what we are what we're looking at here in terms of how the author is curating the experience for SAM. Because, right we have these, we have the real time experience. So if we were, for example, if we were a fly on the wall, and we were simply observing what's happening, we would hear Creedy, say his line, we would see Grimm smile faintly and open his eyes, and we would hear Grimm say, I see will simply have to replace it. Right? We might catch something in his, in his demeanor, something else. But that's not something that if that happened, that is not something that author is choosing to show here. Now, the place in here, so that's real time, and remember real time is, is for what SAM needs to see, in order to illuminate her problem, as opposed to if something's collapsed, right, if we're not giving all the details, it's just something that SAM needs to know. And then if, when we're when we're expanding, right, that is how, how the author is helping SAM to make sense of what's happening.

And it's really, really important, right? You, you know, it's like, in a way, these moments are the keys to unlocking how Grimm is mis-aspectualizing his problem, and therefore, how SAM is mis-aspectualizing. The problem, right, there's something here that you're not seeing. And, and also, what's interesting is that what I love about this particular beat, is that it's paying off the beginning of the scene, when the risk to that lift Crystal was mentioned in a kind of offhand way, it was a thought that Grimm had that was, you know, he's got to crunch all that data, as he's making his decisions. And that was just something that came up, but it wasn't something that he anchored on. But here, he's seen the reality, that risk became a consequence. Right? So. So that's a really lovely payoff. But this is also setting up what happens later. And with the with the core crystal, now, not the core crystal with the lift crystal. So we have this beautiful setup. And if you took if you were to take all these little passages from the entire story and put them together, you would see both the way that Graham is mis-identifying and then figuring out and then and then, you know, you would see the clues, and then you would see how the penny drops, right? Where would he get the money? That's the real problem. This is the real risk that he had. And this and that risk became a consequence.

1

Danielle Kiowski

13:58

Yeah, absolutely. And, you know, I think the lift crystal is absolutely a setup for what happens with the spire arc. And then there's also I know you corrected it. But there is a setup here with the power core as well in that you can't find power course. So he is also letting us know that you can't lose the power cord because they're not just lying about on the street. So when rook tries to take his, we understand how important it is that he not let it go. Because without the power cord, there's no ship. And then of course, there's the little setup with the Lancaster's as well, because we know that he's going to be closely allied with one and so I love that you're pointing out that the mechanics of the setups and payoffs in this passage, and that it acts as that expansion. So, you know, in this passage, we don't have the, the collapse like we've seen, like we would see in other paths Just we do have some collapsing throughout the scene like by the time that Creedy came in with the damage report he, he had collected himself. But as you said, that is to skip over the parts that SAM doesn't need to see. And I think that because this is an attack scene, it's going to have more expansion than then we might otherwise see in other types of scenes. And it's just a very high energy kind of scene where a lot is happening very quickly. So attacks don't happen slowly, generally. gelatinous cubes and things like that from D&D excepted.

But the in general, you know, attacks are coming at you very quickly. And so you So expanding, to allow SAM a window into how the avatar is processing, these things that are coming up and very quickly, is going to allow her to see something that might be too fast to process otherwise. So you know, if we see something like we see a fight to happen in real life, it just looks like a lot of back and forth like it's almost orchestrated, right. And so, by teasing that apart, and really pulling it apart, that's where we can get at the parts of that interaction that are interesting in a story way. And in future weeks, when we talk about mis-attuning beats, we're going to talk about what that what that

story type interestingness actually looks like. But for now with what's important to understand about it, is that it's the part of that interaction that is relevant to SAM's problems. So what is it about this fight that is relevant to the problem, and we need to be able to actually examine the pieces of that fight to, to make that determination. And that means that we need to slow it down, we need to expand it, we need to make sure that we're understanding everything that is going into the quick execution that we're seeing on the surface. And even though this isn't a fighting moment. This is this is a moment where as you said, at first, if we have a fly on the wall, it's just creating something Grimm says something. And but Grimm is so thoughtful and avatar that he has, like, what he says is the tip of an iceberg. And so we have that same sort of dynamic, where we need to unpack the way that he's thinking about what he's saying, to get the full import.

2

Leslie Watts

17:39

Yes. And to take this back to back to SAM's problem, it's, it's precisely because it's how SAM is processing the problem, that is a thing that needs to be solved, in order to in order to, to solve the external problem. Right? When do I intervene? Well, I need to think about what I can't see. If I'm going to make a the best decision I can. And that means of course incorporating everything, as, you know, everything we learn in the course of, of going through life, right? So Graham is having going about his day, you know, he learns that, that Creedy is just that sort of idiot who would say something like, like, Yeah, well, you know, Captain, they wouldn't send the Itaska after you unless you were, you know, a really powerful agent. And, and so we're, he's incorporating all of that. And so we need to see that and the sense he's making of this, and, and to, to test whether he is applying the revelations that he has about how the world works in an appropriate way. So these moments are really important, even though when we're reading them, they don't the specifics don't really jump out at us. It's only really on rereading the scene that we pick up these details. Oh, wait, this is the payoff for that.

You know, that concern about the lift crystal earlier? It's only upon rereading that we get those details. So this is close paying attention. And it's not something we necessarily do when we're just reading for fun. And that is okay, when we're reading for fun, and we're reading as writers. Then we want to read more deeply read multiple times and really get to the bottom of what's So what's going on in the text so that we can iterate that pattern?

1

Danielle Kiowski

20:06

Yeah, and the experience at when you're reading as a reader of this is that it's, there's no filter in between you and the avatar. So you take it on board as your own thinking.

And you don't have that layer of listening to someone tell you a story. So I think it's a very immersive experience where you become Grimm. And it facilitates simulation in a way that I'm more into intrusive narrative device would not. And so it, it allows for a seamless experience for SAM. But that makes it extra important, as we've been talking about, to, to pay attention to your technology. So because you want to create the

seamless experience, you want to make very sure, be very certain that your, your actual technology gets out of the way. So you want to be engineering it so that your SAM can become Grimm. And speaking

2

Leslie Watts

21:15

of technology, and, and getting that out of the way, or, or using it in the most judicious way, we've spent a lot of time talking about this one beat. And we haven't even started talking about, for example, mis-attunements. And you know, some of the other like really detailed, detailed bits about how this is functioning, we haven't gotten down to that level yet. But we've spent a lot of time talking about it. And I can imagine, as I'm simulating your experience, right, the experience of someone listening to this, that it it's overwhelming, oh my goodness, I couldn't possibly do this with my entire manuscript.

And no, of course, you can't write because you, it would take you too long, right, either, if you were if you were analyzing it a masterwork to do all of that work. And then to, to test every beat in your story at this level would take too long. But what we want to do is, look at the really important ones, that's one thing, want to preserve this, you know, reserve these tools for the very important ones, and, and use those to get an understanding of how things work, and then only go down into this level of analysis, when you when you have to when there's a problem that's upstream, that you can't, that you need to solve before all of the text will really flow together and work together. So we're not saying that this needs to be done for every beat at all. But we want to, as we study these beats and the way they're written, then we're taking on those lessons.

integrating them into our process in much the way that Grimm integrates new information in, in his context, that enables him to act. And without having to, to always go back and analyze all of his decisions in exactly this way. So it's really important to understand how we're using these tools and when.

1

Danielle Kiowski

23:39

Yes, exactly. So as you said, we in our own work, we have two times, right? If it's a really important beat, we want to look at it very closely and make sure it works. And if there's something wrong with it, and when I'm editing, that's, that's what I do, I'll read through and if something catches me if I say I don't like that moment. That's my experience as a reader. And then I say, Okay, well, why does that? Why does that take me out of the story? Why do I hang up on that moment? And then I use the tools that we've talked about this week, and that we'll talk about in future weeks to diagnose why that moment doesn't work, and fix it. So I think that you know, that's, that's our own work. And then, as you were talking about with these beats, I think it's at think it's about that we want to create our toolkit, right? We're building our toolkit. And so here we're looking at all of them, not just the important ones, because we're using them to build up the skills that will allow us to look at those important ones. And so I want to encourage everyone that that while in your own work you want to focus on on those two different case studies, when you study a masterwork it, it's very helpful to keep your hand in, by carving out time to just do beat analysis and make sure that you that you keep in

practice. Because there have been sometimes when, you know, we've been focusing on the macro level, and we don't do beat analysis for a week or so. And then we get back into it. And it's, it's more difficult to get back into the beat analysis once you haven't been doing it. So making sure to toggle in your masterwork study and keep all of those tools sharp, and ready to go. is really important. So and what that does is that by looking very closely at any beat, any beat because all stories are all units of story contain the concepts of story, by looking very closely at any beat, you're going to improve the way you write all beats. And so it doesn't really matter what you study, it matters that you study. And it matters that you show up to it and commit to that study.

And really, yeah, really dive into to applying all of the methodology that we have. And you know, when I say all units of story to this applies throughout what we're doing for the guild. So we're spending four months on one scene, you probably wouldn't do that if you were writing your story, because then it might take you your entire life to write one book. But by looking very deeply at this scene, we are improving the way that you write all scenes. By looking very deeply at each trope. We're improving the way you write all tropes. And by looking very deeply at this particular beat and other beats that we'll cover in this semester, we're improving the way you write all beats. So if it gets frustrating hang in there. Because what you're doing even if it feels like you're just spinning on one, one instance, you're going to be able to use that and apply it out. And it's going to make everything better, and make your first drafts better, so that you don't have to have as many of them hopefully, as a preview for upcoming weeks, we have the beat structure that we talked about in the concept video today. And we're going to keep exploring. So as you saw in the beat example, we have the green input and the red output. Those are the things we could see if we're a fly on the wall. And then we have that evaluation that builds on that that core of the beat with those little blue boxes around the edges. So that's our evaluation. And we're going to keep looking at these and and looking at how to make that really exciting and make it work as the energetic foundation for our story.

So today, we've looked at the different pieces that will form that energetic Foundation.

And then in future lessons, we're going to make sure that that foundation works as a platform upon which to build the house of our story.

# Your Worksheet

In your worksheet this week, you’ll start working with a new example of an attack scene from _The Hunger Games_ by Suzanne Collins.

For your writing exercise, you’ll practice generating inputs and outputs and work with the sprectrum of collapse.

# Additional Resources

[624 Overview + Tropes and Beats Introduction - YouTube](https://youtu.be/1WLiCyxIsCk)
[Beat Breakdown: Analyze Writing Line-by-Line - Part 1 - YouTube](https://youtu.be/hC4Zj1vPvHg)
[Beat Breakdown: Analyzing Writing Line-by-Line - Part 2 - YouTube](https://youtu.be/CGweY2jL6xY)
[Beat Breakdown: Analyzing Writing Line-by-Line - Part 3 - YouTube](https://youtu.be/uvJ-0uRJBEo)

# Reflection Questions

## Training Reflection Questions

Reflect: Did anything surprise you in today's training?

Reflect: Which topic is the most unclear to you?

Reflect: What is the most important thing that you learned today?

Reflect: What is one question that you'd like answered about today's topic?

# Forum Challenge

[Collapse Your Day](https://community.storygrid.com/t/forum-challenge-collapse-your-day-semester-3/15305)

Let’s take a look at the role of the author in collapsing action. To practice this skill, make a list of the events of your day yesterday (or on a day of your choice). Collapse the events in two different ways to communicate two different messages to the audience.

Here’s an example:

Message: Yesterday was exhausting and I’m so tired.

- I had to go to the store and go down every aisle to find this one specific kind of flour.
- Then, I went home and spent hours trying to decipher my grandmother’s old recipe card to make a cake.
- Next, my sister and her kids invaded the house with 10 other five-year-olds and wreaked havoc.
- I was up all night cleaning up, and it seemed like every surface was covered in a sticky mess.

Message: Yesterday I connected with my family.

- I went to the store and they had the exact kind of flour that my grandmother always used in our birthday cakes. I searched on every aisle and finally found it—I got the last one.
- Then, I went home and spent hours poring over her recipe card to recreate the exact cake that she used to make for us.
- Next, my sister, her kids, and 10 other five-year olds poured into the house to celebrate my niece’s birthday.
- I was up all night cleaning up after the party, and every time I found a smear of icing I couldn’t help but think of my niece’s smile as she ate grandma’s cake.

---

# Navigation

up:: [[20.00 2022-S3]]
same::
down:: [[Week 6 Worksheet - Story Grid Store]]
down:: [[Week 6 Cohort Discussion Plan - Story Grid Store]]
previous:: [[Week 5 - Draft Week]]
next:: [[Week 7 - Misattunement (Part 1)]]

