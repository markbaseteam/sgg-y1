---

---

# Week 7: Misattunement (Part 1)

## Week 7 Handout



## Application: Active Build Up Beats in _The Aeronaut’s Windlass_

<iframe loading="lazy" title="S3_W7_TAW" src="https://player.vimeo.com/video/760720048?h=a39e4bc05b&amp;dnt=1&amp;app_id=122963" width="680" height="383" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen=""></iframe>

[[Valence-Time-and-Degree-TAW.pdf]]

## Your Worksheet

In your worksheet this week, you’ll continue working with the attack scene from _The Hunger Games_ by Suzanne Collins.

For your writing exercise, you’ll practice using valence, time, and degree to misattune your beats.
[[Semester-3-Worksheet-7-Answer-Key-1.pdf]]

